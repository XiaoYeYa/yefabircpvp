package net.minecraft.client.gui.widget;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.input.AbstractInput;
import net.minecraft.text.MutableText;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public abstract class ButtonWidget extends PressableWidget {
	public static final int DEFAULT_WIDTH_SMALL = 120;
	public static final int DEFAULT_WIDTH = 150;
	public static final int field_49479 = 200;
	public static final int DEFAULT_HEIGHT = 20;
	public static final int field_46856 = 8;
	protected static final ButtonWidget.NarrationSupplier DEFAULT_NARRATION_SUPPLIER = textSupplier -> (MutableText)textSupplier.get();
	protected final ButtonWidget.PressAction onPress;
	protected final ButtonWidget.NarrationSupplier narrationSupplier;

	public static ButtonWidget.Builder builder(net.minecraft.text.Text message, ButtonWidget.PressAction onPress) {
		return new ButtonWidget.Builder(message, onPress);
	}

	protected ButtonWidget(
		int x, int y, int width, int height, net.minecraft.text.Text message, ButtonWidget.PressAction onPress, ButtonWidget.NarrationSupplier narrationSupplier
	) {
		super(x, y, width, height, message);
		this.onPress = onPress;
		this.narrationSupplier = narrationSupplier;
	}

	@Override
	public void onPress(AbstractInput input) {
		this.onPress.onPress(this);
	}

	@Override
	protected MutableText getNarrationMessage() {
		return this.narrationSupplier.createNarrationMessage(() -> super.getNarrationMessage());
	}

	@Override
	public void appendClickableNarrations(NarrationMessageBuilder builder) {
		this.appendDefaultNarrations(builder);
	}

	@Environment(EnvType.CLIENT)
	public static class Builder {
		private final net.minecraft.text.Text message;
		private final ButtonWidget.PressAction onPress;
		@Nullable
		private Tooltip tooltip;
		private int x;
		private int y;
		private int width = 150;
		private int height = 20;
		private ButtonWidget.NarrationSupplier narrationSupplier = ButtonWidget.DEFAULT_NARRATION_SUPPLIER;

		public Builder(net.minecraft.text.Text message, ButtonWidget.PressAction onPress) {
			this.message = message;
			this.onPress = onPress;
		}

		public ButtonWidget.Builder position(int x, int y) {
			this.x = x;
			this.y = y;
			return this;
		}

		public ButtonWidget.Builder width(int width) {
			this.width = width;
			return this;
		}

		public ButtonWidget.Builder size(int width, int height) {
			this.width = width;
			this.height = height;
			return this;
		}

		public ButtonWidget.Builder dimensions(int x, int y, int width, int height) {
			return this.position(x, y).size(width, height);
		}

		public ButtonWidget.Builder tooltip(@Nullable Tooltip tooltip) {
			this.tooltip = tooltip;
			return this;
		}

		public ButtonWidget.Builder narrationSupplier(ButtonWidget.NarrationSupplier narrationSupplier) {
			this.narrationSupplier = narrationSupplier;
			return this;
		}

		public ButtonWidget build() {
			ButtonWidget buttonWidget = new ButtonWidget.Text(this.x, this.y, this.width, this.height, this.message, this.onPress, this.narrationSupplier);
			buttonWidget.setTooltip(this.tooltip);
			return buttonWidget;
		}
	}

	@Environment(EnvType.CLIENT)
	public interface NarrationSupplier {
		MutableText createNarrationMessage(Supplier<MutableText> textSupplier);
	}

	@Environment(EnvType.CLIENT)
	public interface PressAction {
		void onPress(ButtonWidget button);
	}

	@Environment(EnvType.CLIENT)
	public static class Text extends ButtonWidget {
		protected Text(
			int i, int j, int k, int l, net.minecraft.text.Text text, ButtonWidget.PressAction pressAction, ButtonWidget.NarrationSupplier narrationSupplier
		) {
			super(i, j, k, l, text, pressAction, narrationSupplier);
		}

		@Override
		protected void drawIcon(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
			this.drawButton(context);
			this.drawLabel(context.getHoverListener(this, DrawContext.HoverType.NONE));
		}
	}
}
