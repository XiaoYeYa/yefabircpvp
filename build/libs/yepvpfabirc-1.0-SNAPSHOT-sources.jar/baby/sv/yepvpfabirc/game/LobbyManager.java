package baby.sv.yepvpfabirc.game;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_266;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9020;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.*;
import java.util.*;

public class LobbyManager {

    private static final class_5321<class_1937> LOBBY_DIMENSION_KEY =
            class_5321.method_29179(class_7924.field_41223, class_2960.method_60655("yepvpfabirc", "lobby"));

    // 大厅出生点
    private static final class_2338 LOBBY_SPAWN = new class_2338(0, 65, 0);
    // 跑酷起点(大厅东侧外)
    private static final class_2338 PARKOUR_START = new class_2338(20, 65, 0);
    private static final int MIN_PLAYERS_TO_START = 7;

    private boolean lobbyBuilt = false;

    // ===== 投票系统 =====
    private boolean voteActive = false;
    private long voteStartTick = 0;
    private UUID voteInitiator = null;
    // 0=对应ID, 1=自选, 2=全随机(ban双人组)
    private int voteMode = -1;
    private final Set<UUID> voteYes = new HashSet<>();
    private final Set<UUID> voteNo = new HashSet<>();
    private static final long VOTE_DURATION_TICKS = 600; // 30秒投票时间
    // 双人组职业(随机模式排除)
    private static final Set<Role> DUO_ROLES = Set.of(Role.BOBBY, Role.RETOUR);

    // ===== 自选模式系统 =====
    private boolean roleSelectActive = false;
    private long roleSelectStartTick = 0;
    private static final long ROLE_SELECT_DURATION_TICKS = 1200; // 60秒选择时间
    private final Map<UUID, Role> roleSelections = new HashMap<>(); // 玩家已选的职业
    private final Set<Role> takenRoles = new HashSet<>(); // 已被选走的职业

    // ===== 开放日期系统 =====
    // 每周 六/日 开放 (DayOfWeek: SATURDAY=6, SUNDAY=7)
    private static final Set<DayOfWeek> OPEN_DAYS = Set.of(
            DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
    private long adminOpenUntilMs = 0; // 管理员临时开放到期时间(System.currentTimeMillis)

    // ===== 准备系统 =====
    private final Set<UUID> readyPlayers = new HashSet<>();

    // ===== 侧边栏 =====
    private static final String SIDEBAR_OBJECTIVE_NAME = "yepvp_lobby";
    private class_266 sidebarObjective = null;

    // ==================== 维度访问 ====================

    public static class_5321<class_1937> getLobbyDimensionKey() {
        return LOBBY_DIMENSION_KEY;
    }

    public static class_3218 getLobbyWorld(MinecraftServer server) {
        return server.method_3847(LOBBY_DIMENSION_KEY);
    }

    // ==================== 大厅传送 ====================

    public void teleportToLobby(class_3222 player) {
        MinecraftServer server = player.method_51469().method_8503();
        if (server == null) return;
        class_3218 lobbyWorld = getLobbyWorld(server);
        if (lobbyWorld == null) {
            System.err.println("[YePVP] Lobby dimension not found! Falling back to overworld.");
            // 回退: 如果大厅维度不存在，传送到主世界出生点
            class_3218 overworld = server.method_30002();
            player.method_48105(overworld, 0.5, 100, 0.5, Set.of(), 0, 0, false);
            return;
        }

        // 确保大厅已建造(每次检查地板方块是否存在)
        boolean floorExists = !lobbyWorld.method_8320(LOBBY_SPAWN.method_10074()).method_26215();
        System.out.println("[YePVP] teleportToLobby: lobbyBuilt=" + lobbyBuilt + ", floorExists=" + floorExists);
        if (!lobbyBuilt || !floorExists) {
            buildLobby(lobbyWorld);
            lobbyBuilt = true;
        }

        // 传送到大厅
        player.method_48105(lobbyWorld, LOBBY_SPAWN.method_10263() + 0.5, LOBBY_SPAWN.method_10264(),
                LOBBY_SPAWN.method_10260() + 0.5, Set.of(), 0, 0, false);

        // 设置冒险模式
        player.method_7336(class_1934.field_9216);

        // 清空背包
        player.method_31548().method_5448();

        // 给予大厅物品
        giveLobbyItems(player);

        // 重置准备状态
        readyPlayers.remove(player.method_5667());

        // 重置最大生命值为20
        var healthAttr = player.method_5996(net.minecraft.class_5134.field_23716);
        if (healthAttr != null) healthAttr.method_6192(20.0);

        // 满血
        player.method_6033(player.method_6063());

        // 清除所有效果后给饱腹
        player.method_6012();
        applyLobbyEffects(player);

        player.method_7353(class_2561.method_43470("§b§l【大厅】§r§a 欢迎来到大厅！"), false);
        player.method_7353(class_2561.method_43470("§7手持 §e钟 §7右键打开投票菜单 | 手持 §a绿宝石 §7右键准备"), false);

        // 非开放日醒目提示
        if (!isServerOpen()) {
            player.method_7353(class_2561.method_43470(""), false);
            player.method_7353(class_2561.method_43470("§c§l╔══════════════════════════════╗"), false);
            player.method_7353(class_2561.method_43470("§c§l║  §e§l⚠ 今天不是开放日！§c§l              ║"), false);
            player.method_7353(class_2561.method_43470("§c§l║  §7开放时间: §a周六 周日§c§l            ║"), false);
            player.method_7353(class_2561.method_43470("§c§l║  §7下次开放: §e" + getNextOpenDay() + "§c§l  ║"), false);
            player.method_7353(class_2561.method_43470("§c§l╚══════════════════════════════╝"), false);
            player.method_7353(class_2561.method_43470(""), false);
        }
    }

    public void teleportAllToLobby(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            teleportToLobby(player);
        }
    }

    // ==================== 大厅效果 (每秒刷新) ====================

    public void applyLobbyEffects(class_3222 player) {
        // 持续饱腹 + 生命恢复
        player.method_6092(new class_1293(class_1294.field_5922, 600, 0, false, false, false));
        player.method_6092(new class_1293(class_1294.field_5924, 600, 2, false, false, false));
    }

    public boolean isInLobby(class_3222 player) {
        return player.method_51469().method_27983() == LOBBY_DIMENSION_KEY;
    }

    // ==================== 开放日期系统 ====================

    public boolean isServerOpen() {
        // 管理员临时开放
        if (System.currentTimeMillis() < adminOpenUntilMs) return true;
        // 按UTC+8判断星期
        DayOfWeek today = LocalDate.now(ZoneId.of("Asia/Shanghai")).getDayOfWeek();
        return OPEN_DAYS.contains(today);
    }

    public void adminOpen(int minutes) {
        adminOpenUntilMs = System.currentTimeMillis() + (long) minutes * 60 * 1000;
    }

    public long getAdminOpenRemainingMs() {
        long remain = adminOpenUntilMs - System.currentTimeMillis();
        return Math.max(0, remain);
    }

    public String getNextOpenDay() {
        LocalDate now = LocalDate.now(ZoneId.of("Asia/Shanghai"));
        for (int i = 1; i <= 7; i++) {
            LocalDate check = now.plusDays(i);
            if (OPEN_DAYS.contains(check.getDayOfWeek())) {
                String[] dayNames = {"", "周一", "周二", "周三", "周四", "周五", "周六", "周日"};
                return dayNames[check.getDayOfWeek().getValue()] + " (" + check + ")";
            }
        }
        return "未知";
    }

    // ==================== 投票系统 ====================

    /**
     * 玩家发起投票: /vote id | /vote select | /vote random
     */
    public void initiateVote(class_3222 player, String mode, MinecraftServer server) {
        if (GameManager.getInstance().isGameActive()) {
            player.method_7353(class_2561.method_43470("§c游戏正在进行中！"), false);
            return;
        }
        if (GameManager.getInstance().isMapResetInProgress()) {
            player.method_7353(class_2561.method_43470("§c地图正在重置中，请稍后！"), false);
            return;
        }
        // 非开放日禁止投票(管理员除外)
        boolean isOp2 = server.method_3760().method_14603().method_14640(new net.minecraft.class_11560(player.method_7334())) != null;
        if (!isServerOpen() && !isOp2) {
            player.method_7353(class_2561.method_43470("§c§l今天不是开放日！§r§c下次开放: §e" + getNextOpenDay()), false);
            return;
        }
        int onlineCount = server.method_3760().method_14571().size();
        boolean isOp = server.method_3760().method_14603().method_14640(new net.minecraft.class_11560(player.method_7334())) != null;
        if (!isOp && onlineCount < MIN_PLAYERS_TO_START) {
            player.method_7353(class_2561.method_43470("§c至少需要 §e" + MIN_PLAYERS_TO_START + " §c人才能开局！当前在线: §e" + onlineCount), false);
            return;
        }
        if (voteActive) {
            player.method_7353(class_2561.method_43470("§c已有投票正在进行中！"), false);
            return;
        }

        int modeId;
        String modeName;
        switch (mode.toLowerCase()) {
            case "id" -> { modeId = 0; modeName = "对应ID模式"; }
            case "select" -> { modeId = 1; modeName = "自选模式"; }
            case "random" -> { modeId = 2; modeName = "全随机模式"; }
            default -> {
                player.method_7353(class_2561.method_43470("§c未知模式！可用: §eid§c/§eselect§c/§erandom"), false);
                return;
            }
        }

        voteActive = true;
        voteStartTick = server.method_30002().method_75260();
        voteInitiator = player.method_5667();
        voteMode = modeId;
        voteYes.clear();
        voteNo.clear();
        voteYes.add(player.method_5667()); // 发起者自动同意

        // 广播投票信息
        class_2561 yesButton = class_2561.method_43470("§a§l[同意]")
                .method_10862(class_2583.field_24360
                        .method_10958(new class_2558.class_10609("/voteyes"))
                        .method_10949(new class_2568.class_10613(class_2561.method_43470("§a点击同意"))));
        class_2561 noButton = class_2561.method_43470("§c§l[反对]")
                .method_10862(class_2583.field_24360
                        .method_10958(new class_2558.class_10609("/voteno"))
                        .method_10949(new class_2568.class_10613(class_2561.method_43470("§c点击反对"))));

        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_7353(class_2561.method_43470(""), false);
            p.method_7353(class_2561.method_43470("§6§l═══════════════════════════"), false);
            p.method_7353(class_2561.method_43470("§e§l  " + player.method_7334().name() + " §r§e发起了投票开局！"), false);
            p.method_7353(class_2561.method_43470("§7  模式: §b§l" + modeName), false);
            p.method_7353(class_2561.method_43470("§7  30秒内投票，过半数同意即开局"), false);
            p.method_7353(class_2561.method_43470(""), false);
            p.method_7353(class_2561.method_43473().method_10852(class_2561.method_43470("  ")).method_10852(yesButton).method_10852(class_2561.method_43470("  ")).method_10852(noButton), false);
            p.method_7353(class_2561.method_43470("§6§l═══════════════════════════"), false);
        }
    }

    public void castVote(class_3222 player, boolean yes) {
        if (!voteActive) {
            player.method_7353(class_2561.method_43470("§c当前没有投票！"), false);
            return;
        }
        UUID uuid = player.method_5667();
        if (voteYes.contains(uuid) || voteNo.contains(uuid)) {
            player.method_7353(class_2561.method_43470("§c你已经投过票了！"), false);
            return;
        }
        if (yes) {
            voteYes.add(uuid);
            broadcastAll(player.method_51469().method_8503(), "§a" + player.method_7334().name() + " 投了 §a§l同意 §r§7(" + voteYes.size() + "同意/" + voteNo.size() + "反对)");
        } else {
            voteNo.add(uuid);
            broadcastAll(player.method_51469().method_8503(), "§c" + player.method_7334().name() + " 投了 §c§l反对 §r§7(" + voteYes.size() + "同意/" + voteNo.size() + "反对)");
        }
    }

    private void broadcastAll(MinecraftServer server, String msg) {
        if (server == null) return;
        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_7353(class_2561.method_43470(msg), false);
        }
    }

    // ==================== 大厅 Tick ====================

    public void tick(MinecraftServer server) {
        long time = server.method_30002().method_75260();

        // 确保大厅维度中方块存在（维度存档被删后需要重建）
        // 每60秒验证一次地板是否存在
        if (!lobbyBuilt || (time % 1200 == 0)) {
            class_3218 lobbyWorld = getLobbyWorld(server);
            if (lobbyWorld != null) {
                boolean floorOk = !lobbyWorld.method_8320(LOBBY_SPAWN.method_10074()).method_26215();
                if (!floorOk) {
                    System.out.println("[YePVP] Lobby floor missing! Rebuilding...");
                    lobbyBuilt = false;
                    buildLobby(lobbyWorld);
                    lobbyBuilt = true;
                } else if (!lobbyBuilt) {
                    lobbyBuilt = true;
                }
            }
        }

        // 清理已离线玩家的准备状态
        Set<UUID> onlineUuids = new HashSet<>();
        for (class_3222 p : server.method_3760().method_14571()) {
            onlineUuids.add(p.method_5667());
        }
        readyPlayers.retainAll(onlineUuids);

        // 每秒更新侧边栏 + ActionBar
        if (time % 20 == 0) {
            updateSidebar(server);
        }

        for (class_3222 player : server.method_3760().method_14571()) {
            if (isInLobby(player)) {
                boolean isOp = server.method_3760().method_14603().method_14640(new net.minecraft.class_11560(player.method_7334())) != null;
                // 每10秒刷新效果
                if (time % 200 == 0) {
                    if (!isOp && player.field_13974.method_14257() != class_1934.field_9216) {
                        player.method_7336(class_1934.field_9216);
                    }
                    applyLobbyEffects(player);
                    // 检查是否缺少大厅物品，缺少则补给
                    if (player.method_31548().method_5438(0).method_7960() || !player.method_31548().method_5438(0).method_31574(class_1802.field_8557)) {
                        giveLobbyItems(player);
                    }
                }
                // 每秒发送ActionBar显示在线人数
                if (time % 20 == 0) {
                    int online = server.method_3760().method_14571().size();
                    int ready = readyPlayers.size();
                    String readyColor = ready >= MIN_PLAYERS_TO_START ? "§a" : "§e";
                    String status = voteActive ? " §6| §c投票进行中..." :
                            roleSelectActive ? " §6| §b自选中 §e" + Math.max(0, (int)((ROLE_SELECT_DURATION_TICKS - (time - roleSelectStartTick)) / 20)) + "s" : "";
                    String openStatus = isServerOpen() ? "" : " §c§l| ⚠ 非开放日";
                    long adminRemain = getAdminOpenRemainingMs();
                    if (adminRemain > 0) {
                        long mins = adminRemain / 60000;
                        openStatus = " §a| 临时开放 §e" + mins + "min";
                    }
                    player.method_7353(class_2561.method_43470(
                            "§b§l在线: " + readyColor + online + "§7/" + MIN_PLAYERS_TO_START +
                            " §a§l准备: §e" + ready + "§7/" + online + status + openStatus), true);
                }
                // 跑酷: 掉入虚空传送回大厅
                if (player.method_23318() < 50) {
                    player.method_48105((class_3218) player.method_51469(),
                            LOBBY_SPAWN.method_10263() + 0.5, LOBBY_SPAWN.method_10264(),
                            LOBBY_SPAWN.method_10260() + 0.5, Set.of(), 0, 0, false);
                    player.method_6033(player.method_6063());
                }
            } else {
                // 不在大厅的玩家: 延迟1秒后传送(确保实体完全初始化)
                if (player.field_6012 > 20) {
                    teleportToLobby(player);
                }
            }
        }

        // 自选模式计时
        if (roleSelectActive) {
            long selectElapsed = time - roleSelectStartTick;
            // 每15秒提醒
            if (selectElapsed % 300 == 0 && selectElapsed > 0 && selectElapsed < ROLE_SELECT_DURATION_TICKS) {
                int remaining = (int) ((ROLE_SELECT_DURATION_TICKS - selectElapsed) / 20);
                int selected = roleSelections.size();
                int total = server.method_3760().method_14571().size();
                broadcastAll(server, "§e§l【自选】§r§7 剩余 §e" + remaining + "秒 §7已选: §a" + selected + "§7/" + total);
            }
            // 最后10秒每秒提醒
            if (selectElapsed >= ROLE_SELECT_DURATION_TICKS - 200 && selectElapsed < ROLE_SELECT_DURATION_TICKS && selectElapsed % 20 == 0) {
                int remaining = (int) ((ROLE_SELECT_DURATION_TICKS - selectElapsed) / 20);
                if (remaining <= 10 && remaining > 0) {
                    broadcastAll(server, "§c§l【自选】§r§c 还有 §e§l" + remaining + " §r§c秒！未选择将随机分配！");
                }
            }
            // 超时
            if (selectElapsed >= ROLE_SELECT_DURATION_TICKS) {
                broadcastAll(server, "§c§l【自选】§r§c 选择时间到！未选择的玩家将随机分配职业。");
                finishRoleSelection(server);
            }
        }

        // 投票计时
        if (voteActive) {
            long elapsed = time - voteStartTick;
            int onlineCount = server.method_3760().method_14571().size();
            int needed = onlineCount / 2 + 1; // 过半数

            // 提前通过: 同意数≥过半
            if (voteYes.size() >= needed) {
                voteActive = false;
                broadcastAll(server, "§a§l【投票通过】§r§a 同意: " + voteYes.size() + " 反对: " + voteNo.size());
                executeVoteResult(server);
                return;
            }
            // 提前失败: 反对数过多，同意已无法过半
            if (voteNo.size() > onlineCount - needed) {
                voteActive = false;
                broadcastAll(server, "§c§l【投票未通过】§r§c 同意: " + voteYes.size() + " 反对: " + voteNo.size());
                return;
            }
            // 超时
            if (elapsed >= VOTE_DURATION_TICKS) {
                voteActive = false;
                if (voteYes.size() >= needed) {
                    broadcastAll(server, "§a§l【投票通过】§r§a 同意: " + voteYes.size() + " 反对: " + voteNo.size());
                    executeVoteResult(server);
                } else {
                    broadcastAll(server, "§c§l【投票未通过】§r§c 同意: " + voteYes.size() + " 反对: " + voteNo.size() + " (需要" + needed + "票同意)");
                }
            }
            // 每10秒提醒
            else if (elapsed % 200 == 0 && elapsed > 0) {
                int remaining = (int) ((VOTE_DURATION_TICKS - elapsed) / 20);
                broadcastAll(server, "§7投票剩余 §e" + remaining + "秒 §7(同意:" + voteYes.size() + " 反对:" + voteNo.size() + " 需要:" + needed + ")");
            }
        }
    }

    private void executeVoteResult(MinecraftServer server) {
        GameManager gm = GameManager.getInstance();
        switch (voteMode) {
            case 0 -> {
                // 对应ID模式: 使用预设的 PLAYER_ROLE_MAP
                broadcastAll(server, "§b§l【开局】§r§e 对应ID模式！职业根据玩家ID自动分配。");
                gm.startGame(false, false);
            }
            case 1 -> {
                // 自选模式: 进入60秒选择阶段
                startRoleSelection(server);
            }
            case 2 -> {
                // 全随机模式: ban掉双人组(BOBBY+RETOUR)
                broadcastAll(server, "§b§l【开局】§r§e 全随机模式！(已排除双人组职业)");
                gm.startGameRandomNoDuo();
            }
        }
    }

    // ==================== 自选模式 ====================

    private void startRoleSelection(MinecraftServer server) {
        roleSelectActive = true;
        roleSelectStartTick = server.method_30002().method_75260();
        roleSelections.clear();
        takenRoles.clear();

        broadcastAll(server, "");
        broadcastAll(server, "§b§l╔═══════════════════════════════╗");
        broadcastAll(server, "§b§l║   §e§l⚡ 自选职业模式 ⚡§b§l            ║");
        broadcastAll(server, "§b§l║   §7点击下方职业进行选择§b§l          ║");
        broadcastAll(server, "§b§l║   §7每个职业只能被1人选择§b§l         ║");
        broadcastAll(server, "§b§l║   §c§l60秒§7后未选择将随机分配§b§l       ║");
        broadcastAll(server, "§b§l╚═══════════════════════════════╝");
        broadcastAll(server, "");

        // 给每个玩家发送可点击的职业列表
        for (class_3222 player : server.method_3760().method_14571()) {
            sendRoleSelectionMenu(player);
        }
    }

    private void sendRoleSelectionMenu(class_3222 player) {
        player.method_7353(class_2561.method_43470("§6§l══════ 可选职业 ══════"), false);

        // 每行显示2个职业按钮
        Role[] roles = Role.values();
        for (int i = 0; i < roles.length; i += 2) {
            class_2561 line = class_2561.method_43473();
            for (int j = i; j < Math.min(i + 2, roles.length); j++) {
                Role role = roles[j];
                boolean taken = takenRoles.contains(role);
                boolean selectedByMe = roleSelections.get(player.method_5667()) == role;

                class_2561 btn;
                if (selectedByMe) {
                    btn = class_2561.method_43470("§a§l[✓ " + role.getDisplayName() + "]")
                            .method_10862(class_2583.field_24360
                                    .method_10949(new class_2568.class_10613(
                                            class_2561.method_43470("§a§l你已选择此职业\n§7" + role.getDescription()))));
                } else if (taken) {
                    btn = class_2561.method_43470("§8§m[" + role.getDisplayName() + "]§r§c(已选)")
                            .method_10862(class_2583.field_24360
                                    .method_10949(new class_2568.class_10613(
                                            class_2561.method_43470("§c此职业已被其他玩家选择"))));
                } else {
                    btn = class_2561.method_43470("§e§l[" + role.getDisplayName() + "]")
                            .method_10862(class_2583.field_24360
                                    .method_10958(new class_2558.class_10609("/selectrole " + role.getPlayerId()))
                                    .method_10949(new class_2568.class_10613(
                                            class_2561.method_43470("§e点击选择\n§7" + role.getDescription()))));
                }
                if (j > i) line = class_2561.method_43473().method_10852(line).method_10852(class_2561.method_43470("  "));
                line = class_2561.method_43473().method_10852(line).method_10852(btn);
            }
            player.method_7353(line, false);
        }
        player.method_7353(class_2561.method_43470("§6§l═══════════════════════"), false);
    }

    public void handleRoleSelection(class_3222 player, String roleId, MinecraftServer server) {
        if (!roleSelectActive) {
            player.method_7353(class_2561.method_43470("§c当前不在自选阶段！"), false);
            return;
        }

        Role role = Role.fromId(roleId);
        if (role == null) {
            player.method_7353(class_2561.method_43470("§c未知职业ID: " + roleId), false);
            return;
        }

        UUID uuid = player.method_5667();

        // 如果玩家之前选过，释放旧职业
        Role oldRole = roleSelections.get(uuid);
        if (oldRole == role) {
            player.method_7353(class_2561.method_43470("§e你已经选了 §b" + role.getDisplayName() + " §e！"), false);
            return;
        }

        // 检查是否已被他人选走
        if (takenRoles.contains(role) && oldRole != role) {
            player.method_7353(class_2561.method_43470("§c§l" + role.getDisplayName() + " §r§c已被其他玩家选择！"), false);
            // 刷新菜单让玩家看到最新状态
            sendRoleSelectionMenu(player);
            return;
        }

        // 释放旧选择
        if (oldRole != null) {
            takenRoles.remove(oldRole);
        }

        // 记录新选择
        roleSelections.put(uuid, role);
        takenRoles.add(role);

        player.method_7353(class_2561.method_43470("§a§l✓ 你选择了 §b§l" + role.getDisplayName() + "§a§l！"), false);
        broadcastAll(server, "§e" + player.method_7334().name() + " §7选择了 §b" + role.getDisplayName() +
                " §7(" + roleSelections.size() + "/" + server.method_3760().method_14571().size() + ")");

        // 刷新所有玩家的菜单
        for (class_3222 p : server.method_3760().method_14571()) {
            sendRoleSelectionMenu(p);
        }

        // 检查是否所有人都选完了
        if (roleSelections.size() >= server.method_3760().method_14571().size()) {
            finishRoleSelection(server);
        }
    }

    private void finishRoleSelection(MinecraftServer server) {
        roleSelectActive = false;
        GameManager gm = GameManager.getInstance();

        // 将已选职业写入分配表
        for (var entry : roleSelections.entrySet()) {
            class_3222 player = server.method_3760().method_14602(entry.getKey());
            if (player != null) {
                gm.assignRole(player.method_7334().name(), entry.getValue());
            }
        }

        // 未选择的玩家随机分配
        List<Role> availableRoles = new ArrayList<>();
        for (Role r : Role.values()) {
            if (!takenRoles.contains(r)) {
                availableRoles.add(r);
            }
        }
        Collections.shuffle(availableRoles);
        int idx = 0;
        for (class_3222 player : server.method_3760().method_14571()) {
            if (!roleSelections.containsKey(player.method_5667())) {
                Role randomRole = availableRoles.get(idx % availableRoles.size());
                gm.assignRole(player.method_7334().name(), randomRole);
                player.method_7353(class_2561.method_43470("§e§l你未选择职业，已随机分配: §b§l" + randomRole.getDisplayName()), false);
                idx++;
            }
        }

        roleSelections.clear();
        takenRoles.clear();

        broadcastAll(server, "§a§l【自选完成】§r§e 所有职业已分配，游戏即将开始！");
        gm.startGame(false, false);
    }

    // ==================== 地图重置 ====================

    public boolean resetMainWorldMap(MinecraftServer server) {
        Path presetDir = server.method_3831().resolve("config").resolve("yepvp_preset_map");
        if (!Files.exists(presetDir) || !Files.isDirectory(presetDir)) {
            System.err.println("[YePVP] Preset map directory not found: " + presetDir);
            return false;
        }

        // 获取主世界
        class_3218 overworld = server.method_30002();

        // 保存并卸载所有区块
        overworld.method_14176(null, true, false);

        // 获取主世界存档目录
        Path sessionDir = server.method_27050(net.minecraft.class_5218.field_24188);
        Path regionDir = sessionDir.resolve("region");
        Path poiDir = sessionDir.resolve("poi");
        Path entitiesDir = sessionDir.resolve("entities");

        try {
            // 删除现有的 region/poi/entities 文件
            deleteDirectoryContents(regionDir);
            deleteDirectoryContents(poiDir);
            deleteDirectoryContents(entitiesDir);

            // 从预设目录复制
            Path presetRegion = presetDir.resolve("region");
            Path presetPoi = presetDir.resolve("poi");
            Path presetEntities = presetDir.resolve("entities");

            if (Files.exists(presetRegion)) {
                copyDirectory(presetRegion, regionDir);
            }
            if (Files.exists(presetPoi)) {
                copyDirectory(presetPoi, poiDir);
            }
            if (Files.exists(presetEntities)) {
                copyDirectory(presetEntities, entitiesDir);
            }

            System.out.println("[YePVP] Main world map reset successfully from preset.");
            return true;
        } catch (IOException e) {
            System.err.println("[YePVP] Failed to reset map: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private void deleteDirectoryContents(Path dir) throws IOException {
        if (!Files.exists(dir)) return;
        Files.walkFileTree(dir, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }
            @Override
            public FileVisitResult postVisitDirectory(Path d, IOException exc) throws IOException {
                if (!d.equals(dir)) Files.delete(d);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private void copyDirectory(Path src, Path dst) throws IOException {
        Files.createDirectories(dst);
        Files.walkFileTree(src, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                Path targetDir = dst.resolve(src.relativize(dir));
                Files.createDirectories(targetDir);
                return FileVisitResult.CONTINUE;
            }
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.copy(file, dst.resolve(src.relativize(file)), StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    // ==================== 大厅建筑生成 ====================

    private static final int SET_FLAGS = net.minecraft.class_2248.field_31036 | net.minecraft.class_2248.field_31031;

    private void buildLobby(class_3218 world) {
        System.out.println("[YePVP] buildLobby() called! World: " + world.method_27983().method_29177());

        // 强制加载大厅+跑酷区域涉及的所有区块
        int minCX = (-25) >> 4;
        int maxCX = 75 >> 4;
        int minCZ = (-30) >> 4;
        int maxCZ = 30 >> 4;
        for (int chunkX = minCX; chunkX <= maxCX; chunkX++) {
            for (int chunkZ = minCZ; chunkZ <= maxCZ; chunkZ++) {
                world.method_8497(chunkX, chunkZ);
            }
        }
        System.out.println("[YePVP] Chunks loaded. Checking floor at " + LOBBY_SPAWN.method_10074());

        // 检查大厅是否已经存在 (避免重复建造)
        if (!world.method_8320(LOBBY_SPAWN.method_10074()).method_26215()) {
            System.out.println("[YePVP] Lobby already exists, skipping build.");
            return;
        }
        System.out.println("[YePVP] Building lobby structure...");

        int cx = LOBBY_SPAWN.method_10263();
        int cy = LOBBY_SPAWN.method_10264();
        int cz = LOBBY_SPAWN.method_10260();

        class_2680 quartzBlock = class_2246.field_10153.method_9564();
        class_2680 quartzPillar = class_2246.field_10437.method_9564();
        class_2680 smoothQuartz = class_2246.field_9978.method_9564();
        class_2680 glowstone = class_2246.field_10171.method_9564();
        class_2680 seaLantern = class_2246.field_10174.method_9564();
        class_2680 barrier = class_2246.field_10499.method_9564();
        class_2680 blackConcrete = class_2246.field_10458.method_9564();
        class_2680 whiteConcrete = class_2246.field_10107.method_9564();
        class_2680 cyanConcrete = class_2246.field_10308.method_9564();
        class_2680 purpleGlass = class_2246.field_10399.method_9564();
        class_2680 cyanGlass = class_2246.field_10248.method_9564();

        int halfW = 20; // 大厅半宽(41x41)
        int height = 10; // 大厅高度

        // ===== 地板: 棋盘格图案 =====
        for (int x = cx - halfW; x <= cx + halfW; x++) {
            for (int z = cz - halfW; z <= cz + halfW; z++) {
                class_2680 floor;
                int dx = Math.abs(x - cx);
                int dz = Math.abs(z - cz);
                // 中心圆形区域(半径5): 青色混凝土
                if (dx * dx + dz * dz <= 25) {
                    floor = cyanConcrete;
                }
                // 边缘装饰带
                else if (dx == halfW || dz == halfW) {
                    floor = blackConcrete;
                }
                // 棋盘格
                else {
                    floor = ((x + z) % 2 == 0) ? smoothQuartz : whiteConcrete;
                }
                world.method_8652(new class_2338(x, cy - 1, z), floor, SET_FLAGS);
                world.method_8652(new class_2338(x, cy - 2, z), barrier, SET_FLAGS);
            }
        }

        // ===== 墙壁: 石英块 + 玻璃窗 =====
        for (int y = cy; y < cy + height; y++) {
            for (int x = cx - halfW; x <= cx + halfW; x++) {
                // 北墙/南墙
                for (int wallZ : new int[]{cz - halfW, cz + halfW}) {
                    if (y >= cy + 2 && y <= cy + height - 3 && Math.abs(x - cx) <= 8 && Math.abs(x - cx) > 1) {
                        world.method_8652(new class_2338(x, y, wallZ), (y % 2 == 0) ? cyanGlass : purpleGlass, SET_FLAGS);
                    } else {
                        world.method_8652(new class_2338(x, y, wallZ), quartzBlock, SET_FLAGS);
                    }
                }
            }
            for (int z = cz - halfW; z <= cz + halfW; z++) {
                // 东墙/西墙
                for (int wallX : new int[]{cx - halfW, cx + halfW}) {
                    if (y >= cy + 2 && y <= cy + height - 3 && Math.abs(z - cz) <= 8 && Math.abs(z - cz) > 1) {
                        world.method_8652(new class_2338(wallX, y, z), (y % 2 == 0) ? purpleGlass : cyanGlass, SET_FLAGS);
                    } else {
                        world.method_8652(new class_2338(wallX, y, z), quartzBlock, SET_FLAGS);
                    }
                }
            }
        }

        // ===== 天花板: 石英块 + 海晶灯照明 =====
        for (int x = cx - halfW; x <= cx + halfW; x++) {
            for (int z = cz - halfW; z <= cz + halfW; z++) {
                int dx = Math.abs(x - cx);
                int dz = Math.abs(z - cz);
                if (dx % 4 == 0 && dz % 4 == 0) {
                    world.method_8652(new class_2338(x, cy + height, z), seaLantern, SET_FLAGS);
                } else {
                    world.method_8652(new class_2338(x, cy + height, z), quartzBlock, SET_FLAGS);
                }
            }
        }

        // ===== 四角柱子: 石英柱 + 海晶灯顶 =====
        int[][] corners = {{-halfW + 2, -halfW + 2}, {-halfW + 2, halfW - 2},
                          {halfW - 2, -halfW + 2}, {halfW - 2, halfW - 2}};
        for (int[] c : corners) {
            for (int y = cy; y < cy + height; y++) {
                world.method_8652(new class_2338(cx + c[0], y, cz + c[1]), quartzPillar, SET_FLAGS);
            }
            world.method_8652(new class_2338(cx + c[0], cy + height - 1, cz + c[1]), seaLantern, SET_FLAGS);
        }

        // ===== 中心装饰: 信标底座 =====
        world.method_8652(new class_2338(cx, cy, cz), class_2246.field_10327.method_9564(), SET_FLAGS);
        // 3x3铁块底座
        for (int bx = -1; bx <= 1; bx++) {
            for (int bz = -1; bz <= 1; bz++) {
                world.method_8652(new class_2338(cx + bx, cy - 1, cz + bz), class_2246.field_10085.method_9564(), SET_FLAGS);
            }
        }

        // ===== 屏障围栏 (大厅外围防止逃出, 但跑酷方向不封) =====
        for (int y = cy - 2; y <= cy + height + 1; y++) {
            for (int x = cx - halfW - 1; x <= cx + halfW + 1; x++) {
                world.method_8652(new class_2338(x, y, cz - halfW - 1), barrier, SET_FLAGS);
                world.method_8652(new class_2338(x, y, cz + halfW + 1), barrier, SET_FLAGS);
            }
            for (int z = cz - halfW - 1; z <= cz + halfW + 1; z++) {
                world.method_8652(new class_2338(cx - halfW - 1, y, z), barrier, SET_FLAGS);
                // 东墙留出跑酷入口(z在-2到2之间, y在65-67)
                if (z >= cz - 2 && z <= cz + 2 && y >= cy && y <= cy + 2) {
                    // 不放屏障,留出入口
                } else {
                    world.method_8652(new class_2338(cx + halfW + 1, y, z), barrier, SET_FLAGS);
                }
            }
        }
        // 天花板上方屏障
        for (int x = cx - halfW - 1; x <= cx + halfW + 1; x++) {
            for (int z = cz - halfW - 1; z <= cz + halfW + 1; z++) {
                world.method_8652(new class_2338(x, cy + height + 1, z), barrier, SET_FLAGS);
            }
        }

        // ===== 跑酷区域 (大厅东侧外部) =====
        buildParkour(world, cx + halfW + 2, cy, cz);

        System.out.println("[YePVP] Lobby structure built at " + LOBBY_SPAWN);
    }

    // ==================== 跑酷区域生成 ====================

    private void buildParkour(class_3218 world, int startX, int startY, int startZ) {
        class_2680 stone = class_2246.field_10056.method_9564();
        class_2680 mossyStone = class_2246.field_10065.method_9564();
        class_2680 prismarineBricks = class_2246.field_10006.method_9564();
        class_2680 seaLantern = class_2246.field_10174.method_9564();
        class_2680 barrier = class_2246.field_10499.method_9564();

        Random rand = new Random(42); // 固定种子确保每次一致

        // 平台序列: {dx, dy, dz, sizeX, sizeZ}
        int[][] platforms = {
            {0, 0, 0, 3, 3},       // 起点平台
            {4, 1, 2, 2, 2},       // 阶梯向上
            {7, 2, -1, 2, 2},
            {11, 3, 1, 1, 3},      // 窄桥
            {14, 4, 0, 2, 2},
            {17, 3, -3, 2, 2},     // 下降
            {20, 4, -1, 1, 1},     // 单格跳
            {23, 5, 1, 1, 1},
            {26, 6, -1, 1, 1},
            {29, 7, 0, 2, 2},
            {32, 8, 2, 1, 3},      // 长窄桥
            {35, 9, 0, 2, 2},
            {38, 8, -2, 1, 1},     // 下降单格
            {41, 9, 0, 1, 1},
            {44, 10, 1, 2, 2},
            {47, 11, -1, 3, 3},    // 终点大平台
        };

        for (int[] plat : platforms) {
            int px = startX + plat[0];
            int py = startY + plat[1];
            int pz = startZ + plat[2];
            int sx = plat[3];
            int sz = plat[4];

            for (int dx = 0; dx < sx; dx++) {
                for (int dz = 0; dz < sz; dz++) {
                    class_2680 block = rand.nextInt(3) == 0 ? mossyStone : stone;
                    world.method_8652(new class_2338(px + dx, py - 1, pz + dz), block, SET_FLAGS);
                }
            }
        }

        // 终点奖励: 海晶灯
        int endX = startX + 47;
        int endY = startY + 11;
        world.method_8652(new class_2338(endX + 1, endY, startZ), seaLantern, SET_FLAGS);

        // 跑酷区域底部屏障网(防止无限掉落)
        for (int x = startX - 2; x <= startX + 52; x++) {
            for (int z = startZ - 6; z <= startZ + 6; z++) {
                world.method_8652(new class_2338(x, startY - 5, z), barrier, SET_FLAGS);
            }
        }
        // 跑酷区域侧面屏障墙
        for (int y = startY - 5; y <= startY + 15; y++) {
            for (int x = startX - 2; x <= startX + 52; x++) {
                world.method_8652(new class_2338(x, y, startZ - 7), barrier, SET_FLAGS);
                world.method_8652(new class_2338(x, y, startZ + 7), barrier, SET_FLAGS);
            }
            world.method_8652(new class_2338(startX + 53, y, startZ), barrier, SET_FLAGS);
        }
        // 跑酷区域顶部屏障
        for (int x = startX - 2; x <= startX + 52; x++) {
            for (int z = startZ - 6; z <= startZ + 6; z++) {
                world.method_8652(new class_2338(x, startY + 16, z), barrier, SET_FLAGS);
            }
        }

        // 起点告示(用发光方块标记)
        world.method_8652(new class_2338(startX, startY, startZ + 2), class_2246.field_27159.method_9564(), SET_FLAGS);
    }

    // ==================== 大厅物品 ====================

    private static final String LOBBY_ITEM_TAG = "yepvp_lobby";

    private void giveLobbyItems(class_3222 player) {
        // 槽位0: 投票菜单(钟)
        class_1799 voteClock = new class_1799(class_1802.field_8557);
        voteClock.method_57379(class_9334.field_49631, class_2561.method_43470("§6§l投票开局 §7(右键)"));
        voteClock.method_57379(class_9334.field_49632, new class_9290(List.of(
                class_2561.method_43470("§7右键打开投票菜单"),
                class_2561.method_43470("§7选择模式发起投票")
        )));
        player.method_31548().method_5447(0, voteClock);

        // 槽位4: 准备(绿宝石)
        class_1799 readyItem = new class_1799(class_1802.field_8687);
        readyItem.method_57379(class_9334.field_49631, class_2561.method_43470("§a§l准备 §7(右键)"));
        readyItem.method_57379(class_9334.field_49632, new class_9290(List.of(
                class_2561.method_43470("§7右键切换准备状态"),
                class_2561.method_43470("§7准备好后等待开局")
        )));
        player.method_31548().method_5447(4, readyItem);

        // 槽位8: 跑酷传送(紫水晶碎片)
        class_1799 parkourItem = new class_1799(class_1802.field_27063);
        parkourItem.method_57379(class_9334.field_49631, class_2561.method_43470("§d§l跑酷 §7(右键)"));
        parkourItem.method_57379(class_9334.field_49632, new class_9290(List.of(
                class_2561.method_43470("§7右键传送到跑酷起点")
        )));
        player.method_31548().method_5447(8, parkourItem);
    }

    /**
     * 处理大厅物品右键使用，返回true表示消耗了该事件
     */
    public boolean handleLobbyItemUse(class_3222 player) {
        if (!isInLobby(player)) return false;

        class_1799 held = player.method_6047();
        if (held.method_7960()) return false;

        // 钟: 投票菜单
        if (held.method_31574(class_1802.field_8557)) {
            showVoteMenu(player);
            return true;
        }
        // 绿宝石/绿色染料: 准备
        if (held.method_31574(class_1802.field_8687) || held.method_31574(class_1802.field_8131)) {
            toggleReady(player);
            return true;
        }
        // 紫水晶碎片: 跑酷
        if (held.method_31574(class_1802.field_27063)) {
            player.method_48105((class_3218) player.method_51469(),
                    PARKOUR_START.method_10263() + 0.5, PARKOUR_START.method_10264() + 1,
                    PARKOUR_START.method_10260() + 0.5, Set.of(), 0, 0, false);
            player.method_7353(class_2561.method_43470("§d§l【跑酷】§r§a 传送到跑酷起点！"), false);
            return true;
        }

        return false;
    }

    private void showVoteMenu(class_3222 player) {
        MinecraftServer server = player.method_51469().method_8503();
        if (server == null) return;

        int online = server.method_3760().method_14571().size();
        boolean canStart = online >= MIN_PLAYERS_TO_START;
        String countColor = canStart ? "§a" : "§c";

        player.method_7353(class_2561.method_43470(""), false);
        player.method_7353(class_2561.method_43470("§6§l═══════ 投票开局 ═══════"), false);
        player.method_7353(class_2561.method_43470("§7在线人数: " + countColor + online + "§7/" + MIN_PLAYERS_TO_START +
                (canStart ? " §a✓ 可以开局" : " §c✗ 人数不足")), false);
        player.method_7353(class_2561.method_43470(""), false);

        // 三个可点击选项
        class_2561 idBtn = class_2561.method_43470("§e§l[对应ID模式]")
                .method_10862(class_2583.field_24360
                        .method_10958(new class_2558.class_10609("/vote id"))
                        .method_10949(new class_2568.class_10613(class_2561.method_43470("§e根据玩家ID分配对应职业"))));
        class_2561 selectBtn = class_2561.method_43470("§b§l[自选模式]")
                .method_10862(class_2583.field_24360
                        .method_10958(new class_2558.class_10609("/vote select"))
                        .method_10949(new class_2568.class_10613(class_2561.method_43470("§b使用已分配的职业"))));
        class_2561 randomBtn = class_2561.method_43470("§d§l[全随机模式]")
                .method_10862(class_2583.field_24360
                        .method_10958(new class_2558.class_10609("/vote random"))
                        .method_10949(new class_2568.class_10613(class_2561.method_43470("§d随机分配职业(排除双人组)"))));

        player.method_7353(class_2561.method_43473().method_10852(class_2561.method_43470("  ")).method_10852(idBtn), false);
        player.method_7353(class_2561.method_43473().method_10852(class_2561.method_43470("  ")).method_10852(selectBtn), false);
        player.method_7353(class_2561.method_43473().method_10852(class_2561.method_43470("  ")).method_10852(randomBtn), false);
        player.method_7353(class_2561.method_43470(""), false);
        player.method_7353(class_2561.method_43470("§6§l═══════════════════════"), false);
    }

    // ==================== 准备系统 ====================

    public void toggleReady(class_3222 player) {
        UUID uuid = player.method_5667();
        if (readyPlayers.contains(uuid)) {
            readyPlayers.remove(uuid);
            player.method_7353(class_2561.method_43470("§c§l【准备】§r§c 已取消准备"), false);
            // 更新手持物品外观
            class_1799 item = new class_1799(class_1802.field_8687);
            item.method_57379(class_9334.field_49631, class_2561.method_43470("§a§l准备 §7(右键)"));
            item.method_57379(class_9334.field_49632, new class_9290(List.of(
                    class_2561.method_43470("§7右键切换准备状态"),
                    class_2561.method_43470("§c当前状态: 未准备")
            )));
            player.method_31548().method_5447(4, item);
        } else {
            readyPlayers.add(uuid);
            player.method_7353(class_2561.method_43470("§a§l【准备】§r§a 已准备！等待其他玩家..."), false);
            // 更新手持物品外观
            class_1799 item = new class_1799(class_1802.field_8131);
            item.method_57379(class_9334.field_49631, class_2561.method_43470("§a§l已准备 ✓ §7(右键取消)"));
            item.method_57379(class_9334.field_49632, new class_9290(List.of(
                    class_2561.method_43470("§7右键切换准备状态"),
                    class_2561.method_43470("§a当前状态: 已准备")
            )));
            player.method_31548().method_5447(4, item);

            // 广播准备消息
            MinecraftServer server = player.method_51469().method_8503();
            if (server != null) {
                int online = server.method_3760().method_14571().size();
                broadcastAll(server, "§a" + player.method_7334().name() + " §7已准备 §e(" + readyPlayers.size() + "/" + online + ")");
            }
        }
    }

    public Set<UUID> getReadyPlayers() {
        return readyPlayers;
    }

    // ==================== 侧边栏(Scoreboard) ====================

    private void updateSidebar(MinecraftServer server) {
        class_269 scoreboard = server.method_3845();

        // 创建/获取侧边栏Objective
        if (sidebarObjective == null) {
            sidebarObjective = scoreboard.method_1170(SIDEBAR_OBJECTIVE_NAME);
            if (sidebarObjective == null) {
                sidebarObjective = scoreboard.method_1168(
                        SIDEBAR_OBJECTIVE_NAME,
                        class_274.field_1468,
                        class_2561.method_43470("§b§lYePVP §7大乱斗"),
                        class_274.class_275.field_1472,
                        true,
                        class_9020.field_47557
                );
            }
            scoreboard.method_1158(net.minecraft.class_8646.field_45157, sidebarObjective);
        }

        // 清除旧分数
        for (String entry : new ArrayList<>(scoreboard.method_1178().stream()
                .map(holder -> holder.method_5820()).toList())) {
            if (scoreboard.method_55430(net.minecraft.class_9015.method_55422(entry), sidebarObjective) != null) {
                scoreboard.method_1155(net.minecraft.class_9015.method_55422(entry), sidebarObjective);
            }
        }

        int online = server.method_3760().method_14571().size();
        int ready = readyPlayers.size();
        boolean mapResetting = GameManager.getInstance().isMapResetInProgress();
        String readyColor = ready >= MIN_PLAYERS_TO_START ? "§a" : "§e";

        // 分数越高越靠上
        setScore(scoreboard, "§6§l════════════", 10);
        setScore(scoreboard, "§f在线: " + (online >= MIN_PLAYERS_TO_START ? "§a" : "§c") + online + "§7/" + MIN_PLAYERS_TO_START, 9);
        setScore(scoreboard, "§f准备: " + readyColor + ready + "§7/" + online, 8);
        setScore(scoreboard, " ", 7);
        if (mapResetting) {
            setScore(scoreboard, "§c⚡ 地图重置中...", 6);
        } else if (roleSelectActive) {
            int selRemaining = (int) ((ROLE_SELECT_DURATION_TICKS - (server.method_30002().method_75260() - roleSelectStartTick)) / 20);
            if (selRemaining < 0) selRemaining = 0;
            setScore(scoreboard, "§b§l自选职业中!", 6);
            setScore(scoreboard, "§a已选: §e" + roleSelections.size() + "§7/" + online, 5);
            setScore(scoreboard, "§7剩余: §f" + selRemaining + "秒", 4);
        } else if (voteActive) {
            int remaining = (int) ((VOTE_DURATION_TICKS - (server.method_30002().method_75260() - voteStartTick)) / 20);
            if (remaining < 0) remaining = 0;
            String modeName = switch (voteMode) {
                case 0 -> "对应ID";
                case 1 -> "自选";
                case 2 -> "全随机";
                default -> "未知";
            };
            setScore(scoreboard, "§e投票: §b" + modeName, 6);
            setScore(scoreboard, "§a同意:" + voteYes.size() + " §c反对:" + voteNo.size(), 5);
            setScore(scoreboard, "§7剩余: §f" + remaining + "秒", 4);
        } else {
            setScore(scoreboard, "§a等待开局...", 6);
        }
        setScore(scoreboard, "  ", 3);

        // 显示准备状态列表
        int idx = 2;
        for (class_3222 p : server.method_3760().method_14571()) {
            if (idx < 0) break;
            String name = p.method_7334().name();
            if (name.length() > 10) name = name.substring(0, 10);
            String mark = readyPlayers.contains(p.method_5667()) ? "§a✓ " : "§7○ ";
            setScore(scoreboard, mark + "§f" + name, idx--);
        }
    }

    private void setScore(class_269 scoreboard, String name, int score) {
        scoreboard.method_1180(net.minecraft.class_9015.method_55422(name), sidebarObjective).method_55410(score);
    }

    public void removeSidebar(MinecraftServer server) {
        if (server == null) return;
        class_269 scoreboard = server.method_3845();
        if (sidebarObjective != null) {
            scoreboard.method_1194(sidebarObjective);
            sidebarObjective = null;
        }
    }

    // ==================== 获取双人组职业集合 ====================
    public static Set<Role> getDuoRoles() {
        return DUO_ROLES;
    }
}
