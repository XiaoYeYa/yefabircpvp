package baby.sv.yepvpfabirc.game;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class MapDataCollector {

    // 缓存: chunkKey(long) → 4x4子区块RGB颜色(int[16])
    private static final ConcurrentHashMap<Long, int[]> chunkColorCache = new ConcurrentHashMap<>();

    // 渐进扫描状态: 遍历整个世界边界区域
    private static int scanCursorIndex = 0;
    private static List<long[]> scanQueue = null; // [chunkX, chunkZ] pairs stored as long[]{cx, cz}
    private static boolean fullScanComplete = false;
    private static final int CHUNKS_PER_TICK = 50; // 每次调用扫描50个区块(避免服务器过载)

    // 每次tick: 渐进扫描未缓存的区块(只采样已加载的, 不强制加载避免磁盘IO和区块生成开销)
    // 动态变化(ALLAND涂色/XLL玻璃/SHUBING画等)通过 invalidateChunk() 精准失效后下轮扫到时重新采样
    public static void tickCollect(class_3218 world) {
        if (scanQueue == null) {
            buildScanQueue(world);
        }
        if (scanQueue != null && !scanQueue.isEmpty()) {
            int scanned = 0;
            int attempted = 0;
            int maxAttempts = CHUNKS_PER_TICK * 4; // 遇到大量已缓存chunk时最多多扫几次
            while (scanned < CHUNKS_PER_TICK && attempted < maxAttempts && scanCursorIndex < scanQueue.size()) {
                long[] coords = scanQueue.get(scanCursorIndex);
                int cx = (int) coords[0];
                int cz = (int) coords[1];
                long key = class_1923.method_8331(cx, cz);
                scanCursorIndex++;
                attempted++;
                if (chunkColorCache.containsKey(key)) continue;
                // 只采样已加载的区块, 未加载的下一轮扫描循环再试
                class_2818 wc = world.method_14178().method_21730(cx, cz);
                if (wc == null) continue;
                try {
                    int[] colors = sampleChunkSubColors(world, wc);
                    chunkColorCache.put(key, colors);
                } catch (Exception ignored) {}
                scanned++;
            }
            if (scanCursorIndex >= scanQueue.size()) {
                fullScanComplete = true;
                scanCursorIndex = 0; // 循环重新扫描(处理新加载区块/边界变化)
            }
        }
    }

    // 构建扫描队列: 世界边界内所有区块坐标
    private static void buildScanQueue(class_3218 world) {
        net.minecraft.class_2784 border = world.method_8621();
        int centerX = (int) border.method_11964();
        int centerZ = (int) border.method_11980();
        int radius = (int) (border.method_11965() / 2) + 16;
        int minCX = (centerX - radius) >> 4;
        int maxCX = (centerX + radius) >> 4;
        int minCZ = (centerZ - radius) >> 4;
        int maxCZ = (centerZ + radius) >> 4;
        scanQueue = new ArrayList<>();
        for (int cx = minCX; cx <= maxCX; cx++) {
            for (int cz = minCZ; cz <= maxCZ; cz++) {
                scanQueue.add(new long[]{cx, cz});
            }
        }
        scanCursorIndex = 0;
        fullScanComplete = false;
    }

    // 强制刷新指定区块颜色(用于涂色等动态变化)
    public static void invalidateChunk(int chunkX, int chunkZ) {
        chunkColorCache.remove(class_1923.method_8331(chunkX, chunkZ));
    }

    // 清空缓存(游戏重置时)
    public static void reset() {
        chunkColorCache.clear();
        scanQueue = null;
        scanCursorIndex = 0;
        fullScanComplete = false;
    }

    // 构建地图数据 byte[]
    // 格式: [chunkCount(int)] + 每个chunk: [chunkX(short), chunkZ(short), 16*rgb(48 bytes)]
    //       + [playerCount(int)] + 每个player: [x(int), z(int), nameLen(short), name(bytes), markerColor(int)]
    //       + [paintedChunkCount(int)] + 每个: [chunkX(short), chunkZ(short), paintColor(byte)]
    public static byte[] buildMapData(class_3218 world, UUID requestingPlayer) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);

            // 世界边界半径 + 中心坐标
            net.minecraft.class_2784 border = world.method_8621();
            int borderRadius = (int) (border.method_11965() / 2);
            dos.writeInt(borderRadius);
            dos.writeInt((int) border.method_11964());
            dos.writeInt((int) border.method_11980());

            // 区块颜色数据(4x4子区块, 每区块16个RGB)
            dos.writeInt(chunkColorCache.size());
            for (Map.Entry<Long, int[]> entry : chunkColorCache.entrySet()) {
                int cx = class_1923.method_8325(entry.getKey());
                int cz = class_1923.method_8332(entry.getKey());
                dos.writeShort(cx);
                dos.writeShort(cz);
                int[] subColors = entry.getValue();
                for (int i = 0; i < 16; i++) {
                    int rgb = subColors[i];
                    dos.writeByte((rgb >> 16) & 0xFF);
                    dos.writeByte((rgb >> 8) & 0xFF);
                    dos.writeByte(rgb & 0xFF);
                }
            }

            // 玩家位置标记(根据请求者职业决定是否显示)
            GameManager gm = GameManager.getInstance();
            PlayerData reqData = gm.getPlayerData(requestingPlayer);

            // ST Ciallo期间能看到所有人
            long currentTick = world.method_75260();
            boolean stCialloActive = reqData != null && reqData.getRole() == Role.ST
                    && reqData.getCialloSeeAllUntilTick() > currentTick;

            boolean canSeeAllPlayers = reqData != null && (
                    reqData.getRole() == Role.POPCORN ||
                    reqData.getRole() == Role.HELI ||
                    stCialloActive
            );

            // JIEZU夜晚完全隐身(位置无法被探测): 判断当前是否夜晚
            long dayTime = world.method_8532() % 24000;
            boolean isNight = dayTime >= 13000 && dayTime <= 23000;

            List<PlayerMarker> markers = new ArrayList<>();
            Set<UUID> addedPlayers = new HashSet<>();
            if (canSeeAllPlayers) {
                for (Map.Entry<UUID, PlayerData> e : gm.getAllPlayerData().entrySet()) {
                    PlayerData pd = e.getValue();
                    if (!pd.isAlive()) continue;
                    // JIEZU夜晚不可被探测
                    if (pd.getRole() == Role.JIEZU && isNight) continue;
                    // DASHA水中/雨中不可被探测(且不在显形期内)
                    if (pd.getRole() == Role.DASHA && pd.isInWater()) {
                        long ct = world.method_75260();
                        if (ct >= pd.getDashaVisibleUntilTick()) continue;
                    }
                    var player = world.method_8503().method_3760().method_14602(e.getKey());
                    if (player == null) continue;
                    int color = 0xFFFFFF; // 白色默认
                    markers.add(new PlayerMarker((int) player.method_23317(), (int) player.method_23321(), pd.getPlayerName(), color, player.method_36454()));
                    addedPlayers.add(e.getKey());
                }
            }
            // DASHA: 地图持续显示离自己最近的玩家位置
            if (reqData != null && reqData.getRole() == Role.DASHA) {
                var dashaPlayer = world.method_8503().method_3760().method_14602(requestingPlayer);
                if (dashaPlayer != null) {
                    double nearestDist = Double.MAX_VALUE;
                    class_3222 nearestPlayer = null;
                    PlayerData nearestPd = null;
                    for (Map.Entry<UUID, PlayerData> e : gm.getAllPlayerData().entrySet()) {
                        if (e.getKey().equals(requestingPlayer)) continue;
                        PlayerData pd = e.getValue();
                        if (!pd.isAlive()) continue;
                        // 不能探测到隐身的JIEZU/DASHA
                        if (pd.getRole() == Role.JIEZU && isNight) continue;
                        if (pd.getRole() == Role.DASHA && pd.isInWater()) continue;
                        var other = world.method_8503().method_3760().method_14602(e.getKey());
                        if (other == null) continue;
                        double dx = dashaPlayer.method_23317() - other.method_23317();
                        double dz = dashaPlayer.method_23321() - other.method_23321();
                        double dist = dx * dx + dz * dz;
                        if (dist < nearestDist) {
                            nearestDist = dist;
                            nearestPlayer = other;
                            nearestPd = pd;
                        }
                    }
                    if (nearestPlayer != null && !addedPlayers.contains(nearestPlayer.method_5667())) {
                        markers.add(new PlayerMarker((int) nearestPlayer.method_23317(), (int) nearestPlayer.method_23321(), nearestPd.getPlayerName(), 0x00AAFF, nearestPlayer.method_36454())); // 蓝色
                        addedPlayers.add(nearestPlayer.method_5667());
                    }
                }
            }
            // BOBBY和RETOUR地图位置互相共享
            if (reqData != null && (reqData.getRole() == Role.BOBBY || reqData.getRole() == Role.RETOUR)) {
                Role partnerRole = reqData.getRole() == Role.BOBBY ? Role.RETOUR : Role.BOBBY;
                for (Map.Entry<UUID, PlayerData> e : gm.getAllPlayerData().entrySet()) {
                    PlayerData pd = e.getValue();
                    if (pd.getRole() != partnerRole || !pd.isAlive() || addedPlayers.contains(e.getKey())) continue;
                    // 等待复活的罪人也显示(灵体状态)
                    if (pd.getRole() == Role.BOBBY && pd.isWaitingForRevive() && pd.getDeathPos() != null) {
                        markers.add(new PlayerMarker(pd.getDeathPos().method_10263(), pd.getDeathPos().method_10260(), pd.getPlayerName() + "§c(灵体)", 0xAA00AA, 0f));
                        addedPlayers.add(e.getKey());
                        continue;
                    }
                    var player = world.method_8503().method_3760().method_14602(e.getKey());
                    if (player == null) continue;
                    markers.add(new PlayerMarker((int) player.method_23317(), (int) player.method_23321(), pd.getPlayerName(), 0xAA00AA, player.method_36454())); // 紫色
                    addedPlayers.add(e.getKey());
                }
            }
            // RETOUR复活罪人后位置暴露30秒(所有人可见)
            for (Map.Entry<UUID, PlayerData> e : gm.getAllPlayerData().entrySet()) {
                PlayerData pd = e.getValue();
                if (pd.getRole() != Role.RETOUR || !pd.isAlive() || addedPlayers.contains(e.getKey())) continue;
                if (pd.getRetourRevealedUntilTick() > currentTick) {
                    var player = world.method_8503().method_3760().method_14602(e.getKey());
                    if (player == null) continue;
                    markers.add(new PlayerMarker((int) player.method_23317(), (int) player.method_23321(), pd.getPlayerName(), 0xFF8800, player.method_36454())); // 橙色
                    addedPlayers.add(e.getKey());
                }
            }
            // 位置暴露的玩家(所有人可见): revealed=true(明牌阶段) 或 revealUntilTick(HELI揭露/NIHAO等) 或 LAYI飞行中
            for (Map.Entry<UUID, PlayerData> e : gm.getAllPlayerData().entrySet()) {
                PlayerData pd = e.getValue();
                if (!pd.isAlive() || addedPlayers.contains(e.getKey())) continue;
                if (pd.isRevealed() || pd.getRevealUntilTick() > currentTick
                        || (pd.getRole() == Role.LAYI && pd.isLayiFlying())) {
                    var player = world.method_8503().method_3760().method_14602(e.getKey());
                    if (player == null) continue;
                    int color = pd.isRevealed() ? 0xFF6600 : 0xFFFF00; // 橙=永久暴露, 黄=临时暴露
                    markers.add(new PlayerMarker((int) player.method_23317(), (int) player.method_23321(), pd.getPlayerName(), color, player.method_36454()));
                    addedPlayers.add(e.getKey());
                }
            }
            // 自己的位置始终显示
            {
                var selfPlayer = world.method_8503().method_3760().method_14602(requestingPlayer);
                if (selfPlayer != null && !addedPlayers.contains(requestingPlayer)) {
                    markers.add(new PlayerMarker((int) selfPlayer.method_23317(), (int) selfPlayer.method_23321(), selfPlayer.method_7334().name(), 0x00FF00, selfPlayer.method_36454()));
                    addedPlayers.add(requestingPlayer);
                }
            }

            dos.writeInt(markers.size());
            for (PlayerMarker m : markers) {
                dos.writeInt(m.x);
                dos.writeInt(m.z);
                byte[] nameBytes = m.name.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                dos.writeShort(nameBytes.length);
                dos.write(nameBytes);
                dos.writeInt(m.color);
                dos.writeFloat(m.yaw);
            }

            // ALLAND颜料区域数据(从PaintZone系统读取)
            Map<Long, Byte> paintedChunkColors = new HashMap<>();
            for (GameManager.PaintZone zone : gm.getPaintZones()) {
                for (class_2338 bp : zone.originalBlocks.keySet()) {
                    long ck = class_1923.method_8331(bp.method_10263() >> 4, bp.method_10260() >> 4);
                    byte paintByte = (byte)(zone.color + 1); // 0=红→1, 1=蓝→2, 2=绿→3, 3=黄→4
                    paintedChunkColors.putIfAbsent(ck, paintByte);
                }
            }
            dos.writeInt(paintedChunkColors.size());
            for (Map.Entry<Long, Byte> e : paintedChunkColors.entrySet()) {
                dos.writeShort(class_1923.method_8325(e.getKey()));
                dos.writeShort(class_1923.method_8332(e.getKey()));
                dos.writeByte(e.getValue());
            }

            // XLL玻璃迪克位置(已移除,写0保持二进制兼容)
            dos.writeInt(0);

            // JIEZU蛛网位置(所有玩家地图可见)
            List<int[]> webPositions = new ArrayList<>();
            for (PlayerData pd : gm.getAllPlayerData().values()) {
                if (pd.getRole() != Role.JIEZU) continue;
                for (class_2338 wp : pd.getWebPositions()) {
                    webPositions.add(new int[]{wp.method_10263(), wp.method_10260()});
                }
            }
            dos.writeInt(webPositions.size());
            for (int[] wp : webPositions) {
                dos.writeInt(wp[0]);
                dos.writeInt(wp[1]);
            }

            // POPCORN备用躯体位置(所有玩家地图可见)
            List<int[]> backupBodyPositions = new ArrayList<>();
            for (PlayerData pd : gm.getAllPlayerData().values()) {
                if (pd.getRole() != Role.POPCORN) continue;
                for (class_2338 bp : pd.getBackupBodies()) {
                    backupBodyPositions.add(new int[]{bp.method_10263(), bp.method_10260()});
                }
            }
            dos.writeInt(backupBodyPositions.size());
            for (int[] bp : backupBodyPositions) {
                dos.writeInt(bp[0]);
                dos.writeInt(bp[1]);
            }

            // DAMAI墓碑位置(所有玩家地图可见)
            List<int[]> tombstonePositions = new ArrayList<>();
            for (PlayerData pd : gm.getAllPlayerData().values()) {
                if (pd.getRole() != Role.DAMAI) continue;
                class_2338 tp = pd.getTombstonePos();
                if (tp != null && (pd.isDamaiWaitingForSkeleton() || pd.isSkeletonForm())) {
                    tombstonePositions.add(new int[]{tp.method_10263(), tp.method_10260()});
                }
            }
            dos.writeInt(tombstonePositions.size());
            for (int[] tp : tombstonePositions) {
                dos.writeInt(tp[0]);
                dos.writeInt(tp[1]);
            }

            // SHUBING画位置(所有玩家地图可见)
            List<int[]> paintingPositions = new ArrayList<>();
            for (PlayerData pd : gm.getAllPlayerData().values()) {
                if (pd.getRole() != Role.SHUBING) continue;
                for (PlayerData.ShubingPainting sp : pd.getPlacedPaintings()) {
                    if (sp.pos != null && sp.corridorIndex != -2) {
                        paintingPositions.add(new int[]{sp.pos.method_10263(), sp.pos.method_10260()});
                    }
                }
            }
            dos.writeInt(paintingPositions.size());
            for (int[] pp : paintingPositions) {
                dos.writeInt(pp[0]);
                dos.writeInt(pp[1]);
            }

            // Boss位置(预警+存活的Boss)
            List<int[]> bossPositions = new ArrayList<>(); // x, z, type(0=铁傀儡预警,1=铁傀儡存活,2=监守者存活)
            for (GameManager.BossData bd : gm.getPendingBossMarkers()) {
                if (bd.type.equals("iron_golem")) {
                    bossPositions.add(new int[]{bd.spawnPos.method_10263(), bd.spawnPos.method_10260(), 0});
                }
            }
            for (GameManager.BossData bd : gm.getActiveBosses()) {
                net.minecraft.class_1297 e = world.method_66347(bd.entityUuid);
                if (e != null && e.method_5805()) {
                    int bossType = bd.type.equals("iron_golem") ? 1 : 2;
                    bossPositions.add(new int[]{(int) e.method_23317(), (int) e.method_23321(), bossType});
                }
            }
            dos.writeInt(bossPositions.size());
            for (int[] bp : bossPositions) {
                dos.writeInt(bp[0]);
                dos.writeInt(bp[1]);
                dos.writeByte(bp[2]);
            }

            // LAYI导弹箱位置(所有玩家地图可见)
            List<int[]> layiChestPositions = new ArrayList<>();
            for (PlayerData pd : gm.getAllPlayerData().values()) {
                if (pd.getRole() != Role.LAYI) continue;
                for (class_2338 bp : pd.getLayiSpecialChestPositions()) {
                    layiChestPositions.add(new int[]{bp.method_10263(), bp.method_10260()});
                }
            }
            dos.writeInt(layiChestPositions.size());
            for (int[] lp : layiChestPositions) {
                dos.writeInt(lp[0]);
                dos.writeInt(lp[1]);
            }

            dos.flush();
            // gzip压缩减少传输量
            byte[] raw = baos.toByteArray();
            java.io.ByteArrayOutputStream gzBaos = new java.io.ByteArrayOutputStream();
            try (java.util.zip.GZIPOutputStream gz = new java.util.zip.GZIPOutputStream(gzBaos)) {
                gz.write(raw);
            }
            return gzBaos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return new byte[0];
        }
    }

    // 采样4x4子区块颜色: 每4x4子区取中心点采样
    // 优先使用 heightmap 快速定位地表Y, 失败时才fallback到线性扫描
    private static int[] sampleChunkSubColors(class_3218 world, class_2818 chunk) {
        int[] result = new int[16]; // 4x4 grid
        class_1923 cp = chunk.method_12004();
        int bottomY = world.method_31607();
        class_2338.class_2339 mp = new class_2338.class_2339();
        for (int sz = 0; sz < 4; sz++) {
            for (int sx = 0; sx < 4; sx++) {
                int wx = cp.method_8326() + sx * 4 + 2;
                int wz = cp.method_8328() + sz * 4 + 2;
                int localX = wx & 15;
                int localZ = wz & 15;
                // 优先使用 MOTION_BLOCKING_NO_LEAVES(忽略树叶) 获取地表Y
                int startY;
                try {
                    startY = chunk.method_12005(class_2902.class_2903.field_13203, localX, localZ);
                    if (startY < bottomY || startY > 319) startY = 319;
                } catch (Exception e) {
                    startY = 319;
                }
                class_2680 foundState = class_2246.field_10340.method_9564();
                for (int y = startY; y >= bottomY; y--) {
                    class_2680 state = chunk.method_8320(mp.method_10103(localX, y, localZ));
                    if (!state.method_26215()) {
                        foundState = state;
                        break;
                    }
                }
                result[sz * 4 + sx] = getBlockColor(foundState.method_26204());
            }
        }
        return result;
    }

    // 方块 → RGB颜色映射
    private static int getBlockColor(class_2248 block) {
        if (block == class_2246.field_10219) return 0x5D9B47;
        if (block == class_2246.field_10566 || block == class_2246.field_10253 || block == class_2246.field_28685) return 0x8B6B47;
        if (block == class_2246.field_10340 || block == class_2246.field_10115 || block == class_2246.field_10508 || block == class_2246.field_10474) return 0x7F7F7F;
        if (block == class_2246.field_28888) return 0x4A4A4A;
        if (block == class_2246.field_10382) return 0x3B6BB5;
        if (block == class_2246.field_10102 || block == class_2246.field_9979) return 0xDBC67B;
        if (block == class_2246.field_10255) return 0x8B8680;
        if (block == class_2246.field_10491 || block == class_2246.field_10477) return 0xF0F0F0;
        if (block == class_2246.field_10295 || block == class_2246.field_10225 || block == class_2246.field_10384) return 0xA0C8FF;
        if (block == class_2246.field_10431 || block == class_2246.field_10037 || block == class_2246.field_10511 || block == class_2246.field_10010) return 0x6B5030;
        if (block == class_2246.field_10503 || block == class_2246.field_9988 || block == class_2246.field_10539 || block == class_2246.field_10035) return 0x3A7A24;
        if (block == class_2246.field_10161 || block == class_2246.field_9975 || block == class_2246.field_10148) return 0xA08050;
        if (block == class_2246.field_10445 || block == class_2246.field_9989) return 0x6B6B6B;
        if (block == class_2246.field_10056 || block == class_2246.field_10065) return 0x737373;
        if (block == class_2246.field_28900) return 0x3D3D3D;
        if (block == class_2246.field_10058) return 0xA42C2C;
        if (block == class_2246.field_10011) return 0x2C2CA4;
        if (block == class_2246.field_10367) return 0x49A42C;
        if (block == class_2246.field_10085) return 0xD8D8D8;
        if (block == class_2246.field_10205) return 0xF0D020;
        if (block == class_2246.field_10201) return 0x40E8D0;
        if (block == class_2246.field_10164) return 0xD0500A;
        if (block == class_2246.field_10515) return 0x6B2020;
        if (block == class_2246.field_10460) return 0x9EA4B0;
        if (block == class_2246.field_10520) return 0x6B5030;
        if (block == class_2246.field_10402) return 0x8B7D8B;
        if (block == class_2246.field_10415) return 0x9E6246;
        if (block == class_2246.field_9987) return 0x353535;
        if (block == class_2246.field_27159) return 0x9B59B6; // 紫水晶(SHUBING画)
        // 木质建筑方块(村庄等)
        if (block == class_2246.field_10519 || block == class_2246.field_10436 || block == class_2246.field_10366) return 0xB89058;
        if (block == class_2246.field_10620 || block == class_2246.field_10020 || block == class_2246.field_10299) return 0x9A7040;
        if (block == class_2246.field_10563 || block == class_2246.field_10569 || block == class_2246.field_10408) return 0xA08050;
        if (block == class_2246.field_10119 || block == class_2246.field_10071 || block == class_2246.field_10257) return 0xA08050;
        if (block == class_2246.field_10149 || block == class_2246.field_10521 || block == class_2246.field_10352) return 0x8B6535;
        if (block == class_2246.field_10596 || block == class_2246.field_10392) return 0x6B6B6B;
        if (block == class_2246.field_10351 || block == class_2246.field_10131) return 0x737373;
        if (block == class_2246.field_10625 || block == class_2246.field_10252) return 0x6B6B6B;
        if (block == class_2246.field_10033 || block == class_2246.field_10285) return 0xC8E8F0;
        if (block == class_2246.field_10336 || block == class_2246.field_10099 || block == class_2246.field_16541) return 0xFFD040;
        if (block == class_2246.field_9980) return 0x8B6535;
        if (block == class_2246.field_10181 || block == class_2246.field_16333 || block == class_2246.field_16334) return 0x707070;
        if (block == class_2246.field_10034 || block == class_2246.field_16328) return 0x8B6535;
        if (block == class_2246.field_10362) return 0x6B4226;
        if (block == class_2246.field_10293) return 0xD4AA00;
        if (block == class_2246.field_10609 || block == class_2246.field_10247 || block == class_2246.field_10341) return 0x5D9B47;
        if (block == class_2246.field_10359) return 0xD4AA00;
        if (block == class_2246.field_16332) return 0xF0D020;
        if (block == class_2246.field_17563) return 0x6B5030;
        if (block == class_2246.field_10495) return 0x8B4513;
        if (block == class_2246.field_10504) return 0x8B6535;
        if (block == class_2246.field_10306 || block == class_2246.field_10533 || block == class_2246.field_37545) return 0x6B5030;
        if (block == class_2246.field_10335 || block == class_2246.field_10098 || block == class_2246.field_37551 || block == class_2246.field_28673) return 0x3A7A24;
        if (block == class_2246.field_10334 || block == class_2246.field_10218 || block == class_2246.field_37577 || block == class_2246.field_10075) return 0xA08050;
        if (block == class_2246.field_10211 || block == class_2246.field_41072) return 0x7AA02A;
        if (block == class_2246.field_28681) return 0x4D7A30;
        if (block == class_2246.field_37576 || block == class_2246.field_37547) return 0x5A4A3A;
        if (block == class_2246.field_16999) return 0x3A6A24;
        if (block == class_2246.field_10583 || block == class_2246.field_10182) return 0xFFD040;
        if (block == class_2246.field_10449 || block == class_2246.field_10430) return 0xCC2020;
        if (block == class_2246.field_9995 || block == class_2246.field_10086) return 0x4080CC;
        if (block == class_2246.field_10588) return 0x208020;
        if (block == class_2246.field_10029) return 0x287028;
        if (block == class_2246.field_10428) return 0x8B7355;
        if (block == class_2246.field_10424) return 0x80C040;
        if (block == class_2246.field_46283) return 0x40A020;
        if (block == class_2246.field_46282) return 0xD08020;
        if (block == class_2246.field_10580 || block == class_2246.field_10240) return 0x8B4513;
        if (block == class_2246.field_10167 || block == class_2246.field_10425 || block == class_2246.field_10025) return 0x8B8680;
        if (block == class_2246.field_10446 || block == class_2246.field_10466) return 0xE8E8E8;
        if (block == class_2246.field_10146 || block == class_2246.field_10106) return 0x1A1A1A;
        if (block == class_2246.field_10104 || block == class_2246.field_10089 || block == class_2246.field_10191) return 0x9B5B4A;
        if (block == class_2246.field_10360 || block == class_2246.field_10136) return 0x9A9A9A;
        if (block == class_2246.field_27165 || block == class_2246.field_47035) return 0x6A6A60;
        if (block == class_2246.field_27114) return 0xDDDDD0;
        if (block == class_2246.field_28049 || block == class_2246.field_28048) return 0x8B7355;
        if (block == class_2246.field_27119) return 0xC07040;
        // 默认灰色
        return 0x606060;
    }

    private record PlayerMarker(int x, int z, String name, int color, float yaw) {}
}
