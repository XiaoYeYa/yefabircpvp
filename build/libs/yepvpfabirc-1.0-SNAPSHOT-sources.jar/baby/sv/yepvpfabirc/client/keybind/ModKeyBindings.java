package baby.sv.yepvpfabirc.client.keybind;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ModKeyBindings {
    public static class_304 SKILL_Z;
    public static class_304 SKILL_X;
    public static class_304 SKILL_C;
    public static class_304 SKILL_V;
    public static class_304 MAP_KEY;

    private static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(net.minecraft.class_2960.method_60655("yepvpfabirc", "skills"));

    public static void register() {
        SKILL_Z = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.yepvpfabirc.skill_z",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_Z,
                CATEGORY
        ));

        SKILL_X = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.yepvpfabirc.skill_x",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_X,
                CATEGORY
        ));

        SKILL_C = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.yepvpfabirc.skill_c",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_C,
                CATEGORY
        ));

        SKILL_V = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.yepvpfabirc.skill_v",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_V,
                CATEGORY
        ));

        MAP_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.yepvpfabirc.map",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_M,
                CATEGORY
        ));

    }
}
