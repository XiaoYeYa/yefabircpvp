package baby.sv.yepvpfabirc.client.screen;

import baby.sv.yepvpfabirc.network.NetworkHandler;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class JaneShopScreen extends class_437 {

    private int bounty;
    private int power;
    private int quickCharge;
    private int multishot;

    private static final int BG_COLOR = 0xDD1A1A2E;
    private static final int HEADER_BG = 0xDD3B2D00;
    private static final int BORDER_COLOR = 0xFFD4A017;
    private static final int CARD_BG = 0xCC222244;
    private static final int CARD_HOVER = 0xCC333366;
    private static final int CARD_MAXED = 0xCC444444;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private static final int TEXT_GOLD = 0xFFFFAA00;
    private static final int TEXT_GREEN = 0xFF55FF55;
    private static final int TEXT_RED = 0xFFFF5555;
    private static final int TEXT_GRAY = 0xFF999999;
    private static final int TEXT_YELLOW = 0xFFFFFF55;

    private static final int PANEL_W = 340;
    private static final int CARD_W = 100;
    private static final int CARD_H = 120;
    private static final int CARD_GAP = 10;
    private static final int COST = 75;

    public JaneShopScreen(int bounty, int power, int quickCharge, int multishot) {
        super(class_2561.method_43470("赏金猎人商店"));
        this.bounty = bounty;
        this.power = power;
        this.quickCharge = quickCharge;
        this.multishot = multishot;
    }

    public void updateData(int bounty, int power, int quickCharge, int multishot) {
        this.bounty = bounty;
        this.power = power;
        this.quickCharge = quickCharge;
        this.multishot = multishot;
        method_41843();
    }

    @Override
    protected void method_25426() {
        int px = (this.field_22789 - PANEL_W) / 2;
        int cardsY = (this.field_22790 - CARD_H) / 2 + 10;
        int startX = px + (PANEL_W - 3 * CARD_W - 2 * CARD_GAP) / 2;

        // 力量升级按钮
        addUpgradeButton(startX, cardsY + CARD_H + 6, CARD_W, 0, power, 5);
        // 快速装填升级按钮
        addUpgradeButton(startX + CARD_W + CARD_GAP, cardsY + CARD_H + 6, CARD_W, 1, quickCharge, 3);
        // 多重射击升级按钮
        addUpgradeButton(startX + 2 * (CARD_W + CARD_GAP), cardsY + CARD_H + 6, CARD_W, 2, multishot, 1);

        // 关闭按钮
        this.method_37063(class_4185.method_46430(class_2561.method_43470("§c关闭"), btn -> method_25419())
                .method_46434(this.field_22789 / 2 - 40, cardsY + CARD_H + 36, 80, 20)
                .method_46431());
    }

    private void addUpgradeButton(int x, int y, int w, int type, int currentLevel, int maxLevel) {
        boolean maxed = currentLevel >= maxLevel;
        boolean canAfford = bounty >= COST;
        String label = maxed ? "§7已满级" : (canAfford ? "§a升级 §e-" + COST : "§c赏金不足");
        this.method_37063(class_4185.method_46430(class_2561.method_43470(label), btn -> {
            if (!maxed && canAfford) {
                ClientPlayNetworking.send(new NetworkHandler.JaneShopBuyPayload(type));
            }
        }).method_46434(x, y, w, 18).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // 半透明背景
        ctx.method_25294(0, 0, this.field_22789, this.field_22790, 0xBB000000);

        int px = (this.field_22789 - PANEL_W) / 2;
        int cardsY = (this.field_22790 - CARD_H) / 2 + 10;
        int panelTop = cardsY - 50;
        int panelBottom = cardsY + CARD_H + 64;

        // 面板背景+边框
        ctx.method_25294(px, panelTop, px + PANEL_W, panelBottom, BG_COLOR);
        drawBorder(ctx, px, panelTop, PANEL_W, panelBottom - panelTop, BORDER_COLOR);

        // 标题栏
        ctx.method_25294(px + 1, panelTop + 1, px + PANEL_W - 1, panelTop + 28, HEADER_BG);
        String title = "⚔ 赏金猎人商店 ⚔";
        int titleW = this.field_22793.method_1727(title);
        ctx.method_51433(this.field_22793, title, px + (PANEL_W - titleW) / 2, panelTop + 9, TEXT_GOLD, true);

        // 赏金显示
        String bountyText = "§6赏金: §e" + bounty;
        int bountyW = this.field_22793.method_1727(bountyText);
        ctx.method_51433(this.field_22793, bountyText, px + (PANEL_W - bountyW) / 2, panelTop + 33, TEXT_GOLD, true);

        // 三张升级卡片
        int startX = px + (PANEL_W - 3 * CARD_W - 2 * CARD_GAP) / 2;

        drawUpgradeCard(ctx, startX, cardsY, CARD_W, CARD_H, mouseX, mouseY,
                "§b⚡ 力量", "Power", power, 5,
                "弩箭伤害增加", "每级+0.5心");

        drawUpgradeCard(ctx, startX + CARD_W + CARD_GAP, cardsY, CARD_W, CARD_H, mouseX, mouseY,
                "§a⚡ 快速装填", "Quick Charge", quickCharge, 3,
                "装填时间缩短", "每级-0.25秒");

        drawUpgradeCard(ctx, startX + 2 * (CARD_W + CARD_GAP), cardsY, CARD_W, CARD_H, mouseX, mouseY,
                "§d⚡ 多重射击", "Multishot", multishot, 1,
                "同时发射3支箭", "最大1级");

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    private void drawUpgradeCard(class_332 ctx, int x, int y, int w, int h,
                                  int mouseX, int mouseY,
                                  String name, String engName, int level, int maxLevel,
                                  String desc1, String desc2) {
        boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        boolean maxed = level >= maxLevel;

        int bg = maxed ? CARD_MAXED : (hovered ? CARD_HOVER : CARD_BG);
        ctx.method_25294(x, y, x + w, y + h, bg);

        int borderCol = maxed ? TEXT_GRAY : BORDER_COLOR;
        drawBorder(ctx, x, y, w, h, borderCol);

        // 名称
        int nameW = this.field_22793.method_1727(name);
        ctx.method_51433(this.field_22793, name, x + (w - nameW) / 2, y + 8, TEXT_WHITE, true);

        // 英文名
        int engW = this.field_22793.method_1727(engName);
        ctx.method_51433(this.field_22793, engName, x + (w - engW) / 2, y + 22, TEXT_GRAY, false);

        // 等级条
        int barX = x + 10;
        int barY = y + 38;
        int barW = w - 20;
        int barH = 8;
        ctx.method_25294(barX, barY, barX + barW, barY + barH, 0xFF333333);
        if (maxLevel > 0) {
            int filledW = (int)((float) level / maxLevel * barW);
            int barColor = maxed ? 0xFF55FF55 : 0xFFFFAA00;
            ctx.method_25294(barX, barY, barX + filledW, barY + barH, barColor);
        }

        // 等级文字
        String levelText = maxed ? "§a满级 " + level + "/" + maxLevel : "§e" + level + "/" + maxLevel;
        int lvlW = this.field_22793.method_1727(levelText);
        ctx.method_51433(this.field_22793, levelText, x + (w - lvlW) / 2, y + 52, TEXT_WHITE, true);

        // 描述
        int d1W = this.field_22793.method_1727(desc1);
        ctx.method_51433(this.field_22793, desc1, x + (w - d1W) / 2, y + 70, TEXT_GRAY, false);
        int d2W = this.field_22793.method_1727(desc2);
        ctx.method_51433(this.field_22793, desc2, x + (w - d2W) / 2, y + 82, TEXT_GRAY, false);

        // 费用
        if (!maxed) {
            String costText = "§6" + COST + " 赏金";
            int cW = this.field_22793.method_1727(costText);
            int costColor = bounty >= COST ? TEXT_GREEN : TEXT_RED;
            ctx.method_51433(this.field_22793, costText, x + (w - cW) / 2, y + 100, costColor, true);
        } else {
            String maxText = "§7已满级";
            int mW = this.field_22793.method_1727(maxText);
            ctx.method_51433(this.field_22793, maxText, x + (w - mW) / 2, y + 100, TEXT_GRAY, true);
        }
    }

    private void drawBorder(class_332 ctx, int x, int y, int w, int h, int color) {
        ctx.method_25294(x, y, x + w, y + 1, color);
        ctx.method_25294(x, y + h - 1, x + w, y + h, color);
        ctx.method_25294(x, y, x + 1, y + h, color);
        ctx.method_25294(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean method_25422() {
        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
