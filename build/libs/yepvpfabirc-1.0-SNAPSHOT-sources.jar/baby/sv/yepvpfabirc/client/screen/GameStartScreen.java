package baby.sv.yepvpfabirc.client.screen;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class GameStartScreen extends class_437 {

    private final String roleName;
    private final String roleDesc;
    private final int lives;
    private final String playerName;
    private final List<String> rules;

    // Colors
    private static final int BG_COLOR = 0xDD1A1A2E;
    private static final int HEADER_BG = 0xDD0D0D3B;
    private static final int BORDER_COLOR = 0xFF2ECC71;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private static final int TEXT_GREEN = 0xFF2ECC71;
    private static final int TEXT_YELLOW = 0xFFF1C40F;
    private static final int TEXT_GRAY = 0xFFBBBBBB;

    public GameStartScreen(String jsonData) {
        super(class_2561.method_43470("游戏开始"));
        JsonObject json = JsonParser.parseString(jsonData).getAsJsonObject();
        this.roleName = json.get("roleName").getAsString();
        this.roleDesc = json.get("roleDesc").getAsString();
        this.lives = json.get("lives").getAsInt();
        this.playerName = json.get("playerName").getAsString();
        this.rules = new ArrayList<>();
        JsonArray rulesArr = json.getAsJsonArray("rules");
        for (int i = 0; i < rulesArr.size(); i++) {
            rules.add(rulesArr.get(i).getAsString());
        }
    }

    @Override
    protected void method_25426() {
        int buttonW = 120;
        int buttonH = 20;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("§a确认开始"), btn -> method_25419())
                .method_46434(this.field_22789 / 2 - buttonW / 2, this.field_22790 - 40, buttonW, buttonH)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Dark overlay
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xAA000000);

        int panelW = 320;
        int panelH = 240;
        int px = (this.field_22789 - panelW) / 2;
        int py = (this.field_22790 - panelH) / 2 - 10;

        // Panel background
        context.method_25294(px, py, px + panelW, py + panelH, BG_COLOR);
        // Border
        context.method_25294(px, py, px + panelW, py + 1, BORDER_COLOR);
        context.method_25294(px, py + panelH - 1, px + panelW, py + panelH, BORDER_COLOR);
        context.method_25294(px, py, px + 1, py + panelH, BORDER_COLOR);
        context.method_25294(px + panelW - 1, py, px + panelW, py + panelH, BORDER_COLOR);

        // Header
        context.method_25294(px + 1, py + 1, px + panelW - 1, py + 26, HEADER_BG);
        String title = "⚔ 夜喵喵愚人节大乱斗 ⚔";
        int titleW = this.field_22793.method_1727(title);
        context.method_51433(this.field_22793, title, px + (panelW - titleW) / 2, py + 8, TEXT_GREEN, true);

        // Player name and role
        int y = py + 34;
        context.method_51433(this.field_22793, "§e玩家: §f" + playerName, px + 12, y, TEXT_WHITE, true);
        y += 16;
        context.method_51433(this.field_22793, "§a职业: §e" + roleName, px + 12, y, TEXT_GREEN, true);
        y += 14;
        context.method_51433(this.field_22793, "§7" + roleDesc, px + 12, y, TEXT_GRAY, false);
        y += 14;

        String heartsStr = "§c生命: ";
        for (int i = 0; i < Math.min(lives, 10); i++) heartsStr += "❤";
        context.method_51433(this.field_22793, heartsStr, px + 12, y, 0xFFE74C3C, true);
        y += 20;

        // Divider
        context.method_25294(px + 10, y, px + panelW - 10, y + 1, 0x55FFFFFF);
        y += 8;

        // Rules
        context.method_51433(this.field_22793, "§e§l游戏规则:", px + 12, y, TEXT_YELLOW, true);
        y += 14;
        for (String rule : rules) {
            context.method_51433(this.field_22793, "  • " + rule, px + 12, y, TEXT_WHITE, false);
            y += 12;
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25422() {
        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
