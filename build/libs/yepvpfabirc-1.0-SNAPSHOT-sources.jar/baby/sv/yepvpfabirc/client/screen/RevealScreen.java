package baby.sv.yepvpfabirc.client.screen;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RevealScreen extends class_437 {

    private final List<PlayerEntry> playerEntries;

    private static final int BG_COLOR = 0xDD1A1A2E;
    private static final int HEADER_BG = 0xDD3B0D0D;
    private static final int BORDER_COLOR = 0xFFE74C3C;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private static final int TEXT_GREEN = 0xFF2ECC71;
    private static final int TEXT_YELLOW = 0xFFF1C40F;
    private static final int TEXT_RED = 0xFFE74C3C;
    private static final int TEXT_GRAY = 0xFF999999;
    private static final int ROW_ALT = 0x22FFFFFF;

    public RevealScreen(String jsonData) {
        super(class_2561.method_43470("明牌"));
        this.playerEntries = new ArrayList<>();
        JsonObject json = JsonParser.parseString(jsonData).getAsJsonObject();
        JsonArray playersArr = json.getAsJsonArray("players");
        for (int i = 0; i < playersArr.size(); i++) {
            JsonObject p = playersArr.get(i).getAsJsonObject();
            playerEntries.add(new PlayerEntry(
                    p.get("name").getAsString(),
                    p.get("roleName").getAsString(),
                    p.get("roleDesc").getAsString(),
                    p.get("alive").getAsBoolean(),
                    p.get("lives").getAsInt(),
                    p.get("kills").getAsInt()
            ));
        }
    }

    @Override
    protected void method_25426() {
        int buttonW = 120;
        int buttonH = 20;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("§a确认"), btn -> method_25419())
                .method_46434(this.field_22789 / 2 - buttonW / 2, this.field_22790 - 35, buttonW, buttonH)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xBB000000);

        int panelW = 360;
        int rowH = 28;
        int headerH = 30;
        int panelH = headerH + playerEntries.size() * rowH + 16;
        int maxH = this.field_22790 - 80;
        if (panelH > maxH) panelH = maxH;

        int px = (this.field_22789 - panelW) / 2;
        int py = (this.field_22790 - panelH) / 2 - 15;

        // Panel
        context.method_25294(px, py, px + panelW, py + panelH, BG_COLOR);
        context.method_25294(px, py, px + panelW, py + 1, BORDER_COLOR);
        context.method_25294(px, py + panelH - 1, px + panelW, py + panelH, BORDER_COLOR);
        context.method_25294(px, py, px + 1, py + panelH, BORDER_COLOR);
        context.method_25294(px + panelW - 1, py, px + panelW, py + panelH, BORDER_COLOR);

        // Header
        context.method_25294(px + 1, py + 1, px + panelW - 1, py + headerH, HEADER_BG);
        String title = "⚠ 明牌阶段 - 所有职业已公开 ⚠";
        int titleW = this.field_22793.method_1727(title);
        context.method_51433(this.field_22793, title, px + (panelW - titleW) / 2, py + 10, TEXT_RED, true);

        // Player list
        int y = py + headerH + 4;
        for (int i = 0; i < playerEntries.size(); i++) {
            PlayerEntry e = playerEntries.get(i);
            if (y + rowH > py + panelH - 4) break;

            // Alternating row bg
            if (i % 2 == 0) {
                context.method_25294(px + 2, y, px + panelW - 2, y + rowH, ROW_ALT);
            }

            int textColor = e.alive ? TEXT_WHITE : TEXT_GRAY;

            // Name
            context.method_51433(this.field_22793, e.name, px + 10, y + 4, textColor, true);

            // Role
            context.method_51433(this.field_22793, "§e" + e.roleName, px + 100, y + 4, TEXT_YELLOW, true);

            // Status
            String status = e.alive ? "§a存活 ❤" + e.lives : "§c已淘汰";
            context.method_51433(this.field_22793, status, px + 240, y + 4, e.alive ? TEXT_GREEN : TEXT_RED, true);

            // Kills
            context.method_51433(this.field_22793, "§7击杀:" + e.kills, px + 310, y + 4, TEXT_GRAY, false);

            // Desc (second line)
            String desc = e.roleDesc;
            if (desc.length() > 45) desc = desc.substring(0, 45) + "..";
            context.method_51433(this.field_22793, "§7" + desc, px + 14, y + 16, TEXT_GRAY, false);

            y += rowH;
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25422() {
        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private record PlayerEntry(String name, String roleName, String roleDesc, boolean alive, int lives, int kills) {}
}
