package baby.sv.yepvpfabirc;

import baby.sv.yepvpfabirc.command.AprilFoolsCommand;
import baby.sv.yepvpfabirc.command.PlayerCommands;
import baby.sv.yepvpfabirc.command.VoteCommand;
import baby.sv.yepvpfabirc.config.AprilFoolsConfig;
import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import baby.sv.yepvpfabirc.network.HudSyncManager;
import baby.sv.yepvpfabirc.network.NetworkHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1269;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import baby.sv.yepvpfabirc.skill.SkillHandler;
import java.util.Set;

public class Yepvpfabirc implements ModInitializer {

    private int hudSyncTimer = 0;

    private static final Set<class_2248> PROTECTED_ORES = Set.of(
        class_2246.field_10418, class_2246.field_29219,
        class_2246.field_10212, class_2246.field_29027,
        class_2246.field_27120, class_2246.field_29221,
        class_2246.field_10571, class_2246.field_29026,
        class_2246.field_10442, class_2246.field_29029
    );
    private static final Set<class_2248> PROTECTED_ORES_2 = Set.of(
        class_2246.field_10013, class_2246.field_29220,
        class_2246.field_10090, class_2246.field_29028,
        class_2246.field_10080, class_2246.field_29030,
        class_2246.field_23077, class_2246.field_10213,
        class_2246.field_22109
    );
    private static final Set<class_2248> PROTECTED_MINERAL_BLOCKS = Set.of(
        class_2246.field_10085, class_2246.field_10205, class_2246.field_10201,
        class_2246.field_10234, class_2246.field_10441, class_2246.field_10002,
        class_2246.field_27119, class_2246.field_22108, class_2246.field_10381,
        class_2246.field_33508, class_2246.field_33510, class_2246.field_33509
    );

    @Override
    public void onInitialize() {
        ModSounds.register();
        NetworkHandler.registerServer();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            AprilFoolsCommand.register(dispatcher);
            PlayerCommands.register(dispatcher);
            VoteCommand.register(dispatcher);
        });

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            GameManager.getInstance().setServer(server);
            AprilFoolsConfig config = new AprilFoolsConfig();
            config.load();
            config.applyToGameManager();
            System.out.println("[YePvP] 愚人节大乱斗模组已加载！使用 /af start 开始游戏");
        });

        // 方块破坏保护
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (!GameManager.getInstance().isGameActive()) return true;
            // 噬元兽异次元空间: 被困玩家不可破坏任何方块
            if (player instanceof net.minecraft.class_3222 sp) {
                PlayerData pd = GameManager.getInstance().getPlayerData(sp.method_5667());
                if (pd != null) {
                    for (PlayerData ownerData : GameManager.getInstance().getAllPlayerData().values()) {
                        if (ownerData.getRole() == Role.YOUZHA && ownerData.getYouzhaTrappedPlayers().contains(sp.method_5667())) {
                            return false;
                        }
                    }
                }
            }
            // XLL玻璃建筑不可破坏
            if (state.method_27852(class_2246.field_10033) || state.method_27852(class_2246.field_10171)) {
                if (SkillHandler.isXllProtectedBlock(pos)) {
                    player.method_7353(class_2561.method_43470("§c这是XLL的玻璃建筑，无法破坏！"), true);
                    return false;
                }
            }
            // 禁止破坏箱子
            class_2248 block = state.method_26204();
            if (state.method_27852(class_2246.field_10034) || state.method_27852(class_2246.field_10380)) {
                player.method_7353(class_2561.method_43470("§c箱子不可破坏！"), true);
                return false;
            }
            // 禁止挖掘矿物原矿和矿物块
            if (PROTECTED_ORES.contains(block) || PROTECTED_ORES_2.contains(block) || PROTECTED_MINERAL_BLOCKS.contains(block)) {
                player.method_7353(class_2561.method_43470("§c矿物和矿物块不可挖掘！"), true);
                return false;
            }
            return true;
        });

        // 大厅物品右键拦截
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.method_8608() && player instanceof class_3222 sp) {
                if (!GameManager.getInstance().isGameActive()) {
                    boolean handled = GameManager.getInstance().getLobbyManager().handleLobbyItemUse(sp);
                    if (handled) {
                        return class_1269.field_5812;
                    }
                }
            }
            return class_1269.field_5811;
        });

        // 玩家加入时发送版本检查
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            server.execute(() -> {
                NetworkHandler.sendVersionCheck(handler.method_32311());
            });
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            GameManager gm = GameManager.getInstance();
            gm.tick();

            // 大厅系统tick(游戏未进行时维护大厅玩家状态)
            if (!gm.isGameActive()) {
                gm.getLobbyManager().tick(server);
            }

            // 版本检查超时踢出
            NetworkHandler.tickVersionChecks(server);

            if (gm.isGameActive()) {
                hudSyncTimer++;
                if (hudSyncTimer >= 20) {
                    hudSyncTimer = 0;
                    HudSyncManager.syncAllPlayers(server);
                }
            }
        });
    }
}
