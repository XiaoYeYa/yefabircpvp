package baby.sv.yepvpfabirc;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class ModSounds {
    public static final class_2960 EXPLOSION_ID = class_2960.method_60655("yepvpfabirc", "explosion");
    public static final class_3414 EXPLOSION = class_3414.method_47908(EXPLOSION_ID);

    public static final class_2960 CIALLO_ID = class_2960.method_60655("yepvpfabirc", "ciallo");
    public static final class_3414 CIALLO = class_3414.method_47908(CIALLO_ID);

    public static final class_2960 GURENGE_ID = class_2960.method_60655("yepvpfabirc", "gurenge");
    public static final class_3414 GURENGE = class_3414.method_47908(GURENGE_ID);

    public static void register() {
        class_2378.method_10230(class_7923.field_41172, EXPLOSION_ID, EXPLOSION);
        class_2378.method_10230(class_7923.field_41172, CIALLO_ID, CIALLO);
        class_2378.method_10230(class_7923.field_41172, GURENGE_ID, GURENGE);
    }
}
