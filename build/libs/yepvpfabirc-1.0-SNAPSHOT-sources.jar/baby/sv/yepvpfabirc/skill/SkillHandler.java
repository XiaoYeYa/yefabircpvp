package baby.sv.yepvpfabirc.skill;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import java.util.*;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8113;

public class SkillHandler {

    // 左下角提示(替代actionbar)
    private static void tip(class_3222 player, String msg) {
        GameManager.getInstance().sendTip(player, msg);
    }

    // Cooldowns in ticks (20 ticks = 1 second)
    private static final long XLL_CUBE_COOLDOWN = 3600;     // 3分钟
    private static final long XLL_ROAD_COOLDOWN = 2400;     // 2分钟
    private static final long NIHAO_COOLDOWN = 2400;         // 2分钟
    private static final long ST_CIALLO_COOLDOWN = 2400;     // 2分钟
    private static final long ST_SONIC_COOLDOWN = 2400;      // 2分钟
    private static final long RETOUR_REVIVE_COOLDOWN = 600;  // 30秒
    private static final long MACHA_COOLDOWN = 600;          // 30秒
    private static final long DAMAI_TP_COOLDOWN = 600;       // 30秒
    private static final long DASHA_RAIN_COOLDOWN = 6000;    // 5分钟
    private static final long HELI_TP_COOLDOWN = 1200;       // 1分钟
    private static final long HELI_EYE_COOLDOWN = 3600;      // 3分钟
    private static final long JIEZU_NIGHT_COOLDOWN = 6000;   // 5分钟
    private static final long JIEZU_WEB_TP_COOLDOWN = 2400;  // 2分钟
    // ALLAND: 颜料弹由charge系统管理, 无独立CD
    private static final long YOUZHA_ULTIMATE_COOLDOWN = 2400; // 2分钟
    private static final long YOUZHA_EAT_COOLDOWN = 600;       // 30秒
    private static final long POPCORN_LASER_COOLDOWN = 2400; // 2分钟
    private static final long SANCHEZ_HEAL_COOLDOWN = 600;   // 30秒
    private static final long SANCHEZ_HUNT_COOLDOWN = 2400;  // 2分钟
    // MAYPOOR
    private static final long MAYPOOR_FLIGHT_COOLDOWN = 600;  // 30秒
    private static final long MAYPOOR_FLIGHT_DURATION = 200;  // 10秒
    private static final long MAYPOOR_SLAM_COOLDOWN = 200;    // 10秒

    public static void handleSkill(class_3222 player, PlayerData data, int skillSlot) {
        switch (data.getRole()) {
            case XLL -> handleXllSkill(player, data, skillSlot);
            case JIEZU -> handleJiezuSkill(player, data, skillSlot);
            case DAMAI -> handleDamaiSkill(player, data, skillSlot);
            case DASHA -> handleDashaSkill(player, data, skillSlot);
            case JVJV -> handleJvjvSkill(player, data, skillSlot);
            case ST -> handleStSkill(player, data, skillSlot);
            case BOBBY -> handleBobbySkill(player, data, skillSlot);
            case RETOUR -> handleRetourSkill(player, data, skillSlot);
            case ALLAND -> handleAllandSkill(player, data, skillSlot);
            case MACHA -> handleMachaSkill(player, data, skillSlot);
            case HELI -> handleHeliSkill(player, data, skillSlot);
            case POPCORN -> handlePopcornSkill(player, data, skillSlot);
            case SANCHEZ -> handleSanchezSkill(player, data, skillSlot);
            case SHUBING -> handleShubingSkill(player, data, skillSlot);
            case NIHAO -> handleNihaoSkill(player, data, skillSlot);
            case JANE -> handleJaneSkill(player, data, skillSlot);
            case YOUZHA -> handleYouzhaSkill(player, data, skillSlot);
            case LAYI -> handleLayiSkill(player, data, skillSlot);
            case MAYPOOR -> handleMaypoorSkill(player, data, skillSlot);
            default -> {}
        }
    }

    // ==================== XLL: 立体艺术 ====================
    // Z: 生成边长10无法破坏玻璃正方体（5分钟冷却，8秒持续，内部失明+10%maxHP真伤/秒）
    // X: 向前生成3x50永久玻璃长道（2分钟冷却，只限东西南北方向）
    private static void handleXllSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();

        if (skillSlot == 0) {
            // Z键: 玻璃正方体
            if (currentTick - data.getLastSkillZTime() < XLL_CUBE_COOLDOWN) {
                long remaining = (XLL_CUBE_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
                tip(player, "§c玻璃正方体冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillZTime(currentTick);

            class_2338 center = player.method_24515();
            class_3218 world = player.method_51469();
            int half = 5; // 边长10，半径5

            for (int x = -half; x <= half; x++) {
                for (int y = -half; y <= half; y++) {
                    for (int z = -half; z <= half; z++) {
                        if (Math.abs(x) == half || Math.abs(y) == half || Math.abs(z) == half) {
                            class_2338 bp = center.method_10069(x, y, z);
                            world.method_8501(bp, class_2246.field_10033.method_9564());
                        }
                    }
                }
            }

            data.setGlassCubeActive(true);
            data.setGlassCubeCenter(center);
            data.setGlassCubeEndTick(currentTick + 160); // 8秒

            GameManager.getInstance().broadcastMessage("§b§l[立体艺术] §r§e" + player.method_7334().name() + " §b生成了玻璃正方体！范围内玩家将受到失明和伤害！");

        } else if (skillSlot == 1) {
            // X键: 玻璃长道
            if (currentTick - data.getLastSkillXTime() < XLL_ROAD_COOLDOWN) {
                long remaining = (XLL_ROAD_COOLDOWN - (currentTick - data.getLastSkillXTime())) / 20;
                tip(player, "§c玻璃长道冷却中... §e" + remaining + "s");
                return;
            }

            // 只允许东西南北方向(不能斜向或垂直)
            float yaw = player.method_36454() % 360;
            if (yaw < 0) yaw += 360;
            int dx = 0, dz = 0;
            // 南=0, 西=90, 北=180, 东=270
            if (yaw >= 315 || yaw < 45) { dz = 1; } // 南
            else if (yaw >= 45 && yaw < 135) { dx = -1; } // 西
            else if (yaw >= 135 && yaw < 225) { dz = -1; } // 北
            else { dx = 1; } // 东

            data.setLastSkillXTime(currentTick);

            class_3218 world = player.method_51469();
            class_2338 start = player.method_24515();
            int roadLength = 50;
            int roadWidth = 3; // 3格宽(中心+两侧1)

            // 确定宽度方向的偏移
            int wx = (dz != 0) ? 1 : 0; // 前进Z方向→宽度沿X
            int wz = (dx != 0) ? 1 : 0; // 前进X方向→宽度沿Z

            int placed = 0;
            for (int i = 0; i < roadLength; i++) {
                for (int w = -1; w <= 1; w++) {
                    class_2338 roadPos = start.method_10069(dx * i + wx * w, 0, dz * i + wz * w);
                    world.method_8501(roadPos, class_2246.field_10033.method_9564());
                    data.getGlassRoadBlocks().add(roadPos);
                    placed++;

                    // 清空上方2格(保护特殊方块)
                    for (int dy = 1; dy <= 2; dy++) {
                        class_2338 above = roadPos.method_10086(dy);
                        if (!isXllRoadProtectedBlock(world.method_8320(above))) {
                            world.method_8501(above, class_2246.field_10124.method_9564());
                        }
                    }
                }
            }

            String dirName = (dz > 0) ? "南" : (dz < 0) ? "北" : (dx > 0) ? "东" : "西";
            GameManager.getInstance().broadcastMessage("§b§l[立体艺术] §r§e" + player.method_7334().name() + " §b向" + dirName + "展开了50格玻璃长道！");
            tip(player, "§b玻璃长道已生成！方向: §e" + dirName + " §b共" + placed + "格");
        }
    }

    // 玻璃长道上方清除时不清空的方块(只保留基岩)
    private static boolean isXllRoadProtectedBlock(net.minecraft.class_2680 state) {
        if (state.method_26215()) return true;
        if (state.method_26204() == class_2246.field_9987) return true;
        return false;
    }

    // 检测某个位置是否属于XLL的任何不可破坏建筑(正方体/玻璃长道)
    public static boolean isXllProtectedBlock(class_2338 pos) {
        GameManager gm = GameManager.getInstance();
        for (PlayerData pd : gm.getAllPlayerData().values()) {
            if (pd.getRole() != Role.XLL) continue;
            // 检查活跃的正方体
            if (pd.isGlassCubeActive() && pd.getGlassCubeCenter() != null) {
                class_2338 center = pd.getGlassCubeCenter();
                int dx = Math.abs(pos.method_10263() - center.method_10263());
                int dy = Math.abs(pos.method_10264() - center.method_10264());
                int dz = Math.abs(pos.method_10260() - center.method_10260());
                if (dx <= 5 && dy <= 5 && dz <= 5 && (dx == 5 || dy == 5 || dz == 5)) {
                    return true;
                }
            }
            // 检查玻璃长道
            if (pd.getGlassRoadBlocks().contains(pos)) {
                return true;
            }
        }
        return false;
    }

    // 检查某个位置是否属于某个XLL的玻璃(正方体或长道)
    public static boolean isXllGlassBlock(class_2338 pos) {
        return isXllProtectedBlock(pos);
    }

    // 找到某个玻璃长道方块的所有者
    public static PlayerData findGlassRoadOwner(class_2338 pos) {
        GameManager gm = GameManager.getInstance();
        for (PlayerData pd : gm.getAllPlayerData().values()) {
            if (pd.getRole() != Role.XLL) continue;
            if (pd.getGlassRoadBlocks().contains(pos)) return pd;
        }
        return null;
    }

    // 清除XLL玻璃正方体
    public static void removeGlassCube(class_3218 world, class_2338 center) {
        int half = 5;
        for (int x = -half; x <= half; x++) {
            for (int y = -half; y <= half; y++) {
                for (int z = -half; z <= half; z++) {
                    if (Math.abs(x) == half || Math.abs(y) == half || Math.abs(z) == half) {
                        class_2338 bp = center.method_10069(x, y, z);
                        if (world.method_8320(bp).method_26204() == class_2246.field_10033) {
                            world.method_8501(bp, class_2246.field_10124.method_9564());
                        }
                    }
                }
            }
        }
    }

    // 清除XLL所有玻璃长道
    public static void removeAllGlassRoads(class_3218 world, PlayerData ownerData) {
        for (class_2338 pos : new HashSet<>(ownerData.getGlassRoadBlocks())) {
            if (world.method_8320(pos).method_26204() == class_2246.field_10033) {
                world.method_8501(pos, class_2246.field_10124.method_9564());
            }
        }
        ownerData.getGlassRoadBlocks().clear();
    }

    // ==================== JIEZU: 节足动物 ====================
    // Z: 强行切换至夜晚+所有人失明30秒+30秒后回白天(5分钟CD), X: 传送至蛛网(2分钟CD,循环选择)
    private static void handleJiezuSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();
        if (skillSlot == 0) { // Z: 强制夜晚
            if (currentTick - data.getLastSkillZTime() < JIEZU_NIGHT_COOLDOWN) {
                long remaining = (JIEZU_NIGHT_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
                tip(player, "§c技能冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillZTime(currentTick);
            class_3218 world = player.method_51469();
            world.method_29199(18000); // 午夜
            // 所有人失明30秒(JIEZU自己除外)
            for (class_3222 p : world.method_18456()) {
                if (p.method_5667().equals(player.method_5667())) continue;
                p.method_6092(new class_1293(class_1294.field_5919, 600, 0, false, false, true));
            }
            // 30秒后回白天
            data.setJiezuNightEndTick(currentTick + 600);
            GameManager.getInstance().broadcastMessage("§8§l[节足动物] §r§e" + player.method_7334().name() + " §8强制切换到了夜晚！所有人失明30秒！30秒后恢复白天。");
        } else if (skillSlot == 1) { // X: 切换选中的蛛网(1/2/3循环)
            if (data.getWebPositions().isEmpty()) {
                tip(player, "§c没有放置过蛛网！");
                return;
            }
            int nextIdx = (data.getJiezuWebTpIndex() + 1) % data.getWebPositions().size();
            data.setJiezuWebTpIndex(nextIdx);
            class_2338 target = data.getWebPositions().get(nextIdx);
            tip(player, "§e已选中蛛网#" + (nextIdx + 1) + " §7(" + target.method_10263() + "," + target.method_10264() + "," + target.method_10260() + ") §e按V键传送");
        } else if (skillSlot == 2) { // V: 传送到选中的蛛网
            if (data.getWebPositions().isEmpty()) {
                tip(player, "§c没有放置过蛛网！");
                return;
            }
            if (currentTick - data.getLastSkillXTime() < JIEZU_WEB_TP_COOLDOWN) {
                long remaining = (JIEZU_WEB_TP_COOLDOWN - (currentTick - data.getLastSkillXTime())) / 20;
                tip(player, "§c传送冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillXTime(currentTick);
            int idx = data.getJiezuWebTpIndex() % data.getWebPositions().size();
            class_2338 target = data.getWebPositions().get(idx);
            class_3218 world = player.method_51469();
            // 在蛛网周围8方向找安全位置(2格空气+下方实心), 避免卡墙
            int[][] offsets = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
            class_2338 safePos = null;
            for (int[] off : offsets) {
                class_2338 check = target.method_10069(off[0], 0, off[1]);
                if (world.method_8320(check).method_26215()
                        && world.method_8320(check.method_10084()).method_26215()
                        && !world.method_8320(check.method_10074()).method_26215()) {
                    safePos = check;
                    break;
                }
            }
            // 兜底: 垂直向上找空气
            if (safePos == null) {
                for (int dy = 0; dy <= 5; dy++) {
                    class_2338 check = target.method_10069(0, dy, 0);
                    if (world.method_8320(check).method_26215() && world.method_8320(check.method_10084()).method_26215()) {
                        safePos = check;
                        break;
                    }
                }
            }
            if (safePos == null) safePos = target.method_10084(); // 最终兜底
            player.method_48105(world, safePos.method_10263() + 0.5, safePos.method_10264(), safePos.method_10260() + 0.5, Set.of(), player.method_36454(), player.method_36455(), false);
            tip(player, "§a已传送至蛛网#" + (idx + 1) + "！(" + target.method_10263() + "," + target.method_10264() + "," + target.method_10260() + ")");
        }
    }

    // ==================== YUSUI: 男娘后宫 ====================
    // 雪球命中时调用（由SnowballHitMixin触发）
    // 只在场上没有男娘时才能转化
    public static void onYusuiSnowballHit(class_3222 yusui, class_3222 target) {
        GameManager gm = GameManager.getInstance();
        PlayerData data = gm.getPlayerData(yusui.method_5667());
        if (data == null || data.getRole() != Role.YUSUI) return;
        PlayerData targetData = gm.getPlayerData(target.method_5667());
        if (targetData == null) return;
        if (targetData.getRole() == Role.YUSUI) return; // 不能让鱼碎自己变男娘
        if (targetData.isNanniang()) return;

        // 只在场上没有存活的男娘时才能用雪球转化
        for (PlayerData pd : gm.getAllPlayerData().values()) {
            if (pd.isNanniang() && pd.isAlive()) {
                tip(yusui, "§c场上已有男娘，雪球无法转化新目标！");
                return;
            }
        }

        makeNanniang(yusui, target, data, targetData);
    }

    // 被男娘击杀的玩家也变男娘(在GameManager.onPlayerDeath中调用)
    public static void onNanniangKillConvert(class_3222 victim, PlayerData killerData) {
        GameManager gm = GameManager.getInstance();
        PlayerData victimData = gm.getPlayerData(victim.method_5667());
        if (victimData == null || victimData.isNanniang() || victimData.getRole() == Role.YUSUI) return;

        UUID masterUuid = killerData.getNanniangMaster();
        PlayerData masterData = gm.getPlayerData(masterUuid);
        if (masterData == null) return;

        class_3222 masterPlayer = victim.method_51469().method_8503().method_3760().method_14602(masterUuid);
        makeNanniang(masterPlayer, victim, masterData, victimData);
    }

    private static void makeNanniang(class_3222 master, class_3222 target,
                                     PlayerData masterData, PlayerData targetData) {
        masterData.getNanniangTargets().add(target.method_5667());
        targetData.setNanniang(true);
        targetData.setNanniangMaster(masterData.getPlayerUuid());

        GameManager.getInstance().broadcastMessage("§d" + target.method_7334().name() + " 成为了男娘，喵~");
        target.method_7353(class_2561.method_43470("§e你被变成了男娘！"), false);
    }

    // ==================== NIHAO: 问好 ====================
    // 无主动技能键, 通过/hello指令触发
    private static void handleNihaoSkill(class_3222 player, PlayerData data, int skillSlot) {
        // NIHAO的技能通过/hello命令触发, 不使用按键
        tip(player, "§e使用 §a/hello <玩家名> §e来问好！");
    }

    // /hello 命令处理(由PlayerCommands调用)
    public static void handleHelloCommand(class_3222 player, class_3222 target) {
        GameManager gm = GameManager.getInstance();
        PlayerData data = gm.getPlayerData(player.method_5667());
        if (data == null || data.getRole() != Role.NIHAO) {
            player.method_7353(class_2561.method_43470("§c你不是Nihao角色！"), false);
            return;
        }

        long currentTick = player.method_51469().method_75260();
        if (currentTick - data.getLastSkillZTime() < NIHAO_COOLDOWN) {
            long remaining = (NIHAO_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
            tip(player, "§c问好冷却中... §e" + remaining + "s");
            return;
        }
        if (data.getHelloTargetUuid() != null) {
            tip(player, "§c你已经在问好中！等待对方回复...");
            return;
        }

        PlayerData targetData = gm.getPlayerData(target.method_5667());
        if (targetData == null || !targetData.isAlive()) {
            tip(player, "§c目标不在游戏中或已死亡！");
            return;
        }

        data.setLastSkillZTime(currentTick);
        int code = 100000 + new java.util.Random().nextInt(900000); // 6位随机数
        data.setHelloTargetUuid(target.method_5667());
        data.setHelloCode(code);
        data.setHelloExpiryTick(currentTick + data.getHelloTimerSeconds() * 20L);

        gm.broadcastMessage("§e§l[问好] §r§e" + player.method_7334().name() + " §a向 §e" + target.method_7334().name() + " §a发起了问好！");

        // 目标: 正中间大标题 + 副标题显示验证码 + 警报音效
        int timer = data.getHelloTimerSeconds();
        // Title 时序: fadeIn=10tick, stay=timer秒, fadeOut=20tick
        target.field_13987.method_14364(new net.minecraft.class_5905(10, timer * 20, 20));
        target.field_13987.method_14364(new net.minecraft.class_5904(
                class_2561.method_43470("§c§l⚠ 你被问好了！")));
        target.field_13987.method_14364(new net.minecraft.class_5903(
                class_2561.method_43470("§e输入 §a/helloback " + code + " §e否则 §c§l" + timer + "秒后秒杀！")));
        // 警报音效(带诅咒氛围)+铃声
        net.minecraft.class_3218 tWorld = (net.minecraft.class_3218) target.method_51469();
        tWorld.method_8396(null, target.method_24515(),
                net.minecraft.class_3417.field_15203,
                net.minecraft.class_3419.field_15250, 1.0f, 1.0f);
        tWorld.method_8396(null, target.method_24515(),
                net.minecraft.class_3417.field_14793.comp_349(),
                net.minecraft.class_3419.field_15250, 1.0f, 0.8f);
        // 聊天消息(fallback, 玩家可以复制)
        target.method_7353(class_2561.method_43470("§c§l⚠ 你被问好了！§r§e" + timer + "秒内输入 §a/helloback " + code + " §e否则被秒杀！"), false);

        // NIHAO本人: 轻提示
        net.minecraft.class_3218 pWorld = (net.minecraft.class_3218) player.method_51469();
        pWorld.method_8396(null, player.method_24515(),
                net.minecraft.class_3417.field_15015.comp_349(),
                net.minecraft.class_3419.field_15250, 0.8f, 1.2f);
        tip(player, "§a已向 " + target.method_7334().name() + " 发起问好！验证码: §e" + code + " §a倒计时: §e" + timer + "秒");
    }

    // /helloback 命令处理(由PlayerCommands调用)
    public static void handleHelloBackCommand(class_3222 responder, int code) {
        GameManager gm = GameManager.getInstance();
        UUID responderUuid = responder.method_5667();

        for (PlayerData nihaoData : gm.getAllPlayerData().values()) {
            if (nihaoData.getRole() != Role.NIHAO) continue;

            // 检查全体问好
            if (!nihaoData.getBroadcastHelloCodes().isEmpty()) {
                Integer broadcastCode = nihaoData.getBroadcastHelloCodes().get(responderUuid);
                if (broadcastCode != null && !nihaoData.getBroadcastHelloResponded().contains(responderUuid)) {
                    if (broadcastCode == code) {
                        nihaoData.getBroadcastHelloResponded().add(responderUuid);
                        responder.method_7353(class_2561.method_43470("§a§l✓ 成功回复全体问好！"), false);
                        gm.broadcastMessage("§a§l[问好] §r§e" + responder.method_7334().name() + " §a成功回复了全体问好！");
                        // 清除Title
                        responder.field_13987.method_14364(new net.minecraft.class_5905(0, 0, 0));
                        responder.field_13987.method_14364(new net.minecraft.class_5904(class_2561.method_43473()));
                        return;
                    } else {
                        responder.method_7353(class_2561.method_43470("§c验证码错误！"), false);
                        return;
                    }
                }
            }

            // 检查单体问好
            if (nihaoData.getHelloTargetUuid() != null
                    && nihaoData.getHelloTargetUuid().equals(responderUuid)) {
                if (nihaoData.getHelloCode() == code) {
                    // 回复正确: NIHAO位置暴露30秒
                    long currentTick = responder.method_51469().method_75260();
                    nihaoData.setNihaoRevealUntilTick(currentTick + 600);
                    nihaoData.setRevealUntilTick(currentTick + 600);
                    class_3222 nihaoPlayer = responder.method_51469().method_8503().method_3760().method_14602(nihaoData.getPlayerUuid());
                    if (nihaoPlayer != null) {
                        nihaoPlayer.method_6092(new class_1293(class_1294.field_5912, 600, 0, false, false, true));
                    }
                    nihaoData.setHelloTargetUuid(null);
                    nihaoData.setHelloCode(0);
                    nihaoData.setHelloExpiryTick(0);
                    // 清除Title
                    responder.field_13987.method_14364(new net.minecraft.class_5905(0, 0, 0));
                    responder.field_13987.method_14364(new net.minecraft.class_5904(class_2561.method_43473()));
                    gm.broadcastMessage("§a§l[问好] §r§e" + responder.method_7334().name() + " §a成功回复了问好！§e" + nihaoData.getPlayerName() + " §a的位置暴露30秒！");
                    return;
                } else {
                    responder.method_7353(class_2561.method_43470("§c验证码错误！"), false);
                    return;
                }
            }
        }
        responder.method_7353(class_2561.method_43470("§c没有人在向你问好！"), false);
    }

    // ==================== DAMAI: 不死者 ====================
    // Z: 传送回墓碑(30秒冷却)
    private static void handleDamaiSkill(class_3222 player, PlayerData data, int skillSlot) {
        if (skillSlot != 0) return;
        if (!data.isSkeletonForm()) {
            tip(player, "§c你不在骷髅形态！");
            return;
        }
        class_2338 tombstone = data.getTombstonePos();
        if (tombstone == null) {
            tip(player, "§c没有墓碑位置！");
            return;
        }
        long currentTick = player.method_51469().method_75260();
        if (currentTick - data.getLastSkillZTime() < DAMAI_TP_COOLDOWN) {
            long remaining = (DAMAI_TP_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
            tip(player, "§c传送冷却中... §e" + remaining + "s");
            return;
        }
        data.setLastSkillZTime(currentTick);
        class_3218 world = player.method_51469();
        player.method_48105(world, tombstone.method_10263() + 0.5, tombstone.method_10264() + 1, tombstone.method_10260() + 0.5, Set.of(), player.method_36454(), player.method_36455(), false);
        tip(player, "§a已传送回墓碑位置！");
    }

    // ==================== DASHA: 鲨鱼人 ====================
    // Z: 变天为雨(5分钟冷却)
    private static void handleDashaSkill(class_3222 player, PlayerData data, int skillSlot) {
        if (skillSlot != 0) return;
        long currentTick = player.method_51469().method_75260();
        if (currentTick - data.getLastSkillZTime() < DASHA_RAIN_COOLDOWN) {
            long remaining = (DASHA_RAIN_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
            tip(player, "§c技能冷却中... §e" + remaining + "s");
            return;
        }
        data.setLastSkillZTime(currentTick);
        class_3218 world = player.method_51469();
        world.method_27910(0, 1200, true, false); // 雨天1分钟
        GameManager.getInstance().broadcastMessage("§b§l我的世界下雨了...");
    }

    // ==================== JVJV: 大爆炸 ====================
    // Z: 大爆炸, X: 红莲华, C: 进食回血, V: 吃人(5格内最近, 1minCD, 消化1min)
    private static void handleJvjvSkill(class_3222 player, PlayerData data, int skillSlot) {
        if (skillSlot == 3) { // V: 吃人
            long currentTick = player.method_51469().method_75260();
            if (data.getJvjvEatenPlayer() != null) {
                tip(player, "§c正在消化中，无法再次吃人！");
                return;
            }
            if (currentTick - data.getLastJvjvEatTick() < 1200) { // 1分钟CD
                int remaining = (int) ((1200 - (currentTick - data.getLastJvjvEatTick())) / 20);
                tip(player, "§c吃人冷却中... §e" + remaining + "s");
                return;
            }
            // 红莲华蓄力期间无法操作
            if (data.isRedLotusCharging(currentTick)) {
                tip(player, "§c红莲华蓄力中，无法操作！");
                return;
            }
            // 寻找5格内最近的存活玩家
            class_3218 world = player.method_51469();
            class_3222 nearest = null;
            double minDist = 25; // 5格squared
            for (class_3222 other : world.method_18456()) {
                if (other == player || other.method_7325()) continue;
                PlayerData od = GameManager.getInstance().getPlayerData(other.method_5667());
                if (od == null || !od.isAlive()) continue;
                double d = player.method_5858(other);
                if (d < minDist) {
                    minDist = d;
                    nearest = other;
                }
            }
            if (nearest == null) {
                tip(player, "§c5格内没有可吃的玩家！");
                return;
            }
            data.setLastJvjvEatTick(currentTick);
            GameManager.getInstance().jvjvEatPlayer(player, data, nearest, currentTick);
            return;
        }
        if (skillSlot == 2) { // C: 进食回血
            long currentTick = player.method_51469().method_75260();
            if (currentTick - data.getLastJvjvHealTick() < 20) { // 1秒CD
                return;
            }
            int foodLevel = player.method_7344().method_7586();
            if (foodLevel < 5) {
                tip(player, "§c饱食度不足！需要5点饱食度(当前" + foodLevel + ")");
                return;
            }
            data.setLastJvjvHealTick(currentTick);
            player.method_7344().method_7580(foodLevel - 5);
            player.method_6025(10.0f); // 回复10HP=5心
            class_3218 world = player.method_51469();
            world.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_19149,
                    net.minecraft.class_3419.field_15248, 1.0f, 1.0f);
            tip(player, "§a进食回血！回复5心(剩余饱食度" + player.method_7344().method_7586() + ")");
            return;
        }
        if (skillSlot == 0) { // Z: 大爆炸
            if (data.isExplosionUsed()) {
                tip(player, "§c本条命已使用大爆炸！");
                return;
            }
            // 红莲华蓄力期间无法操作
            long currentTick = player.method_51469().method_75260();
            if (data.isRedLotusCharging(currentTick)) {
                tip(player, "§c红莲华蓄力中，无法操作！");
                return;
            }
            data.setExplosionUsed(true);
            data.setLastSkillZTime(currentTick);
            // 全体玩家播放自定义爆炸前音效
            class_3218 world = player.method_51469();
            for (class_3222 p : world.method_18456()) {
                world.method_43128(null, p.method_23317(), p.method_23318(), p.method_23321(),
                        baby.sv.yepvpfabirc.ModSounds.EXPLOSION, net.minecraft.class_3419.field_15250,
                        1.0f, 1.0f);
            }
            GameManager.getInstance().broadcastMessage("§c§l[大爆炸] §r§e" + player.method_7334().name() + " §c发动了大爆炸！3秒后爆炸！");
        } else if (skillSlot == 1) { // X: 红莲华
            if (!data.canRedLotus()) {
                tip(player, "§c未解锁红莲华！需要累计大爆炸炸死5人！(当前" + data.getJvjvTotalExplosionKills() + "/5)");
                return;
            }
            if (data.isRedLotusUsed()) {
                tip(player, "§c红莲华已使用！");
                return;
            }
            long currentTick = player.method_51469().method_75260();
            data.setRedLotusUsed(true);
            data.setRedLotusActiveTick(currentTick);
            data.setRedLotusPos(player.method_24515());
            data.setLastSkillXTime(currentTick);
            // 高亮显示(发光效果10秒)
            player.method_6092(new class_1293(class_1294.field_5912, 200, 0, false, false, true));
            // 全体播放红莲华音乐
            class_3218 world = player.method_51469();
            for (class_3222 p : world.method_18456()) {
                world.method_43128(null, p.method_23317(), p.method_23318(), p.method_23321(),
                        baby.sv.yepvpfabirc.ModSounds.GURENGE, net.minecraft.class_3419.field_15250,
                        1.0f, 1.0f);
            }
            GameManager.getInstance().broadcastMessage("§c§l§k!!§r §4§l红莲华 §c§l§k!! §r§e" + player.method_7334().name() + " §c发动了红莲华！10秒后100格内所有玩家将被秒杀！");
        }
    }

    // JVJV大爆炸延迟执行（在GameManager tick中调用）
    public static void executeJvjvExplosion(class_3222 player, PlayerData data) {
        class_3218 world = player.method_51469();
        class_243 pos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());

        world.method_8437(null, pos.field_1352, pos.field_1351, pos.field_1350, 6.0f, class_1937.class_7867.field_40888);

        int killCount = 0;
        for (class_3222 target : new ArrayList<>(world.method_18456())) {
            if (target == player) continue;
            PlayerData td = GameManager.getInstance().getPlayerData(target.method_5667());
            if (td == null || !td.isAlive()) continue;
            if (target.method_5707(pos) <= 64) { // 8格
                // 绕过复活无敌: 临时清除
                long savedInvincibleUntil = td.getRespawnInvincibleUntil();
                td.setRespawnInvincibleUntil(0);
                // 穿透下界合金套/抗性: 多重保险击杀
                // 注意: 不能用 setHealth(0) 再 damage(), 因为 damage 检查 health>0 会跳过 onDeath, 导致命数不扣
                target.method_64397(world, world.method_48963().method_51847(), 99999f);
                if (target.method_5805()) target.method_64397(world, world.method_48963().method_48829(), 99999f);
                if (target.method_5805()) target.method_5768(world);
                if (target.method_5805()) td.setRespawnInvincibleUntil(savedInvincibleUntil); // 兜底
                killCount++;
                data.addKill(); // 计入左侧击杀数
            }
        }
        data.setLastExplosionKills(killCount);
        data.addJvjvTotalExplosionKills(killCount); // 累计击杀

        // 每炸死1人+1命(在自身死亡前累加, 避免被loseLife抵消)
        if (killCount > 0) {
            for (int i = 0; i < killCount; i++) {
                data.gainLife();
            }
        }

        GameManager.getInstance().broadcastMessage("§c§l[大爆炸] §r§e" + player.method_7334().name() + " §c炸死了 §e" + killCount + " §c名玩家！(累计" + data.getJvjvTotalExplosionKills() + "人)" + (killCount > 0 ? " §a§l+" + killCount + "命§r§c!" : ""));

        // 自身死亡(在bonus life加完之后, 确保loseLife不会抵消)
        player.method_5768(world);
        // 累计炸死5人解锁红莲华
        if (data.getJvjvTotalExplosionKills() >= 5 && !data.canRedLotus()) {
            data.setCanRedLotus(true);
            GameManager.getInstance().broadcastMessage("§4§l" + player.method_7334().name() + " 累计炸死5人，解锁了红莲华！");
        }
    }

    // JVJV红莲华延迟执行
    public static void executeRedLotus(class_3222 player, PlayerData data) {
        class_3218 world = player.method_51469();
        class_243 pos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());

        for (class_3222 target : new ArrayList<>(world.method_18456())) {
            if (target == player) continue;
            PlayerData td = GameManager.getInstance().getPlayerData(target.method_5667());
            if (td == null || !td.isAlive()) continue;
            if (target.method_5707(pos) <= 10000) { // 100格
                target.method_5768(world);
                data.addKill(); // 计入左侧击杀数
            }
        }
        data.setRedLotusActiveTick(0); // 清除冻结状态
        GameManager.getInstance().broadcastMessage("§4§l[红莲华] §r§c100格内所有玩家被秒杀！§e" + player.method_7334().name() + " §c存活！");
    }

    // ==================== ST: 柚子厨 ====================
    // Z: Ciallo暴露自己+看到所有人30秒(2分钟CD), V: 自瞄声波(选择ciallo暴露目标, 4秒自动攻击, 2分钟CD)
    private static void handleStSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();
        if (skillSlot == 0) { // Z: Ciallo
            handleCialloCommand(player);
        } else if (skillSlot == 2) { // V: 自瞄声波
            // 已在自瞄中 → 再按V循环切换目标
            if (data.getSonicAutoAimTarget() != null) {
                selectNextAutoAimTarget(player, data);
                return;
            }
            // 冷却检查
            if (currentTick - data.getLastSonicTick() < ST_SONIC_COOLDOWN) {
                long remaining = (ST_SONIC_COOLDOWN - (currentTick - data.getLastSonicTick())) / 20;
                tip(player, "§c声波冷却中... §e" + remaining + "s");
                return;
            }
            // 必须在Ciallo暴露期间才能使用
            if (data.getCialloSeeAllUntilTick() <= currentTick) {
                tip(player, "§c需要先使用Ciallo暴露目标！(Z键)");
                return;
            }
            // 选择第一个目标并开始自瞄
            if (!selectNextAutoAimTarget(player, data)) {
                tip(player, "§c没有可锁定的目标！");
                return;
            }
            data.setLastSonicTick(currentTick);
            data.setSonicReadyNotified(false);
            GameManager.getInstance().broadcastMessage("§d§l[Ciallo自瞄] §r§e" + player.method_7334().name() + " §c锁定了目标！4秒自动攻击开始！");
        }
    }

    // 循环选择下一个ciallo暴露的目标
    private static boolean selectNextAutoAimTarget(class_3222 player, PlayerData data) {
        GameManager gm = GameManager.getInstance();
        net.minecraft.server.MinecraftServer srv = gm.getServer();
        java.util.List<UUID> candidates = new java.util.ArrayList<>();
        for (PlayerData pd : gm.getAllPlayerData().values()) {
            if (!pd.isAlive() || pd.getPlayerUuid().equals(player.method_5667())) continue;
            class_3222 target = srv.method_3760().method_14602(pd.getPlayerUuid());
            if (target == null) continue;
            candidates.add(pd.getPlayerUuid());
        }
        if (candidates.isEmpty()) return false;

        int idx = data.getSonicSelectIndex() % candidates.size();
        UUID targetUuid = candidates.get(idx);
        data.setSonicSelectIndex(idx + 1);
        data.setSonicAutoAimTarget(targetUuid);
        data.setSonicAutoAimStartTick(player.method_51469().method_75260());

        class_3222 target = srv.method_3760().method_14602(targetUuid);
        String targetName = target != null ? target.method_7334().name() : "???";
        double dist = target != null ? Math.sqrt(player.method_5858(target)) : 0;
        tip(player, "§d§l[自瞄锁定] §e" + targetName + " §7(距离" + (int)dist + "格) §a再按V切换目标");
        return true;
    }

    // /Ciallo命令处理(ST专属主动1)
    public static void handleCialloCommand(class_3222 player) {
        PlayerData data = GameManager.getInstance().getPlayerData(player.method_5667());
        if (data == null || data.getRole() != Role.ST) {
            player.method_7353(class_2561.method_43470("§c你不是柚子厨角色！"), false);
            return;
        }

        long currentTick = player.method_51469().method_75260();
        if (currentTick - data.getLastCialloTick() < ST_CIALLO_COOLDOWN) {
            long remaining = (ST_CIALLO_COOLDOWN - (currentTick - data.getLastCialloTick())) / 20;
            tip(player, "§cCiallo冷却中... §e" + remaining + "s");
            return;
        }

        data.setLastCialloTick(currentTick);
        // 暴露自己30秒
        data.setCialloRevealUntilTick(currentTick + 600);
        data.setRevealUntilTick(currentTick + 600);
        player.method_6092(new class_1293(class_1294.field_5912, 600, 0, false, false, true));
        // 看到所有人30秒
        data.setCialloSeeAllUntilTick(currentTick + 600);

        // 全体玩家播放Ciallo自定义音效
        class_3218 world = player.method_51469();
        for (class_3222 p : world.method_18456()) {
            world.method_43128(null, p.method_23317(), p.method_23318(), p.method_23321(),
                    baby.sv.yepvpfabirc.ModSounds.CIALLO, net.minecraft.class_3419.field_15250,
                    1.0f, 1.0f);
        }

        GameManager.getInstance().broadcastMessage("§d§lCiallo～(∠・ω< )⌒☆ §r§e" + player.method_7334().name() + " §a发送了Ciallo！位置暴露30秒！");
        tip(player, "§aCiallo！你的位置暴露30秒，同时可以看到所有人位置30秒！");
    }

    // ST自瞄声波: 4秒蓄力结束后一次性结算(由GameManager.tickSt调用)
    // 伤害公式: 0-100格线性提升(0->20心), 100-200格线性衰减(20->10心), 200格以上保底10心
    public static void executeSonicFinalDamage(class_3222 player, PlayerData data, class_3222 target) {
        class_3218 world = (class_3218) player.method_51469();
        double distance = Math.sqrt(player.method_5858(target));

        double totalDamageHearts;
        if (distance <= 100.0) {
            // 0-100格: 0 -> 20心
            totalDamageHearts = distance * (20.0 / 100.0);
        } else if (distance <= 200.0) {
            // 100-200格: 20 -> 10心
            totalDamageHearts = 20.0 - (distance - 100.0) * (10.0 / 100.0);
        } else {
            // 200格以上: 保底10心
            totalDamageHearts = 10.0;
        }
        
        float damage = (float) (totalDamageHearts * 2.0); // 心→HP

        // 结算: 播放声波爆响+Ciallo音效
        world.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_38830,
                net.minecraft.class_3419.field_15248, 2.0f, 1.0f);
        for (class_3222 p : world.method_18456()) {
            world.method_43128(null, p.method_23317(), p.method_23318(), p.method_23321(),
                    baby.sv.yepvpfabirc.ModSounds.CIALLO, net.minecraft.class_3419.field_15250, 1.0f, 1.0f);
        }

        // 一次性结算伤害(穿透抗性: 用magic)
        target.method_64397(world, world.method_48963().method_48831(), damage);

        // 击退约10格
        double dx = target.method_23317() - player.method_23317();
        double dz = target.method_23321() - player.method_23321();
        double dist2d = Math.sqrt(dx * dx + dz * dz);
        if (dist2d < 0.1) { dx = 1; dz = 0; dist2d = 1; }
        double knockScale = 2.5 / dist2d;
        target.method_18800(dx * knockScale, 0.4, dz * knockScale);
        target.field_64356 = true;
        target.field_13987.method_14364(new net.minecraft.class_2743(target));

        tip(target, "§c§l被Ciallo声波结算命中！§r§c承受了 §e" + String.format("%.1f", totalDamageHearts) + "心 §7(距离" + (int)distance + "格)");
        tip(player, "§d§l[声波结算] §e" + target.method_7334().name() + " §d承受 §e" + String.format("%.1f", totalDamageHearts) + "心 §7(距离" + (int)distance + "格)");
    }

    // ==================== BOBBY: 罪人(主动) ====================
    // Z: 灵体(旁观者模式30s, 2minCD)
    private static void handleBobbySkill(class_3222 player, PlayerData data, int skillSlot) {
        if (skillSlot != 0) return;
        long currentTick = player.method_51469().method_75260();
        // 灵体中不可再次使用
        if (data.getBobbyGhostEndTick() > 0) {
            tip(player, "§c已在灵体状态中！");
            return;
        }
        if (currentTick - data.getLastBobbyGhostTick() < 2400) { // 2分钟CD
            int remaining = (int) ((2400 - (currentTick - data.getLastBobbyGhostTick())) / 20);
            tip(player, "§c灵体冷却中... §e" + remaining + "s");
            return;
        }
        data.setLastBobbyGhostTick(currentTick);
        GameManager.getInstance().startBobbyGhost(player, data, currentTick);
    }

    // ==================== RETOUR: 但丁 ====================
    // Z: 与罪人(Bobby)交换位置(1minCD)
    // V: 切换激光(无CD, 准星方向30格内1心/秒真伤)
    private static void handleRetourSkill(class_3222 player, PlayerData data, int skillSlot) {
        if (skillSlot == 0) { // Z键
            GameManager.getInstance().retourSwapWithBobby(player, data);
        } else if (skillSlot == 2) { // V键
            boolean active = !data.isRetourLaserActive();
            data.setRetourLaserActive(active);
            if (active) {
                tip(player, "§c§l激光已开启！§r§c准星对准敌人30格内造成1心/秒真伤");
                GameManager.getInstance().broadcastMessage("§c§l[激光] §r§e" + player.method_7334().name() + " §c开启了激光！");
            } else {
                tip(player, "§7激光已关闭");
            }
        }
    }

    // ==================== HELI: 揭开帷幕 ====================
    // Z: 传送到被揭露的玩家身旁(1分钟CD, 循环选择)
    // X: 全视之眼(3分钟CD, 揭露所有玩家1分钟)
    private static void handleHeliSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();
        if (skillSlot == 0) {
            // Z: 传送到被揭露的玩家
            if (currentTick - data.getLastSkillZTime() < HELI_TP_COOLDOWN) {
                long remaining = (HELI_TP_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
                tip(player, "§c技能冷却中... §e" + remaining + "s");
                return;
            }
            // 收集当前仍在揭露中的玩家
            List<UUID> activeRevealed = new ArrayList<>();
            for (Map.Entry<UUID, Long> entry : data.getRevealedPlayerExpiry().entrySet()) {
                if (entry.getValue() > currentTick) activeRevealed.add(entry.getKey());
            }
            if (activeRevealed.isEmpty()) {
                tip(player, "§c当前没有被揭露的玩家可传送！");
                return;
            }
            int idx = data.getHeliTpIndex() % activeRevealed.size();
            UUID targetUuid = activeRevealed.get(idx);
            data.setHeliTpIndex(idx + 1);
            class_3222 target = player.method_51469().method_8503().method_3760().method_14602(targetUuid);
            if (target == null || !target.method_5805()) {
                tip(player, "§c目标不在线或已死亡！");
                return;
            }
            data.setLastSkillZTime(currentTick);
            class_3218 world = (class_3218) target.method_51469();
            player.method_48105(world, target.method_23317() + 1, target.method_23318(), target.method_23321(), Set.of(), player.method_36454(), player.method_36455(), false);
            tip(player, "§a已传送到 §e" + target.method_7334().name() + " §a身旁！");
            GameManager.getInstance().broadcastMessage("§6§l[揭幕] §r§e" + player.method_7334().name() + " §6传送到了 §e" + target.method_7334().name() + " §6身旁！");
        } else if (skillSlot == 1) {
            // X: 全视之眼 — 揭露所有玩家1分钟
            if (currentTick - data.getLastSkillXTime() < HELI_EYE_COOLDOWN) {
                long remaining = (HELI_EYE_COOLDOWN - (currentTick - data.getLastSkillXTime())) / 20;
                tip(player, "§c技能冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillXTime(currentTick);
            class_3218 world = player.method_51469();
            long dayTime = world.method_8532() % 24000;
            boolean isNight = dayTime >= 13000 && dayTime <= 23000;
            int revealedCount = 0;
            for (class_3222 p : world.method_18456()) {
                if (p.method_5667().equals(player.method_5667())) continue;
                PlayerData pd = GameManager.getInstance().getPlayerData(p.method_5667());
                if (pd == null || !pd.isAlive()) continue;
                if (isFullyInvisible(pd, isNight, currentTick)) continue;
                heliApplyReveal(data, pd, p.method_5667(), currentTick);
                revealedCount++;
            }
            GameManager.getInstance().broadcastMessage("§6§l[全视之眼] §r§e" + player.method_7334().name() + " §6开启了全视之眼！揭露了 §e" + revealedCount + " §6名玩家！");
        }
    }

    // 判断玩家是否处于"完全隐身"状态(揭露对其位置暴露无效)
    public static boolean isFullyInvisible(PlayerData pd, boolean isNight, long currentTick) {
        // JIEZU夜晚完全隐身
        if (pd.getRole() == Role.JIEZU && isNight) return true;
        // DASHA水中完全隐身(显形期除外)
        if (pd.getRole() == Role.DASHA && pd.isInWater() && currentTick >= pd.getDashaVisibleUntilTick()) return true;
        return false;
    }

    // 对目标施加揭露(1分钟位置暴露 + 前15秒双倍伤害)
    private static void heliApplyReveal(PlayerData heliData, PlayerData targetData, UUID targetUuid, long currentTick) {
        heliData.getRevealedPlayers().add(targetUuid);
        heliData.getRevealedPlayerExpiry().put(targetUuid, currentTick + 1200); // 1分钟
        heliData.getHeliRevealStartTick().put(targetUuid, currentTick); // 记录开始时间(15s双倍伤害)
        targetData.setRevealUntilTick(currentTick + 1200);
    }

    // Heli攻击揭露（从DamaiAttackMixin调用）
    // 揭露持续1分钟, 持续期间不能再次揭露同一玩家
    public static void heliRevealOnAttack(class_3222 heli, class_3222 target) {
        PlayerData heliData = GameManager.getInstance().getPlayerData(heli.method_5667());
        if (heliData == null || heliData.getRole() != Role.HELI) return;
        long currentTick = heli.method_51469().method_75260();

        // 该玩家仍在揭露中 → 不能重复揭露
        Long expiry = heliData.getRevealedPlayerExpiry().get(target.method_5667());
        if (expiry != null && expiry > currentTick) return;

        // 检查目标是否完全隐身
        PlayerData targetData = GameManager.getInstance().getPlayerData(target.method_5667());
        if (targetData != null) {
            long dayTime = heli.method_51469().method_8532() % 24000;
            boolean isNight = dayTime >= 13000 && dayTime <= 23000;
            if (isFullyInvisible(targetData, isNight, currentTick)) {
                tip(heli, "§c对方处于完全隐身状态，无法揭露！");
                return;
            }
        }

        heliApplyReveal(heliData, targetData, target.method_5667(), currentTick);
        GameManager.getInstance().broadcastMessage("§6§l[揭幕] §r§e" + heli.method_7334().name() + " §6揭露了 §e" + target.method_7334().name() + " §6的位置！§c15秒内受到的伤害翻倍！");
    }

    // ==================== MACHA: 钓鱼 ====================
    // Z: 15秒冷却, 随机战利品(不钓人)
    // X: 钓人(每10次出钩获得1次钓人机会, 3秒警告)
    // 10%合金武器(不重复) 10%合金装备(不重复) 5%随机传送 35%随机道具 5%基头四召唤器 33%鱼 1%+命 1%暴毙
    private static void handleMachaSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();

        if (skillSlot == 1) { // X: 钓人
            if (data.getMachaFishPlayerCharges() <= 0) {
                tip(player, "§c没有钓人次数！(每10次出钩获得1次, 当前第" + data.getMachaFishCount() + "次)");
                return;
            }
            if (data.getMachaFishingTarget() != null) {
                tip(player, "§c正在钓人中...");
                return;
            }
            data.useMachaFishPlayerCharge();
            fishPlayer(player, data, currentTick);
            return;
        }

        if (skillSlot != 0) return; // Z: 钓鱼
        if (currentTick - data.getLastSkillZTime() < MACHA_COOLDOWN) {
            long remaining = (MACHA_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
            tip(player, "§c技能冷却中... §e" + remaining + "s");
            return;
        }
        if (data.getMachaFishingTarget() != null) {
            tip(player, "§c正在钓鱼中...");
            return;
        }

        data.setLastSkillZTime(currentTick);
        data.incrementMachaFishCount();
        class_3218 world = player.method_51469();
        Random rand = new Random();

        // 每10次出钩获得1次钓人机会
        if (data.getMachaFishCount() % 10 == 0) {
            data.addMachaFishPlayerCharge();
            tip(player, "§a§l第" + data.getMachaFishCount() + "次出钩！获得钓人机会！(按X使用, 当前" + data.getMachaFishPlayerCharges() + "次)");
        }

        int roll = rand.nextInt(100);
        if (roll < 1) {
            // 1% 暴毙
            player.method_5768(world);
            GameManager.getInstance().broadcastMessage("§c§l[钓鱼] §r§e" + player.method_7334().name() + " §c钓到了死亡！暴毙！");
        } else if (roll < 2) {
            // 1% +1命
            data.gainLife();
            GameManager.getInstance().broadcastMessage("§a§l[钓鱼] §r§e" + player.method_7334().name() + " §a钓到了额外一条命！");
            tip(player, "§a§l钓到了1条命！当前命数: " + data.getLives());
        } else if (roll < 12) {
            // 10% 下界合金武器(不重复)
            machaGiveUniqueWeapon(player, data, rand);
        } else if (roll < 22) {
            // 10% 下界合金装备(不重复)
            machaGiveUniqueArmor(player, data, rand);
        } else if (roll < 27) {
            // 5% 自己随机传送
            net.minecraft.class_2784 border = world.method_8621();
            double radius = border.method_11965() / 2.0 * 0.8;
            double cx = border.method_11964();
            double cz = border.method_11980();
            int rx = (int) (cx + (rand.nextDouble() - 0.5) * 2 * radius);
            int rz = (int) (cz + (rand.nextDouble() - 0.5) * 2 * radius);
            world.method_8497(rx >> 4, rz >> 4);
            class_2338 safePos = GameManager.getInstance().findSafeLandSpawnPublic(world, rx, rz, rand);
            player.method_48105(world, safePos.method_10263() + 0.5, safePos.method_10264(), safePos.method_10260() + 0.5, Set.of(), player.method_36454(), player.method_36455(), false);
            tip(player, "§e钓到了...传送！你被随机传送了！");
        } else if (roll < 62) {
            // 35% 随机道具
            machaGiveRandomItem(player, world, rand);
        } else if (roll < 67) {
            // 5% 基头四召唤器
            machaGiveWardenSummoner(player);
        } else {
            // 33% 鱼
            class_1799[] fish = {new class_1799(class_1802.field_8429), new class_1799(class_1802.field_8209),
                    new class_1799(class_1802.field_8846), new class_1799(class_1802.field_8323)};
            player.method_31548().method_7394(fish[rand.nextInt(fish.length)]);
            tip(player, "§7钓到了鱼...");
        }
    }

    // 给不重复的下界合金武器
    private static void machaGiveUniqueWeapon(class_3222 player, PlayerData data, Random rand) {
        String[] allWeapons = {"netherite_sword", "netherite_axe"};
        List<String> available = new ArrayList<>();
        for (String w : allWeapons) {
            if (!data.getMachaObtainedWeapons().contains(w)) available.add(w);
        }
        if (available.isEmpty()) {
            // 全部获得过, 给鱼代替
            tip(player, "§7已获得所有下界合金武器，钓到了鱼...");
            player.method_31548().method_7394(new class_1799(class_1802.field_8429));
            return;
        }
        String chosen = available.get(rand.nextInt(available.size()));
        data.getMachaObtainedWeapons().add(chosen);
        class_1799 item = switch (chosen) {
            case "netherite_sword" -> new class_1799(class_1802.field_22022);
            case "netherite_axe" -> new class_1799(class_1802.field_22025);
            default -> new class_1799(class_1802.field_22022);
        };
        player.method_31548().method_7394(item);
        tip(player, "§d§l钓到了下界合金武器！" + item.method_7964().getString());
    }

    // 给不重复的下界合金装备
    private static void machaGiveUniqueArmor(class_3222 player, PlayerData data, Random rand) {
        String[] allArmor = {"netherite_helmet", "netherite_chestplate", "netherite_leggings", "netherite_boots"};
        List<String> available = new ArrayList<>();
        for (String a : allArmor) {
            if (!data.getMachaObtainedArmor().contains(a)) available.add(a);
        }
        if (available.isEmpty()) {
            tip(player, "§7已获得所有下界合金装备，钓到了鱼...");
            player.method_31548().method_7394(new class_1799(class_1802.field_8429));
            return;
        }
        String chosen = available.get(rand.nextInt(available.size()));
        data.getMachaObtainedArmor().add(chosen);
        class_1799 item = switch (chosen) {
            case "netherite_helmet" -> new class_1799(class_1802.field_22027);
            case "netherite_chestplate" -> new class_1799(class_1802.field_22028);
            case "netherite_leggings" -> new class_1799(class_1802.field_22029);
            case "netherite_boots" -> new class_1799(class_1802.field_22030);
            default -> new class_1799(class_1802.field_22027);
        };
        player.method_31548().method_7394(item);
        tip(player, "§d§l钓到了下界合金装备！" + item.method_7964().getString());
    }

    // 基头四召唤器: 给物品(使用时由GameManager处理)
    private static void machaGiveWardenSummoner(class_3222 player) {
        class_1799 item = new class_1799(class_1802.field_38746); // 回响碎片作为召唤器物品
        item.method_57379(net.minecraft.class_9334.field_49631,
                net.minecraft.class_2561.method_43470("§4§l基头四召唤器 §7(右键使用)"));
        player.method_31548().method_7394(item);
        tip(player, "§4§l钓到了基头四召唤器！§7右键使用召唤4个监守者(15秒)！");
        GameManager.getInstance().broadcastMessage("§4§l[钓鱼] §r§e" + player.method_7334().name() + " §4钓到了基头四召唤器！");
    }

    private static void machaGiveRandomItem(class_3222 player, class_3218 world, Random rand) {
        var registry = world.method_30349().method_30530(net.minecraft.class_7924.field_41265);
        int pick = rand.nextInt(13);
        class_1799 item;
        switch (pick) {
            case 0 -> {
                item = new class_1799(class_1802.field_8436);
                net.minecraft.class_6880<net.minecraft.class_1842>[] potionEntries = new net.minecraft.class_6880[]{
                    net.minecraft.class_1847.field_8993, net.minecraft.class_1847.field_8966,
                    net.minecraft.class_1847.field_8992, net.minecraft.class_1847.field_9000,
                    net.minecraft.class_1847.field_8980
                };
                var chosen = potionEntries[rand.nextInt(potionEntries.length)];
                item.method_57379(net.minecraft.class_9334.field_49651,
                    new net.minecraft.class_1844(chosen));
            }
            case 1 -> item = new class_1799(class_1802.field_8833);
            case 2 -> item = new class_1799(class_1802.field_8639, 10);
            case 3 -> item = new class_1799(class_1802.field_8634, 5);
            case 4 -> item = new class_1799(class_1802.field_8626, 2);
            case 5 -> {
                item = new class_1799(class_1802.field_49814);
                var density = registry.method_46746(net.minecraft.class_1893.field_50157).orElse(null);
                if (density != null) item.method_7978(density, 5);
            }
            case 6 -> item = new class_1799(class_1802.field_49098, 10);
            case 7 -> item = new class_1799(class_1802.field_8255);
            case 8 -> item = new class_1799(class_1802.field_8102);
            case 9 -> item = new class_1799(class_1802.field_8399);
            case 10 -> item = new class_1799(class_1802.field_8107, 64);
            case 11 -> item = new class_1799(class_1802.field_8187, 3);
            case 12 -> item = new class_1799(class_1802.field_8786, 10);
            default -> item = new class_1799(class_1802.field_8429);
        }
        player.method_31548().method_7394(item);
        tip(player, "§a钓到了 §e" + item.method_7964().getString() + (item.method_7947() > 1 ? " x" + item.method_7947() : "") + "§a！");
    }

    private static void fishPlayer(class_3222 player, PlayerData data, long currentTick) {
        GameManager gm = GameManager.getInstance();
        List<class_3222> candidates = new ArrayList<>();
        for (PlayerData pd : gm.getAllPlayerData().values()) {
            if (!pd.isAlive() || pd.getPlayerUuid().equals(player.method_5667())) continue;
            class_3222 target = gm.getServer().method_3760().method_14602(pd.getPlayerUuid());
            if (target != null) candidates.add(target);
        }
        if (candidates.isEmpty()) {
            tip(player, "§c没有可以钓的玩家！");
            return;
        }
        class_3222 target = candidates.get(new Random().nextInt(candidates.size()));
        data.setMachaFishingTarget(target.method_5667());
        data.setMachaFishingStartTick(currentTick);
        gm.broadcastMessage("§6§l[钓鱼] §r§e" + player.method_7334().name() + " §a正在钓 §e" + target.method_7334().name() + "§a！§c3秒后传送！");
        gm.sendTip(target, "§c§l⚠ 你被钓了！3秒后将被传送到 " + player.method_7334().name() + " 面前！");
    }

    // ==================== ALLAND: 喷射战士 ====================
    // Z=红(slot0), X=蓝(slot1), V=黄(slot2), C=绿(slot3) 颜料弹发射
    private static void handleAllandSkill(class_3222 player, PlayerData data, int skillSlot) {
        // skillSlot: 0=Z, 1=X, 2=V, 3=C → color: 0=红, 1=蓝, 2=绿, 3=黄
        int color = switch (skillSlot) {
            case 0 -> 0; // Z → 红
            case 1 -> 1; // X → 蓝
            case 2 -> 3; // V → 黄
            case 3 -> 2; // C → 绿
            default -> -1;
        };
        if (color < 0) return;

        if (data.getPaintCharges() <= 0) {
            tip(player, "§c没有颜料弹次数！(每15秒+1, 上限4)");
            return;
        }

        String colorName = switch (color) {
            case 0 -> "§c红";
            case 1 -> "§9蓝";
            case 2 -> "§a绿";
            case 3 -> "§e黄";
            default -> "?";
        };

        data.usePaintCharge();

        // 发射颜料弹(雪球, 无重力直线飞行)
        class_3218 world = (class_3218) player.method_51469();
        class_1799 snowballItem = new class_1799(net.minecraft.class_1802.field_8543);
        net.minecraft.class_1680 snowball =
            new net.minecraft.class_1680(world, player, snowballItem);
        snowball.method_24919(player, player.method_36455(), player.method_36454(), 0.0f, 1.5f, 0.0f);
        snowball.method_5875(true);
        world.method_8649(snowball);

        // 注册颜料弹(用color而非skillSlot)
        GameManager.getInstance().registerPaintProjectile(snowball.method_5628(), color, player.method_5667());

        tip(player, "§e发射" + colorName + "§e颜料弹！剩余: §a" + data.getPaintCharges() + "/4");
    }

    // ==================== POPCORN: 智械危机 ====================
    // Z: 放置备用躯体(充能制, 开局2次+击杀+1)
    // X: 传送到备用躯体(循环选择, 脉冲晕眩5格5秒, 满血+5临时心)
    // C(slot3): 灵魂出窍(即时进入旁观/返回)
    // V(slot2): 轨道镭射(对自身位置释放,旁观时对附身目标位置释放)
    private static void handlePopcornSkill(class_3222 player, PlayerData data, int skillSlot) {
        GameManager gm = GameManager.getInstance();
        // 旁观模式中: Z=下一个目标, X=上一个目标
        if (data.isPopcornSpectating() && (skillSlot == 0 || skillSlot == 1)) {
            int direction = (skillSlot == 0) ? 1 : -1;
            gm.popcornSwitchSpectateTarget(player, data, direction);
            return;
        }
        // 旁观模式中V键: 对附身目标位置释放镭射
        if (data.isPopcornSpectating() && skillSlot == 2) {
            java.util.UUID camTarget = data.getPopcornCameraTarget();
            if (camTarget != null) {
                net.minecraft.class_3222 targetPlayer =
                        gm.getServer().method_3760().method_14602(camTarget);
                if (targetPlayer != null) {
                    gm.popcornTriggerLaser(player, data, (int) targetPlayer.method_23317(), (int) targetPlayer.method_23321());
                    return;
                }
            }
            tip(player, "§c没有附身目标！");
            return;
        }
        if (skillSlot == 0) { // Z: 放置备用躯体
            if (data.isPopcornSpectating()) {
                tip(player, "§c旁观模式中无法放置躯体！");
                return;
            }
            if (data.getBackupBodyCharges() <= 0) {
                tip(player, "§c没有备用躯体充能！击杀玩家可获得。");
                return;
            }
            data.setBackupBodyCharges(data.getBackupBodyCharges() - 1);
            class_2338 pos = player.method_24515();
            data.getBackupBodies().add(pos);
            player.method_51469().method_8501(pos, class_2246.field_23261.method_9564());
            tip(player, "§a已放置备用躯体！当前 §e" + data.getBackupBodies().size() + " §a个，剩余充能 §e" + data.getBackupBodyCharges());
            gm.broadcastMessage("§e§l[智械危机] §r§e" + player.method_7334().name() + " §a放置了备用躯体！（所有人地图可见）");
        } else if (skillSlot == 1) { // X: 选择并传送到备用躯体(将其消耗)
            if (data.isPopcornSpectating()) {
                tip(player, "§c旁观模式中无法传送！先返回自身！");
                return;
            }
            if (data.getBackupBodies().isEmpty()) {
                tip(player, "§c没有备用躯体可传送！");
                return;
            }
            List<class_2338> bodies = data.getBackupBodies();
            long currentTick = player.method_51469().method_75260();

            // 如果已经进入选择模式
            if (data.getPopcornBodySelectTick() > 0) {
                // 如果距离上次按X时间很短(0.75秒内), 视为切换下一个
                if (currentTick - data.getLastSkillXTime() < 15) {
                    int idx = (data.getPopcornBodyTpIndex() + 1) % bodies.size();
                    data.setPopcornBodyTpIndex(idx);
                    data.setLastSkillXTime(currentTick);
                    class_2338 target = bodies.get(idx);
                    int dist = (int) Math.sqrt(player.method_5649(target.method_10263() + 0.5, target.method_10264() + 0.5, target.method_10260() + 0.5));
                    tip(player, "§e选择躯体 §a" + (idx + 1) + "/" + bodies.size()
                            + " §7(" + target.method_10263() + "," + target.method_10264() + "," + target.method_10260() + ") §e距离§a" + dist
                            + "格 §7(再次按X切换, 等待1.5秒或按V确认传送)");
                } else {
                    // 确认传送
                    class_2338 target = bodies.get(data.getPopcornBodyTpIndex() % bodies.size());
                    gm.popcornTeleportToBody(player, data, target);
                    data.setPopcornBodySelectTick(0);
                }
            } else {
                // 进入选择模式
                data.setPopcornBodyTpIndex(0);
                data.setPopcornBodySelectTick(currentTick);
                data.setLastSkillXTime(currentTick);
                class_2338 target = bodies.get(0);
                int dist = (int) Math.sqrt(player.method_5649(target.method_10263() + 0.5, target.method_10264() + 0.5, target.method_10260() + 0.5));
                tip(player, "§e开启选择模式 §a1/" + bodies.size()
                        + " §7(" + target.method_10263() + "," + target.method_10264() + "," + target.method_10260() + ") §e距离§a" + dist
                        + "格 §7(再次按X切换, 等待1.5秒或按V确认传送)");
            }
        } else if (skillSlot == 2) { // V: 轨道镭射(对准心所指位置释放)
            // 如果在X选择模式下按V, 视为确认传送
            if (data.getPopcornBodySelectTick() > 0 && !data.getBackupBodies().isEmpty()) {
                class_2338 target = data.getBackupBodies().get(data.getPopcornBodyTpIndex() % data.getBackupBodies().size());
                gm.popcornTeleportToBody(player, data, target);
                data.setPopcornBodySelectTick(0);
                return;
            }
            // 从视线发射raycast, 命中则取命中点, 未命中则沿视线投射256格取落点
            net.minecraft.class_239 hit = player.method_5745(256.0, 1.0f, false);
            int tx, tz;
            if (hit.method_17783() == net.minecraft.class_239.class_240.field_1332) {
                net.minecraft.class_243 hp = hit.method_17784();
                tx = (int) hp.field_1352;
                tz = (int) hp.field_1350;
            } else {
                net.minecraft.class_243 eye = player.method_33571();
                net.minecraft.class_243 dir = player.method_5720();
                net.minecraft.class_243 end = eye.method_1019(dir.method_1021(256.0));
                tx = (int) end.field_1352;
                tz = (int) end.field_1350;
            }
            gm.popcornTriggerLaser(player, data, tx, tz);
        } else if (skillSlot == 3) { // C: 灵魂出窍(即时进入/返回)
            gm.popcornSpectateAction(player, data);
        }
    }

    // ==================== SANCHEZ: 诸神黄昏 ====================
    // Z: 恢复头狼全血(30秒冷却,唯一治愈手段), X: 召唤狼(消耗1心+1charge), V: 狩猎模式(2分钟冷却)
    private static void handleSanchezSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();
        GameManager gm = GameManager.getInstance();

        if (skillSlot == 0) { // Z: 恢复头狼
            if (data.isAlphaWolfDead()) {
                long remain = (3600 - (currentTick - data.getAlphaWolfDeathTick())) / 20;
                tip(player, "§c头狼已死亡，等待复活！§e" + Math.max(0, remain) + "s");
                return;
            }
            if (currentTick - data.getLastSkillZTime() < SANCHEZ_HEAL_COOLDOWN) {
                long remaining = (SANCHEZ_HEAL_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
                tip(player, "§c冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillZTime(currentTick);
            data.setAlphaWolfHealth(40.0);
            // 同步到实体
            class_3218 world = player.method_51469();
            if (data.getAlphaWolfEntityUuid() != null) {
                net.minecraft.class_1297 e = world.method_66347(data.getAlphaWolfEntityUuid());
                if (e instanceof net.minecraft.class_1493 wolf) {
                    wolf.method_6033(40.0f);
                }
            }
            tip(player, "§a头狼已恢复全血！(20心)");
        } else if (skillSlot == 1) { // X: 召唤狼
            if (data.isAlphaWolfDead()) {
                tip(player, "§c头狼已死亡，无法召唤狼群！");
                return;
            }
            if (data.getWolfKillCharges() <= 0) {
                tip(player, "§c没有召唤次数！击杀生物可获得。");
                return;
            }
            if (player.method_6032() <= 2.0f) {
                tip(player, "§c血量不足1心，无法召唤！");
                return;
            }
            data.useWolfKillCharge();
            class_3218 world = player.method_51469();
            // 自己受1心伤害
            player.method_64397(world, world.method_48963().method_48831(), 2.0f);
            // 召唤真实狼实体(1心HP, 3心伤害)
            gm.spawnPackWolf(player, data, world);
            int wolfCount = data.getPackWolfUuids().size();
            tip(player, "§a已召唤狼！当前狼群: §e" + wolfCount + "只 §7(剩余次数: " + data.getWolfKillCharges() + ")");
        } else if (skillSlot == 2) { // V: 狩猎模式
            if (currentTick - data.getLastSkillVTime() < SANCHEZ_HUNT_COOLDOWN) {
                long remaining = (SANCHEZ_HUNT_COOLDOWN - (currentTick - data.getLastSkillVTime())) / 20;
                tip(player, "§c冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillVTime(currentTick);
            data.setSanchezHuntEndTick(currentTick + 200); // 10秒
            // 立即给效果
            player.method_6092(new class_1293(class_1294.field_5907, 200, 255, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5904, 200, 1, false, false, true));
            gm.broadcastMessage("§6§l[狩猎] §r§e" + player.method_7334().name() + " §6开启了狩猎模式！全军无敌10秒！");
        } else if (skillSlot == 3) { // C: 召集狼群(传送所有狼到自己位置, 30秒CD)
            if (currentTick - data.getLastSkillCTime() < 600) { // 30秒=600tick
                long remaining = (600 - (currentTick - data.getLastSkillCTime())) / 20;
                tip(player, "§c召集冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillCTime(currentTick);
            class_3218 world = player.method_51469();
            int teleported = 0;
            // 传送头狼
            if (data.getAlphaWolfEntityUuid() != null) {
                net.minecraft.class_1297 e = world.method_66347(data.getAlphaWolfEntityUuid());
                if (e != null && e.method_5805()) {
                    e.method_48105(world, player.method_23317(), player.method_23318(), player.method_23321(), java.util.Set.of(), 0, 0, false);
                    teleported++;
                }
            }
            // 传送狼群
            for (UUID wolfId : data.getPackWolfUuids()) {
                net.minecraft.class_1297 e = world.method_66347(wolfId);
                if (e != null && e.method_5805()) {
                    e.method_48105(world, player.method_23317(), player.method_23318(), player.method_23321(), java.util.Set.of(), 0, 0, false);
                    teleported++;
                }
            }
            tip(player, "§a已召集 §e" + teleported + " §a只狼到身边！");
        }
    }

    // ==================== SHUBING: 画中世界 ====================
    // 通道在天空中生成, 每条通道偏移避免重叠
    // 基础坐标 (0, 300, corridorIndex*10), 在世界边界(半径1000)内
    public static final int CORRIDOR_BASE_Y = 300;
    public static final int CORRIDOR_LEN = 150;
    private static int nextCorridorZOffset = 0; // 每条通道Z偏移10格避免重叠

    // Z: 放置画, X: 切换垂直/水平模式, V: 画中世界传送随机玩家(2min CD)
    private static void handleShubingSkill(class_3222 player, PlayerData data, int skillSlot) {
        // X键: 切换画的放置模式
        if (skillSlot == 1) {
            data.togglePaintingMode();
            String mode = data.isPaintingModeHorizontal() ? "§b水平模式§r(水平通道)" : "§d垂直模式§r(垂直通道)";
            player.method_7353(class_2561.method_43470("§e§l[画模式切换] §r当前: " + mode), false);
            return;
        }
        // V键: 画中世界传送随机玩家到身旁(2min CD, 必须在画中世界内)
        if (skillSlot == 2) {
            handleShubingSummon(player, data);
            return;
        }
        if (skillSlot != 0) return;
        if (data.getPaintingCount() <= 0) {
            tip(player, "§c没有画可以放置！每1分钟获得1幅。");
            return;
        }
        // 限制场上最多2幅画
        if (data.getActivePaintingCount() >= 2) {
            tip(player, "§c场上已有2幅画！拆除旧画后才能放置新的。");
            return;
        }

        class_3218 world = (class_3218) player.method_51469();

        // 跟随准心放置: raycast玩家视线方向, 最远5格
        net.minecraft.class_239 hitResult = player.method_5745(5.0, 0, false);
        class_2338 pos;
        if (hitResult.method_17783() == net.minecraft.class_239.class_240.field_1332) {
            net.minecraft.class_3965 blockHit = (net.minecraft.class_3965) hitResult;
            // 放在命中方块的相邻面(外侧)
            pos = blockHit.method_17777().method_10093(blockHit.method_17780());
        } else {
            // 没看到方块: 放在视线前方3格位置
            net.minecraft.class_243 eyePos = player.method_33571();
            net.minecraft.class_243 lookDir = player.method_5720();
            pos = class_2338.method_49638(eyePos.method_1019(lookDir.method_1021(3.0)));
        }

        // 检查是否在世界边界内
        net.minecraft.class_2784 border = world.method_8621();
        if (!border.method_11952(pos)) {
            tip(player, "§c无法在毒圈外放置画！");
            return;
        }

        // 使用当前模式(X键切换): 水平=水平通道, 垂直=垂直通道
        boolean horizontal = data.isPaintingModeHorizontal();
        String modeStr = horizontal ? "§b水平" : "§d垂直";
        player.method_7353(class_2561.method_43470("§e[画] §r当前模式: " + modeStr + "§r | §7按X键切换模式"), false);

        // 统一用紫水晶方块作为画的标记
        world.method_8501(pos, class_2246.field_27159.method_9564());
        UUID paintingEntityUuid = UUID.nameUUIDFromBytes(("shubing_" + pos.method_23854()).getBytes());

        data.usePainting();
        PlayerData.ShubingPainting painting = new PlayerData.ShubingPainting(pos, paintingEntityUuid, horizontal);
        data.getPlacedPaintings().add(painting);
        int paintIdx = data.getPlacedPaintings().size() - 1;

        // 生成悬浮文字
        String ownerName = player.method_7334().name();
        class_2561 hologramText = buildHologramText(painting, data, ownerName);
        painting.hologramTag = spawnHologramTag(world, pos, hologramText);

        // 广播画位置
        String dir = horizontal ? "水平" : "垂直";
        GameManager.getInstance().broadcastMessage(
                "§e§l[画中世界] §r§e" + ownerName +
                " §a放置了一幅" + dir + "画于 §e(" + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + ")");

        // 检查是否有未配对的画可以配对
        int unpairedIdx = -1;
        for (int i = 0; i < data.getPlacedPaintings().size() - 1; i++) {
            if (data.getPlacedPaintings().get(i).corridorIndex == -1) {
                unpairedIdx = i;
                break;
            }
        }

        if (unpairedIdx >= 0) {
            // 配对! 第二幅画的方向决定通道走向
            // 垂直放(挂墙上)→垂直通道(攀爬), 水平放(地面)→水平通道(行走)
            boolean corridorVertical = !horizontal;

            // 生成通道
            int corridorIdx = data.getCorridors().size();
            int zOffset = nextCorridorZOffset;
            nextCorridorZOffset += 10;
            // 通道生成在世界边界中心上空, 避免被毒圈吞噬
            net.minecraft.class_2784 wb = world.method_8621();
            int cx = (int) wb.method_11964();
            int cz = (int) wb.method_11980();
            class_2338 origin = new class_2338(cx, CORRIDOR_BASE_Y, cz + zOffset);

            PlayerData.ShubingCorridor corridor = new PlayerData.ShubingCorridor(
                    origin, corridorVertical, unpairedIdx, paintIdx);
            data.getCorridors().add(corridor);

            // 更新两幅画的配对信息
            PlayerData.ShubingPainting firstPainting = data.getPlacedPaintings().get(unpairedIdx);
            firstPainting.corridorIndex = corridorIdx;
            firstPainting.corridorEnd = 0;
            painting.corridorIndex = corridorIdx;
            painting.corridorEnd = 1;

            // 在天空中建造通道
            buildCorridor(world, origin, corridorVertical);

            // 更新两端悬浮文字(显示链接目标)
            updateHologramByTag(world, firstPainting.hologramTag,
                    buildHologramText(firstPainting, data, ownerName));
            updateHologramByTag(world, painting.hologramTag,
                    buildHologramText(painting, data, ownerName));

            player.method_7353(class_2561.method_43470("§a§l两幅画已连接！画中世界通道已生成！" +
                    (corridorVertical ? "(垂直通道)" : "(水平通道)")), true);
            GameManager.getInstance().broadcastMessage(
                    "§e§l[画中世界] §r§a" + ownerName +
                    " 的两幅画已连接！触碰画即可进入通道！");
        } else {
            tip(player, "§a画已放置！放下第二幅画来连接通道。");
        }
    }

    // 建造通道: 水平通道沿X轴, 垂直通道沿Y轴
    // 墙壁用石砖, 每3格嵌入海晶灯照明, 两端用紫水晶方块
    private static void buildCorridor(class_3218 world, class_2338 origin, boolean vertical) {
        if (vertical) {
            // 垂直通道: 5x5外壳, 3x3空气内部, Y方向延伸50格, 无梯子(自由落体)
            // 先清空整个区域(包括顶底2层额外封口), 确保完全密闭
            for (int y = -2; y <= CORRIDOR_LEN + 1; y++) {
                for (int x = -2; x <= 2; x++) {
                    for (int z = -2; z <= 2; z++) {
                        class_2338 bp = origin.method_10069(x, y, z);
                        boolean isInner = (x >= -1 && x <= 1 && z >= -1 && z <= 1);
                        boolean inCorridorRange = (y >= 0 && y < CORRIDOR_LEN);
                        if (inCorridorRange && isInner) {
                            // 内部3x3: 空气
                            world.method_8501(bp, class_2246.field_10124.method_9564());
                        } else if (inCorridorRange) {
                            // 外壳: 石砖墙 + 每3格海晶灯
                            if (y % 3 == 0 && x == 2 && z == 0) {
                                world.method_8501(bp, class_2246.field_10174.method_9564());
                            } else {
                                world.method_8501(bp, class_2246.field_10056.method_9564());
                            }
                        } else {
                            // 顶底封口层(y<0或y>=CORRIDOR_LEN): 全部石砖封死
                            world.method_8501(bp, class_2246.field_10056.method_9564());
                        }
                    }
                }
            }
            // 顶底封口标记层: 紫水晶方块(覆盖完整5x5, 在最外层)
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    world.method_8501(origin.method_10069(x, -2, z), class_2246.field_27159.method_9564());
                    world.method_8501(origin.method_10069(x, CORRIDOR_LEN + 1, z), class_2246.field_27159.method_9564());
                }
            }
        } else {
            // 水平通道: 3宽(Z) x 4高(Y=0地板,1-2空气,3天花板) x 50长(X)
            for (int x = 0; x < CORRIDOR_LEN; x++) {
                for (int y = 0; y <= 3; y++) {
                    for (int z = -1; z <= 1; z++) {
                        class_2338 bp = origin.method_10069(x, y, z);
                        boolean isFloor = (y == 0);
                        boolean isCeiling = (y == 3);
                        boolean isSideWall = (z == -1 || z == 1);
                        if (isFloor) {
                            world.method_8501(bp, class_2246.field_28900.method_9564());
                        } else if (isCeiling) {
                            if (x % 3 == 0 && z == 0) {
                                world.method_8501(bp, class_2246.field_10174.method_9564());
                            } else {
                                world.method_8501(bp, class_2246.field_10056.method_9564());
                            }
                        } else if (isSideWall) {
                            world.method_8501(bp, class_2246.field_10056.method_9564());
                        } else {
                            world.method_8501(bp, class_2246.field_10124.method_9564());
                        }
                    }
                }
            }
            // 两端封口: 紫水晶方块
            for (int y = 0; y <= 3; y++) {
                for (int z = -1; z <= 1; z++) {
                    world.method_8501(origin.method_10069(-1, y, z), class_2246.field_27159.method_9564());
                    world.method_8501(origin.method_10069(CORRIDOR_LEN, y, z), class_2246.field_27159.method_9564());
                }
            }
        }
    }

    // ===== 悬浮文字(TextDisplayEntity, 反射设置FIXED+正反两面) =====
    private static long hologramCounter = 0;
    @SuppressWarnings("unchecked")
    private static net.minecraft.class_2940<class_2561> TEXT_TRACKED = null;
    @SuppressWarnings("unchecked")
    private static net.minecraft.class_2940<Byte> BILLBOARD_TRACKED = null;
    @SuppressWarnings("unchecked")
    private static net.minecraft.class_2940<Integer> BACKGROUND_TRACKED = null;

    private static void initTrackedFields() {
        if (TEXT_TRACKED != null) return;
        try {
            for (java.lang.reflect.Field f : class_8113.class_8123.class.getDeclaredFields()) {
                f.setAccessible(true);
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())
                        && f.getType() == net.minecraft.class_2940.class) {
                    Object val = f.get(null);
                    if (val != null) {
                        // 通过测试set来区分TEXT vs BACKGROUND等字段
                        String fname = f.getName();
                        if (TEXT_TRACKED == null && fname.toLowerCase().contains("text")) {
                            TEXT_TRACKED = (net.minecraft.class_2940<class_2561>) val;
                        } else if (BACKGROUND_TRACKED == null && fname.toLowerCase().contains("background")) {
                            BACKGROUND_TRACKED = (net.minecraft.class_2940<Integer>) val;
                        }
                    }
                }
            }
            // TEXT字段可能不叫text,按声明顺序:第一个是TEXT,第二个是LINE_WIDTH,第三个是BACKGROUND,...
            if (TEXT_TRACKED == null) {
                java.lang.reflect.Field[] fields = class_8113.class_8123.class.getDeclaredFields();
                List<java.lang.reflect.Field> statics = new ArrayList<>();
                for (java.lang.reflect.Field f : fields) {
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers())
                            && f.getType() == net.minecraft.class_2940.class) {
                        f.setAccessible(true);
                        statics.add(f);
                    }
                }
                if (statics.size() >= 1) TEXT_TRACKED = (net.minecraft.class_2940<class_2561>) statics.get(0).get(null);
                if (statics.size() >= 3) BACKGROUND_TRACKED = (net.minecraft.class_2940<Integer>) statics.get(2).get(null);
            }
            // BILLBOARD在DisplayEntity父类 — 通过泛型类型TrackedData<Byte>定位
            for (java.lang.reflect.Field f : class_8113.class.getDeclaredFields()) {
                if (!java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                if (f.getType() != net.minecraft.class_2940.class) continue;
                java.lang.reflect.Type gt = f.getGenericType();
                if (gt instanceof java.lang.reflect.ParameterizedType pt) {
                    java.lang.reflect.Type[] args = pt.getActualTypeArguments();
                    if (args.length == 1 && args[0] == Byte.class) {
                        f.setAccessible(true);
                        BILLBOARD_TRACKED = (net.minecraft.class_2940<Byte>) f.get(null);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class_8113.class_8123 createTextDisplay(class_3218 world, double x, double y, double z, float yaw, class_2561 text) {
        initTrackedFields();
        class_8113.class_8123 display = new class_8113.class_8123(class_1299.field_42457, world);
        display.method_5814(x, y, z);
        display.method_36456(yaw);
        try {
            if (TEXT_TRACKED != null) display.method_5841().method_12778(TEXT_TRACKED, text);
            if (BILLBOARD_TRACKED != null) display.method_5841().method_12778(BILLBOARD_TRACKED, (byte) 0); // 0=FIXED
            if (BACKGROUND_TRACKED != null) display.method_5841().method_12778(BACKGROUND_TRACKED, 0x40000000);
        } catch (Exception ignored) {}
        return display;
    }

    private static String spawnHologramTag(class_3218 world, class_2338 paintingPos, class_2561 text) {
        String tag = "shubing_holo_" + (hologramCounter++);
        double x = paintingPos.method_10263() + 0.5;
        double y = paintingPos.method_10264() + 1.5;
        double z = paintingPos.method_10260() + 0.5;
        // 正面(yaw=0)
        class_8113.class_8123 front = createTextDisplay(world, x, y, z, 0f, text);
        front.method_5780(tag);
        world.method_8649(front);
        // 背面(yaw=180)
        class_8113.class_8123 back = createTextDisplay(world, x, y, z, 180f, text);
        back.method_5780(tag);
        world.method_8649(back);
        return tag;
    }

    private static void updateHologramByTag(class_3218 world, String tag, class_2561 text) {
        if (tag == null) return;
        initTrackedFields();
        for (var entity : world.method_27909()) {
            if (entity.method_5752().contains(tag) && entity instanceof class_8113.class_8123 display) {
                if (TEXT_TRACKED != null) {
                    try { display.method_5841().method_12778(TEXT_TRACKED, text); } catch (Exception ignored) {}
                }
            }
        }
    }

    private static void removeHologramByTag(class_3218 world, String tag) {
        if (tag == null) return;
        List<net.minecraft.class_1297> toRemove = new ArrayList<>();
        for (var entity : world.method_27909()) {
            if (entity.method_5752().contains(tag)) toRemove.add(entity);
        }
        toRemove.forEach(net.minecraft.class_1297::method_31472);
    }

    // 构建MC Text组件(带颜色)
    private static class_2561 buildHologramText(PlayerData.ShubingPainting painting, PlayerData data, String ownerName) {
        String mode = painting.horizontal ? "水平画" : "垂直画";
        net.minecraft.class_124 modeColor = painting.horizontal ? net.minecraft.class_124.field_1075 : net.minecraft.class_124.field_1076;
        if (painting.corridorIndex < 0) {
            return class_2561.method_43470(ownerName + "的画 ").method_27692(net.minecraft.class_124.field_1065)
                    .method_10852(class_2561.method_43470("[" + mode + "]").method_27692(modeColor))
                    .method_10852(class_2561.method_43470(" 未配对").method_27692(net.minecraft.class_124.field_1080));
        }
        PlayerData.ShubingCorridor corridor = data.getCorridors().get(painting.corridorIndex);
        int otherEnd = (painting.corridorEnd == 0) ? corridor.painting1Index : corridor.painting0Index;
        if (otherEnd >= 0 && otherEnd < data.getPlacedPaintings().size()) {
            class_2338 otherPos = data.getPlacedPaintings().get(otherEnd).pos;
            String type = corridor.vertical ? "垂直通道" : "水平通道";
            net.minecraft.class_124 typeColor = corridor.vertical ? net.minecraft.class_124.field_1076 : net.minecraft.class_124.field_1075;
            return class_2561.method_43470(ownerName + "的画 ").method_27692(net.minecraft.class_124.field_1065)
                    .method_10852(class_2561.method_43470("[" + mode + "] ").method_27692(modeColor))
                    .method_10852(class_2561.method_43470(type + " -> ").method_27692(typeColor))
                    .method_10852(class_2561.method_43470("(" + otherPos.method_10263() + ", " + otherPos.method_10264() + ", " + otherPos.method_10260() + ")").method_27692(net.minecraft.class_124.field_1054));
        }
        return class_2561.method_43470(ownerName + "的画 ").method_27692(net.minecraft.class_124.field_1065)
                .method_10852(class_2561.method_43470("[" + mode + "]").method_27692(modeColor));
    }

    // 获取通道某端的传送坐标
    // end: 0=入口端, 1=出口端
    public static double[] getCorridorTeleportPos(PlayerData.ShubingCorridor corridor, int end) {
        class_2338 o = corridor.origin;
        if (corridor.vertical) {
            // 垂直通道: end0(画1)=底部, end1(画2)=顶部(从顶部落下)
            if (end == 0) {
                return new double[]{o.method_10263() + 0.5, o.method_10264() + 1.0, o.method_10260() + 0.5};
            } else {
                int ty = o.method_10264() + CORRIDOR_LEN - 2;
                return new double[]{o.method_10263() + 0.5, ty, o.method_10260() + 0.5};
            }
        } else {
            // 水平: end0=x+1, end1=x+LEN-2
            int tx = (end == 0) ? o.method_10263() + 1 : o.method_10263() + CORRIDOR_LEN - 2;
            return new double[]{tx + 0.5, o.method_10264() + 1.0, o.method_10260() + 0.5};
        }
    }

    // 判断玩家在通道中到达了哪一端 (0=入口端, 1=出口端, -1=中间)
    public static int getCorridorEndReached(PlayerData.ShubingCorridor corridor, class_3222 player) {
        class_2338 o = corridor.origin;
        if (corridor.vertical) {
            // 垂直通道: 底部=end0, 顶部=end1
            double relY = player.method_23318() - o.method_10264();
            if (relY <= 1.0) return 0; // 到达底部
            if (relY >= CORRIDOR_LEN - 2.0) return 1; // 到达顶部
        } else {
            double relX = player.method_23317() - o.method_10263();
            if (relX <= 1.0) return 0;
            if (relX >= CORRIDOR_LEN - 2.0) return 1;
        }
        return -1;
    }

    // 玩家触碰画 → 进入通道 (由Mixin调用)
    public static void onPlayerTouchPainting(class_3222 player, UUID paintingEntityUuid) {
        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;
        PlayerData pd = gm.getPlayerData(player.method_5667());
        if (pd == null || !pd.isAlive()) return;

        // 找到这幅画属于哪个SHUBING玩家
        for (PlayerData shubingData : gm.getAllPlayerData().values()) {
            if (shubingData.getRole() != Role.SHUBING) continue;
            int paintIdx = shubingData.findPaintingByEntityUuid(paintingEntityUuid);
            if (paintIdx < 0) continue;

            PlayerData.ShubingPainting painting = shubingData.getPlacedPaintings().get(paintIdx);
            if (painting.corridorIndex < 0) {
                tip(player, "§e这幅画还没有连接通道。");
                return;
            }

            // 已经在某个通道内，不能再进
            if (shubingData.getCorridorPlayers().containsKey(player.method_5667())) {
                return;
            }

            PlayerData.ShubingCorridor corridor = shubingData.getCorridors().get(painting.corridorIndex);
            // 如果这端被封了，不能进入
            if (painting.corridorEnd == 0 && corridor.end0Sealed) {
                tip(player, "§c这一端的出口已被封闭！");
                return;
            }
            if (painting.corridorEnd == 1 && corridor.end1Sealed) {
                tip(player, "§c这一端的出口已被封闭！");
                return;
            }

            // 垂直通道: 画1(end0)进入→直接弹回, 只有画2(end1)可以从顶部落下
            if (corridor.vertical && painting.corridorEnd == 0) {
                tip(player, "§c这一端无法进入垂直通道！请从另一幅画进入！");
                return;
            }

            // 传送进通道对应端
            class_3218 world = (class_3218) player.method_51469();
            double[] tp = getCorridorTeleportPos(corridor, painting.corridorEnd);
            player.method_48105(world, tp[0], tp[1], tp[2], java.util.Set.of(), 0, 0, false);
            player.field_6017 = 0; // 进入时重置摔落距离

            long currentTick = world.method_75260();
            shubingData.getCorridorPlayers().put(player.method_5667(),
                    new PlayerData.CorridorEntry(painting.corridorIndex, currentTick, painting.corridorEnd));

            // 20秒摔落伤害免疫
            pd.setCorridorFallImmuneUntilTick(currentTick + 400);

            player.method_7353(class_2561.method_43470("§e§l你进入了画中世界！§c§l10秒内必须到达另一端！"), false);
            gm.broadcastMessage("§e" + player.method_7334().name() + " §a进入了画中世界通道！");
            return;
        }
    }

    // 玩家触碰标记方块(水平画) → 同onPlayerTouchPainting
    public static void onPlayerTouchPaintingBlock(class_3222 player, class_2338 pos) {
        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        for (PlayerData shubingData : gm.getAllPlayerData().values()) {
            if (shubingData.getRole() != Role.SHUBING) continue;
            int paintIdx = shubingData.findPaintingByPos(pos);
            if (paintIdx < 0) continue;

            PlayerData.ShubingPainting painting = shubingData.getPlacedPaintings().get(paintIdx);
            // 用entityUuid调用统一入口
            onPlayerTouchPainting(player, painting.entityUuid);
            return;
        }
    }

    // 画被破坏 (PaintingEntity死亡 或 标记方块被拆)
    public static void onShubingPaintingBroken(class_3218 world, UUID paintingEntityUuid) {
        GameManager gm = GameManager.getInstance();
        for (PlayerData shubingData : gm.getAllPlayerData().values()) {
            if (shubingData.getRole() != Role.SHUBING) continue;
            int paintIdx = shubingData.findPaintingByEntityUuid(paintingEntityUuid);
            if (paintIdx < 0) continue;

            PlayerData.ShubingPainting painting = shubingData.getPlacedPaintings().get(paintIdx);

            // 如果画有所属通道，封闭对应端
            if (painting.corridorIndex >= 0) {
                PlayerData.ShubingCorridor corridor = shubingData.getCorridors().get(painting.corridorIndex);
                if (painting.corridorEnd == 0) {
                    corridor.end0Sealed = true;
                    sealCorridorEnd(world, corridor, 0);
                } else {
                    corridor.end1Sealed = true;
                    sealCorridorEnd(world, corridor, 1);
                }

                // 检查是否两端都封了→摧毁通道
                if (corridor.end0Sealed && corridor.end1Sealed) {
                    destroyCorridor(world, shubingData, painting.corridorIndex);
                }

                gm.broadcastMessage("§e§l[画中世界] §c一幅画被拆除！对应出口已关闭！");
            }

            // 移除悬浮文字
            removeHologramByTag(world, painting.hologramTag);
            painting.hologramTag = null;

            // 移除画数据(注意: 不能改变list索引因为corridor引用了索引)
            // 标记为已删除(pos=null)
            painting.pos = null;
            painting.corridorIndex = -2; // -2=已删除
            return;
        }
    }

    // 按位置触发画破坏(水平画用)
    public static void onShubingPaintingBlockBroken(class_3218 world, class_2338 pos) {
        GameManager gm = GameManager.getInstance();
        for (PlayerData shubingData : gm.getAllPlayerData().values()) {
            if (shubingData.getRole() != Role.SHUBING) continue;
            int paintIdx = shubingData.findPaintingByPos(pos);
            if (paintIdx < 0) continue;

            PlayerData.ShubingPainting painting = shubingData.getPlacedPaintings().get(paintIdx);
            onShubingPaintingBroken(world, painting.entityUuid);
            return;
        }
    }

    // 封闭通道某一端
    private static void sealCorridorEnd(class_3218 world, PlayerData.ShubingCorridor corridor, int end) {
        class_2338 o = corridor.origin;
        if (corridor.vertical) {
            int sealY = (end == 0) ? 0 : CORRIDOR_LEN - 1;
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    world.method_8501(o.method_10069(x, sealY, z), class_2246.field_10056.method_9564());
                }
            }
        } else {
            int sealX = (end == 0) ? 0 : CORRIDOR_LEN - 1;
            for (int y = 0; y <= 3; y++) {
                for (int z = -1; z <= 1; z++) {
                    world.method_8501(o.method_10069(sealX, y, z), class_2246.field_10056.method_9564());
                }
            }
        }
    }

    // 摧毁整条通道, 踢出所有玩家
    public static void destroyCorridor(class_3218 world, PlayerData shubingData, int corridorIdx) {
        PlayerData.ShubingCorridor corridor = shubingData.getCorridors().get(corridorIdx);
        class_2338 o = corridor.origin;

        // 踢出通道内玩家
        for (Map.Entry<UUID, PlayerData.CorridorEntry> entry :
                new HashMap<>(shubingData.getCorridorPlayers()).entrySet()) {
            if (entry.getValue().corridorIndex == corridorIdx) {
                class_3222 p = GameManager.getInstance().getServer().method_3760().method_14602(entry.getKey());
                if (p != null) {
                    p.method_48105(world, 0.5, 100, 0.5, java.util.Set.of(), 0, 0, false);
                    tip(p, "§c画中世界崩塌！你被传回了现实！");
                }
                shubingData.getCorridorPlayers().remove(entry.getKey());
            }
        }

        // 清除方块
        if (corridor.vertical) {
            for (int y = -1; y <= CORRIDOR_LEN; y++) {
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) {
                        world.method_8501(o.method_10069(x, y, z), class_2246.field_10124.method_9564());
                    }
                }
            }
        } else {
            for (int x = -1; x <= CORRIDOR_LEN; x++) {
                for (int y = 0; y <= 3; y++) {
                    for (int z = -1; z <= 1; z++) {
                        world.method_8501(o.method_10069(x, y, z), class_2246.field_10124.method_9564());
                    }
                }
            }
        }
    }

    // V键: 画中世界传送随机玩家到身旁(2min CD, 必须在画中世界内)
    private static void handleShubingSummon(class_3222 player, PlayerData data) {
        GameManager gm = GameManager.getInstance();
        long currentTick = player.method_51469().method_75260();

        // 检查CD(2分钟=2400tick)
        if (data.getLastShubingSummonTick() > 0 && currentTick - data.getLastShubingSummonTick() < 2400) {
            int secLeft = (int)((2400 - (currentTick - data.getLastShubingSummonTick())) / 20);
            tip(player, "§c画中世界传送冷却中! §e" + secLeft + "秒");
            return;
        }

        // 必须在画中世界内(即在某个通道内)
        boolean inCorridor = false;
        for (PlayerData shubingData : gm.getAllPlayerData().values()) {
            if (shubingData.getRole() != Role.SHUBING) continue;
            if (shubingData.getCorridorPlayers().containsKey(player.method_5667())) {
                inCorridor = true;
                break;
            }
        }
        if (!inCorridor) {
            tip(player, "§c必须在画中世界内才能使用此技能！");
            return;
        }

        // 随机选一个存活的非SHUBING玩家
        List<class_3222> candidates = new ArrayList<>();
        for (PlayerData pd : gm.getAllPlayerData().values()) {
            if (!pd.isAlive()) continue;
            if (pd.getPlayerUuid().equals(player.method_5667())) continue;
            class_3222 target = gm.getServer().method_3760().method_14602(pd.getPlayerUuid());
            if (target != null && !target.method_7325()) {
                // 不传送已在通道内的玩家
                boolean alreadyInCorridor = false;
                for (PlayerData sd : gm.getAllPlayerData().values()) {
                    if (sd.getRole() != Role.SHUBING) continue;
                    if (sd.getCorridorPlayers().containsKey(target.method_5667())) {
                        alreadyInCorridor = true;
                        break;
                    }
                }
                if (!alreadyInCorridor) candidates.add(target);
            }
        }

        if (candidates.isEmpty()) {
            tip(player, "§c没有可传送的玩家！");
            return;
        }

        class_3222 target = candidates.get(new java.util.Random().nextInt(candidates.size()));
        class_3218 world = (class_3218) player.method_51469();
        target.method_48105(world, player.method_23317() + 1.0, player.method_23318(), player.method_23321(),
                java.util.Set.of(), target.method_36454(), target.method_36455(), false);

        data.setLastShubingSummonTick(currentTick);

        // 将目标也注册为通道内玩家(找到SHUBING自己所在的通道)
        for (PlayerData shubingData : gm.getAllPlayerData().values()) {
            if (shubingData.getRole() != Role.SHUBING) continue;
            PlayerData.CorridorEntry myEntry = shubingData.getCorridorPlayers().get(player.method_5667());
            if (myEntry != null) {
                shubingData.getCorridorPlayers().put(target.method_5667(),
                        new PlayerData.CorridorEntry(myEntry.corridorIndex, currentTick, myEntry.enteredFromEnd));
                break;
            }
        }

        target.method_7353(class_2561.method_43470("§c§l你被拉入了画中世界！§e10秒内到达出口否则死亡！"), false);
        gm.broadcastMessage("§e§l[画中世界] §r§c" + target.method_7334().name() + " §e被传送进了画中世界！");
        tip(player, "§a已将 §e" + target.method_7334().name() + " §a传送到画中世界！");
    }

    // ==================== JANE: 赏金猎人 ====================
    // Z: 切换暗黑视域(失明+看到所有人边框)
    // X: 打开商店UI(客户端Screen)
    private static void handleJaneSkill(class_3222 player, PlayerData data, int skillSlot) {
        GameManager gm = GameManager.getInstance();

        if (skillSlot == 0) { // Z: 切换暗黑视域
            data.setDarkVisionActive(!data.isDarkVisionActive());
            if (data.isDarkVisionActive()) {
                tip(player, "§c§l暗黑视域 §a已开启！§7(失明+看到所有人边框)");
                gm.broadcastMessage("§6§l[赏金] §r§e" + player.method_7334().name() + " §7切换到了暗黑视域！");
            } else {
                player.method_6016(net.minecraft.class_1294.field_5919);
                tip(player, "§a常态视域 §a已开启！");
            }
        } else if (skillSlot == 1) { // X: 打开商店UI
            baby.sv.yepvpfabirc.network.NetworkHandler.sendJaneShopData(player, data);
        }
    }

    // ==================== YOUZHA: 油炸意面 ====================
    // Z: 噬元兽(2minCD) — 指针处召唤猫, 1秒吸人, 异次元15秒, 出来扣血扣上限
    // X: 大吃特吃(30sCD) — 消耗5饱食度, 随机buff
    private static void handleYouzhaSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();

        if (skillSlot == 0) { // Z: 噬元兽
            if (currentTick - data.getLastYouzhaUltimateTick() < YOUZHA_ULTIMATE_COOLDOWN) {
                long remaining = (YOUZHA_ULTIMATE_COOLDOWN - (currentTick - data.getLastYouzhaUltimateTick())) / 20;
                tip(player, "§c噬元兽冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastYouzhaUltimateTick(currentTick);

            // Raycast找指针位置(最大50格)
            net.minecraft.class_239 hit = player.method_5745(50.0, 1.0f, false);
            net.minecraft.class_243 spawnPos;
            if (hit.method_17783() == net.minecraft.class_239.class_240.field_1332) {
                class_2338 bp = ((net.minecraft.class_3965) hit).method_17777();
                spawnPos = new net.minecraft.class_243(bp.method_10263() + 0.5, bp.method_10264() + 1, bp.method_10260() + 0.5);
            } else {
                spawnPos = hit.method_17784();
            }

            class_3218 world = player.method_51469();
            // 召唤猫
            net.minecraft.class_1451 cat = net.minecraft.class_1299.field_16281.method_5883(world, net.minecraft.class_3730.field_16461);
            if (cat == null) return;
            cat.method_5808(spawnPos.field_1352, spawnPos.field_1351, spawnPos.field_1350, 0, 0);
            cat.method_5875(false);
            cat.method_5977(true);
            cat.method_5684(true);
            cat.method_5780("youzha_cat_" + player.method_5667());
            cat.method_5780("youzha_cat_absorb_" + (currentTick + 20)); // 1秒后吸人
            world.method_8649(cat);

            GameManager.getInstance().broadcastMessage("§6§l[噬元兽] §r§e" + player.method_7334().name() + " §6召唤了噬元兽！1秒后吞噬周围的人！");
            tip(player, "§6噬元兽已召唤！1秒后吞噬5格内的人！");

        } else if (skillSlot == 1) { // X: 大吃特吃(无CD, 只需饱食度)
            // 检查饱食度
            int foodLevel = player.method_7344().method_7586();
            if (foodLevel < 5) {
                tip(player, "§c饱食度不足！需要5点饱食度(当前" + foodLevel + ")");
                return;
            }
            player.method_7344().method_7580(foodLevel - 5);

            // 随机buff(10秒)
            Random rand = new Random();
            int pick = rand.nextInt(6);
            net.minecraft.class_6880<net.minecraft.class_1291> effect;
            String effectName;
            int amplifier = 0;
            switch (pick) {
                case 0 -> { effect = class_1294.field_5904; effectName = "速度II"; amplifier = 1; }
                case 1 -> { effect = class_1294.field_5913; effectName = "跳跃提升II"; amplifier = 1; }
                case 2 -> { effect = class_1294.field_5924; effectName = "生命恢复II"; amplifier = 1; }
                case 3 -> { effect = class_1294.field_5910; effectName = "力量I"; amplifier = 0; }
                case 4 -> { effect = class_1294.field_5907; effectName = "抗性I"; amplifier = 0; }
                default -> { effect = class_1294.field_5917; effectName = "急迫II"; amplifier = 1; }
            }
            player.method_6092(new class_1293(effect, 200, amplifier, false, true, true)); // 10秒
            tip(player, "§a大吃特吃！消耗5饱食度，获得 §e" + effectName + " §a10秒！");
        }
    }

    // ==================== LAYI: 蜡翼 ====================
    // Z: 激活飞行(每命1次) + 刷3个导弹箱
    // X: 连射20箭(30sCD, 飞行中)
    private static void handleLayiSkill(class_3222 player, PlayerData data, int skillSlot) {
        GameManager gm = GameManager.getInstance();
        if (skillSlot == 0) {
            gm.activateLayiFlight(player, data);
        } else if (skillSlot == 1) {
            gm.activateLayiArrowBarrage(player, data);
        }
    }

    // ==================== MAYPOOR: 天锤 ====================
    // 被动: 免疫摔落伤害(在BaneOfArthropodsMixin中处理)
    // Z: 30sCD 获得创造模式飞行10秒
    // X: 10sCD 下落中激活,落地时制造爆炸(基础0格半径/0伤害, 每下落1格 半径+0.5/伤害+1)
    private static void handleMaypoorSkill(class_3222 player, PlayerData data, int skillSlot) {
        long currentTick = player.method_51469().method_75260();

        if (skillSlot == 0) {
            // Z: 创造飞行
            if (currentTick - data.getLastSkillZTime() < MAYPOOR_FLIGHT_COOLDOWN) {
                long remaining = (MAYPOOR_FLIGHT_COOLDOWN - (currentTick - data.getLastSkillZTime())) / 20;
                tip(player, "§c飞行冷却中... §e" + remaining + "s");
                return;
            }
            data.setLastSkillZTime(currentTick);
            data.setMaypoorFlightEndTick(currentTick + MAYPOOR_FLIGHT_DURATION);

            // 启用创造模式飞行
            player.method_31549().field_7478 = true;
            player.method_31549().field_7479 = true;
            player.method_7355();

            class_3218 world = player.method_51469();
            world.method_8396(null, player.method_24515(),
                    net.minecraft.class_3417.field_14572,
                    net.minecraft.class_3419.field_15248, 1.0f, 1.0f);
            tip(player, "§6§l[天锤] §r§e翱翔！飞行10秒");
            GameManager.getInstance().broadcastMessage("§6§l[天锤] §r§e" + player.method_7334().name() + " §6启动了飞行(10秒)！");

        } else if (skillSlot == 1) {
            // X: 重锤激活(下落时使用)
            if (data.isMaypoorSlamArmed()) {
                tip(player, "§c重锤已激活！等待落地结算");
                return;
            }
            if (currentTick - data.getLastSkillXTime() < MAYPOOR_SLAM_COOLDOWN) {
                long remaining = (MAYPOOR_SLAM_COOLDOWN - (currentTick - data.getLastSkillXTime())) / 20;
                tip(player, "§c重锤冷却中... §e" + remaining + "s");
                return;
            }
            // 必须正在下落: 不在地面 + 下落中(velocityY < 0)
            if (player.method_24828()) {
                tip(player, "§c必须在下落时使用！");
                return;
            }
            // 飞行中不允许使用(避免与创造飞行冲突)
            if (data.isMaypoorFlying(currentTick) || player.method_31549().field_7479) {
                tip(player, "§c飞行中无法使用重锤！");
                return;
            }
            if (player.method_18798().field_1351 >= 0) {
                tip(player, "§c必须在向下坠落时才能使用！");
                return;
            }

            data.setLastSkillXTime(currentTick);
            data.setMaypoorSlamArmed(true);
            data.setMaypoorSlamStartY(player.method_23318());

            class_3218 world = player.method_51469();
            world.method_8396(null, player.method_24515(),
                    net.minecraft.class_3417.field_14717.comp_349(),
                    net.minecraft.class_3419.field_15248, 1.5f, 0.6f);
            tip(player, "§6§l[天锤] §r§c重锤激活！落地时爆炸，下落越高威力越大！");
        }
    }

    // 落地结算: 计算下落距离并制造爆炸(由GameManager.tickMaypoor调用)
    public static void executeMaypoorSlam(class_3222 player, PlayerData data) {
        class_3218 world = player.method_51469();
        double fallDist = Math.max(0, data.getMaypoorSlamStartY() - player.method_23318());
        // 基础: 0伤害 0半径; 每下落1格: 伤害+1, 半径+0.5
        float damage = (float) fallDist;
        float radius = (float) (fallDist * 0.5);
        class_243 pos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());

        // 仅在有意义时才执行(下落>0)
        if (radius > 0) {
            // 视觉/音效爆炸 (不破坏方块, 不造成原生伤害, 我们手动结算)
            world.method_8437(player, pos.field_1352, pos.field_1351, pos.field_1350, radius,
                    net.minecraft.class_1937.class_7867.field_40888);

            // 手动对范围内玩家施加伤害(不打到自己)
            double radSq = radius * radius;
            for (class_3222 target : new ArrayList<>(world.method_18456())) {
                if (target == player || target.method_7325()) continue;
                PlayerData td = GameManager.getInstance().getPlayerData(target.method_5667());
                if (td == null || !td.isAlive()) continue;
                double d2 = target.method_5707(pos);
                if (d2 <= radSq) {
                    target.method_64397(world, world.method_48963().method_48802(player), damage);
                }
            }
        }

        GameManager.getInstance().broadcastMessage("§6§l[天锤] §r§e" + player.method_7334().name()
                + " §6重锤落地！下落 §c" + String.format("%.1f", fallDist) + " §6格，伤害 §c"
                + String.format("%.1f", damage) + "§6, 半径 §c" + String.format("%.1f", radius) + "§6格");

        data.setMaypoorSlamArmed(false);
        data.setMaypoorSlamStartY(0);
    }

    // ==================== Utility ====================
    public static class_3222 findNearestPlayer(class_3222 source, double maxDistance) {
        class_3222 nearest = null;
        double nearestDist = maxDistance * maxDistance;
        for (class_3222 other : source.method_51469().method_18456()) {
            if (other == source) continue;
            PlayerData otherData = GameManager.getInstance().getPlayerData(other.method_5667());
            if (otherData == null || !otherData.isAlive()) continue;
            double dist = other.method_5858(source);
            if (dist < nearestDist) {
                nearestDist = dist;
                nearest = other;
            }
        }
        return nearest;
    }
}
