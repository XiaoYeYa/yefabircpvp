package baby.sv.yepvpfabirc.network;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import baby.sv.yepvpfabirc.skill.SkillHandler;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class NetworkHandler {

    public static final String MOD_PROTOCOL_VERSION = "1.0.0-af2025";

    // 待验证玩家: UUID → 加入时间戳(tick)
    private static final java.util.concurrent.ConcurrentHashMap<java.util.UUID, Long> pendingVersionChecks = new java.util.concurrent.ConcurrentHashMap<>();

    public static final class_2960 SKILL_USE_ID = class_2960.method_60655("yepvpfabirc", "skill_use");
    public static final class_2960 HUD_SYNC_ID = class_2960.method_60655("yepvpfabirc", "hud_sync");
    public static final class_2960 GREETING_RESPONSE_ID = class_2960.method_60655("yepvpfabirc", "greeting_response");
    public static final class_2960 GAME_START_SCREEN_ID = class_2960.method_60655("yepvpfabirc", "game_start_screen");
    public static final class_2960 REVEAL_SCREEN_ID = class_2960.method_60655("yepvpfabirc", "reveal_screen");
    public static final class_2960 SPECTATOR_SWITCH_ID = class_2960.method_60655("yepvpfabirc", "spectator_switch");
    public static final class_2960 MAP_REQUEST_ID = class_2960.method_60655("yepvpfabirc", "map_request");
    public static final class_2960 MAP_DATA_ID = class_2960.method_60655("yepvpfabirc", "map_data");
    public static final class_2960 MAP_TELEPORT_ID = class_2960.method_60655("yepvpfabirc", "map_teleport");
    public static final class_2960 HIDDEN_PLAYERS_ID = class_2960.method_60655("yepvpfabirc", "hidden_players");
    public static final class_2960 JANE_SHOP_ID = class_2960.method_60655("yepvpfabirc", "jane_shop");
    public static final class_2960 JANE_SHOP_BUY_ID = class_2960.method_60655("yepvpfabirc", "jane_shop_buy");
    public static final class_2960 VERSION_CHECK_ID = class_2960.method_60655("yepvpfabirc", "version_check");
    public static final class_2960 VERSION_RESPONSE_ID = class_2960.method_60655("yepvpfabirc", "version_response");

    public record SkillUsePayload(int skillSlot) implements class_8710 {
        public static final class_9154<SkillUsePayload> ID = new class_9154<>(SKILL_USE_ID);
        public static final class_9139<class_2540, SkillUsePayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10804(value.skillSlot),
                buf -> new SkillUsePayload(buf.method_10816())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record HudSyncPayload(String jsonData) implements class_8710 {
        public static final class_9154<HudSyncPayload> ID = new class_9154<>(HUD_SYNC_ID);
        public static final class_9139<class_2540, HudSyncPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10814(value.jsonData),
                buf -> new HudSyncPayload(buf.method_19772())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record GameStartScreenPayload(String jsonData) implements class_8710 {
        public static final class_9154<GameStartScreenPayload> ID = new class_9154<>(GAME_START_SCREEN_ID);
        public static final class_9139<class_2540, GameStartScreenPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10814(value.jsonData),
                buf -> new GameStartScreenPayload(buf.method_19772())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record RevealScreenPayload(String jsonData) implements class_8710 {
        public static final class_9154<RevealScreenPayload> ID = new class_9154<>(REVEAL_SCREEN_ID);
        public static final class_9139<class_2540, RevealScreenPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10814(value.jsonData),
                buf -> new RevealScreenPayload(buf.method_19772())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record GreetingResponsePayload(boolean accepted) implements class_8710 {
        public static final class_9154<GreetingResponsePayload> ID = new class_9154<>(GREETING_RESPONSE_ID);
        public static final class_9139<class_2540, GreetingResponsePayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_52964(value.accepted),
                buf -> new GreetingResponsePayload(buf.readBoolean())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record MapRequestPayload(boolean dummy) implements class_8710 {
        public static final class_9154<MapRequestPayload> ID = new class_9154<>(MAP_REQUEST_ID);
        public static final class_9139<class_2540, MapRequestPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_52964(value.dummy),
                buf -> new MapRequestPayload(buf.readBoolean())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record MapDataPayload(byte[] data) implements class_8710 {
        public static final class_9154<MapDataPayload> ID = new class_9154<>(MAP_DATA_ID);
        public static final class_9139<class_2540, MapDataPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10813(value.data),
                buf -> new MapDataPayload(buf.method_10803(2097152)) // 2MB max
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // HELI全视之眼期间地图传送
    public record MapTeleportPayload(int x, int z) implements class_8710 {
        public static final class_9154<MapTeleportPayload> ID = new class_9154<>(MAP_TELEPORT_ID);
        public static final class_9139<class_2540, MapTeleportPayload> CODEC = class_9139.method_56438(
                (value, buf) -> { buf.method_53002(value.x); buf.method_53002(value.z); },
                buf -> new MapTeleportPayload(buf.readInt(), buf.readInt())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // 完全隐身玩家列表(S2C): 装备+手持+模型全部隐藏
    public record HiddenPlayersPayload(byte[] data) implements class_8710 {
        public static final class_9154<HiddenPlayersPayload> ID = new class_9154<>(HIDDEN_PLAYERS_ID);
        public static final class_9139<class_2540, HiddenPlayersPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10813(value.data),
                buf -> new HiddenPlayersPayload(buf.method_10795())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // JANE商店数据(S2C): bounty + 三项升级等级
    public record JaneShopPayload(int bounty, int power, int quickCharge, int multishot) implements class_8710 {
        public static final class_9154<JaneShopPayload> ID = new class_9154<>(JANE_SHOP_ID);
        public static final class_9139<class_2540, JaneShopPayload> CODEC = class_9139.method_56438(
                (value, buf) -> { buf.method_10804(value.bounty); buf.method_10804(value.power); buf.method_10804(value.quickCharge); buf.method_10804(value.multishot); },
                buf -> new JaneShopPayload(buf.method_10816(), buf.method_10816(), buf.method_10816(), buf.method_10816())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // JANE商店购买(C2S): 0=power, 1=quickCharge, 2=multishot
    public record JaneShopBuyPayload(int upgradeType) implements class_8710 {
        public static final class_9154<JaneShopBuyPayload> ID = new class_9154<>(JANE_SHOP_BUY_ID);
        public static final class_9139<class_2540, JaneShopBuyPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10804(value.upgradeType),
                buf -> new JaneShopBuyPayload(buf.method_10816())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // 版本检查(S2C): 服务端发送协议版本
    public record VersionCheckPayload(String version) implements class_8710 {
        public static final class_9154<VersionCheckPayload> ID = new class_9154<>(VERSION_CHECK_ID);
        public static final class_9139<class_2540, VersionCheckPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10814(value.version),
                buf -> new VersionCheckPayload(buf.method_19772())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // 版本响应(C2S): 客户端回复自己的协议版本
    public record VersionResponsePayload(String version) implements class_8710 {
        public static final class_9154<VersionResponsePayload> ID = new class_9154<>(VERSION_RESPONSE_ID);
        public static final class_9139<class_2540, VersionResponsePayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10814(value.version),
                buf -> new VersionResponsePayload(buf.method_19772())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // direction: 1=next, -1=prev, 0=free camera
    public record SpectatorSwitchPayload(int direction) implements class_8710 {
        public static final class_9154<SpectatorSwitchPayload> ID = new class_9154<>(SPECTATOR_SWITCH_ID);
        public static final class_9139<class_2540, SpectatorSwitchPayload> CODEC = class_9139.method_56438(
                (value, buf) -> buf.method_10804(value.direction),
                buf -> new SpectatorSwitchPayload(buf.method_10816())
        );
        @Override
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public static void registerServer() {
        PayloadTypeRegistry.playC2S().register(SkillUsePayload.ID, SkillUsePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(GreetingResponsePayload.ID, GreetingResponsePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(VersionResponsePayload.ID, VersionResponsePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(VersionCheckPayload.ID, VersionCheckPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SpectatorSwitchPayload.ID, SpectatorSwitchPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MapRequestPayload.ID, MapRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MapTeleportPayload.ID, MapTeleportPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HudSyncPayload.ID, HudSyncPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MapDataPayload.ID, MapDataPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(GameStartScreenPayload.ID, GameStartScreenPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(RevealScreenPayload.ID, RevealScreenPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HiddenPlayersPayload.ID, HiddenPlayersPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(JaneShopPayload.ID, JaneShopPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(JaneShopBuyPayload.ID, JaneShopBuyPayload.CODEC);

        // 版本响应处理
        ServerPlayNetworking.registerGlobalReceiver(VersionResponsePayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                if (!payload.version().equals(MOD_PROTOCOL_VERSION)) {
                    player.field_13987.method_52396(net.minecraft.class_2561.method_43470(
                            "§c§l版本不匹配！\n§r§e服务端版本: " + MOD_PROTOCOL_VERSION +
                            "\n§e你的版本: " + payload.version() +
                            "\n\n§f请安装愚人活动最新模组！"));
                } else {
                    pendingVersionChecks.remove(player.method_5667());
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SkillUsePayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                GameManager gm = GameManager.getInstance();
                if (!gm.isGameActive()) return;
                PlayerData data = gm.getPlayerData(player.method_5667());
                if (data == null || !data.isAlive()) return;
                SkillHandler.handleSkill(player, data, payload.skillSlot());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(MapRequestPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                GameManager gm = GameManager.getInstance();
                if (!gm.isGameActive()) return;
                net.minecraft.class_3218 world = player.method_51469();
                byte[] mapData = baby.sv.yepvpfabirc.game.MapDataCollector.buildMapData(world, player.method_5667());
                ServerPlayNetworking.send(player, new MapDataPayload(mapData));
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(MapTeleportPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                GameManager gm = GameManager.getInstance();
                if (!gm.isGameActive()) return;
                PlayerData data = gm.getPlayerData(player.method_5667());
                if (data == null || !data.isAlive()) return;
                // HELI: 地图点击传送到最近被揭露的玩家
                if (data.getRole() == Role.HELI) {
                    gm.handleHeliMapTeleport(player, data, payload.x(), payload.z());
                }
                // POPCORN: 地图点击触发轨道镭射
                if (data.getRole() == Role.POPCORN) {
                    gm.popcornTriggerLaser(player, data, payload.x(), payload.z());
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(JaneShopBuyPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                GameManager gm = GameManager.getInstance();
                if (!gm.isGameActive()) return;
                PlayerData data = gm.getPlayerData(player.method_5667());
                if (data == null || !data.isAlive() || data.getRole() != Role.JANE) return;
                gm.handleJaneShopBuy(player, data, payload.upgradeType());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SpectatorSwitchPayload.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                GameManager gm = GameManager.getInstance();
                if (!gm.isGameActive()) return;
                if (!player.method_7325()) return;
                gm.handleSpectatorSwitch(player, payload.direction());
            });
        });
    }

    public static void syncHudToPlayer(class_3222 player, String jsonData) {
        ServerPlayNetworking.send(player, new HudSyncPayload(jsonData));
    }

    public static void sendGameStartScreen(class_3222 player, String jsonData) {
        ServerPlayNetworking.send(player, new GameStartScreenPayload(jsonData));
    }

    public static void sendRevealScreen(class_3222 player, String jsonData) {
        ServerPlayNetworking.send(player, new RevealScreenPayload(jsonData));
    }

    public static void sendMapData(class_3222 player, byte[] data) {
        ServerPlayNetworking.send(player, new MapDataPayload(data));
    }

    public static void sendHiddenPlayers(class_3222 player, byte[] data) {
        ServerPlayNetworking.send(player, new HiddenPlayersPayload(data));
    }

    public static void sendVersionCheck(class_3222 player) {
        pendingVersionChecks.put(player.method_5667(), GameManager.getInstance().getServerTime());
        ServerPlayNetworking.send(player, new VersionCheckPayload(MOD_PROTOCOL_VERSION));
    }

    // 每tick检查超时(5秒=100tick未回复则踢出)
    public static void tickVersionChecks(net.minecraft.server.MinecraftServer server) {
        long currentTick = server.method_30002().method_75260();
        var iter = pendingVersionChecks.entrySet().iterator();
        while (iter.hasNext()) {
            var entry = iter.next();
            if (currentTick - entry.getValue() > 100) { // 5秒超时
                iter.remove();
                class_3222 player = server.method_3760().method_14602(entry.getKey());
                if (player != null) {
                    player.field_13987.method_52396(net.minecraft.class_2561.method_43470(
                            "§c§l未检测到愚人活动模组！\n\n§f请安装愚人活动最新模组！"));
                }
            }
        }
    }

    public static void sendJaneShopData(class_3222 player, PlayerData data) {
        ServerPlayNetworking.send(player, new JaneShopPayload(
                data.getBounty(), data.getCrossbowPower(), data.getCrossbowQuickCharge(), data.getCrossbowMultishot()));
    }
}
