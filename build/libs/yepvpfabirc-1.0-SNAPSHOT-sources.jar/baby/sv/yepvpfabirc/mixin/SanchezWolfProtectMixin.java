package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1493;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class SanchezWolfProtectMixin {

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void onSanchezWolfDamage(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309) (Object) this;
        if (!(self instanceof class_1493 wolf)) return;

        // 只处理带sanchez标签的狼
        boolean isSanchezWolf = wolf.method_5752().stream().anyMatch(t -> t.startsWith("sanchez_"));
        if (!isSanchezWolf) return;

        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        // 获取伤害来源实体
        net.minecraft.class_1297 attacker = source.method_5529();
        if (attacker == null) return;

        // 1. SANCHEZ玩家不能伤害自己的狼
        if (attacker instanceof class_3222 player) {
            PlayerData data = gm.getPlayerData(player.method_5667());
            if (data != null && data.getRole() == Role.SANCHEZ) {
                // 检查这只狼是否属于该玩家(通过commandTag)
                String playerUuidStr = player.method_5667().toString();
                if (wolf.method_5752().stream().anyMatch(t -> t.contains(playerUuidStr))) {
                    cir.setReturnValue(false);
                    return;
                }
            }
        }

        // 2. SANCHEZ的狼不能伤害同主人的友方狼
        if (attacker instanceof class_1493 attackerWolf) {
            boolean attackerIsSanchez = attackerWolf.method_5752().stream().anyMatch(t -> t.startsWith("sanchez_"));
            if (attackerIsSanchez) {
                // 提取两只狼的主人UUID(从tag中解析)
                String selfOwner = extractOwnerFromTags(wolf);
                String attackerOwner = extractOwnerFromTags(attackerWolf);
                if (selfOwner != null && selfOwner.equals(attackerOwner)) {
                    cir.setReturnValue(false);
                    return;
                }
            }
        }
    }

    // SANCHEZ狼攻击非狼实体: 使用正常物理伤害(狼的ATTACK_DAMAGE属性已设为6.0=3心)
    // 不再拦截, 让狼自然攻击(这样击杀检测也能正常工作)

    @org.spongepowered.asm.mixin.Unique
    private static String extractOwnerFromTags(class_1493 wolf) {
        for (String tag : wolf.method_5752()) {
            if (tag.startsWith("sanchez_alpha_")) return tag.substring("sanchez_alpha_".length());
            if (tag.startsWith("sanchez_pack_")) return tag.substring("sanchez_pack_".length());
        }
        return null;
    }
}
