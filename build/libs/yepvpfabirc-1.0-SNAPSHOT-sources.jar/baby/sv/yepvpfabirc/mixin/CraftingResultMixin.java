package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import net.minecraft.class_1657;
import net.minecraft.class_1734;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1734.class)
public abstract class CraftingResultMixin {

    @Inject(method = "onTakeItem", at = @At("HEAD"), cancellable = true)
    private void onPreventChestCraft(class_1657 player, class_1799 stack, CallbackInfo ci) {
        if (!GameManager.getInstance().isGameActive()) return;
        if (stack.method_31574(class_1802.field_8106) || stack.method_31574(class_1802.field_8247)) {
            stack.method_7939(0);
            ci.cancel();
            player.method_7353(net.minecraft.class_2561.method_43470("§c游戏中禁止合成箱子！"), true);
        }
    }
}
