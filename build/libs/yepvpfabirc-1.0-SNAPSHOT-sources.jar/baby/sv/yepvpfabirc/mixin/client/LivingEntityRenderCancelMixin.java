package baby.sv.yepvpfabirc.mixin.client;

import baby.sv.yepvpfabirc.client.hud.HiddenPlayersCache;
import baby.sv.yepvpfabirc.client.hud.HudDataCache;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_922;

// LivingEntityRenderer重写了EntityRenderer.render(), 必须在此注入才能拦截玩家渲染
@Mixin(class_922.class)
public abstract class LivingEntityRenderCancelMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(class_10042 state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
        if (!HudDataCache.isGameActive()) return;
        UUID uuid = HiddenPlayersCache.getStateUuid(state);
        if (uuid == null) return;
        class_310 mc = class_310.method_1551();
        // 自己不隐藏(本地玩家看得到自己)
        if (mc.field_1724 != null && mc.field_1724.method_5667().equals(uuid)) return;
        // 旁观者可以看到所有隐身玩家
        if (mc.field_1724 != null && mc.field_1724.method_7325()) return;
        // 检查服务端同步的完全隐身列表
        if (HiddenPlayersCache.isHidden(uuid)) {
            ci.cancel();
        }
    }
}
