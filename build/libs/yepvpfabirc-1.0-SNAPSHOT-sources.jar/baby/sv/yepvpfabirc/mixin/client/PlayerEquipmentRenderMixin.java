package baby.sv.yepvpfabirc.mixin.client;

import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_922.class)
public abstract class PlayerEquipmentRenderMixin {
    // 隐身渲染取消已移至EntityRenderCancelMixin(基于EntityRenderDispatcher)
    // 此mixin保留为空以兼容mixin配置
}

