package baby.sv.yepvpfabirc.mixin.client;

import baby.sv.yepvpfabirc.client.hud.HudDataCache;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class WallClimbMixin {

    @Inject(method = "isClimbing", at = @At("HEAD"), cancellable = true)
    private void onIsClimbing(CallbackInfoReturnable<Boolean> cir) {
        class_1657 self = (class_1657) (Object) this;
        if (!HudDataCache.isGameActive()) return;
        if (!"jiezu".equals(HudDataCache.getSelfRoleId())) return;

        if (self.field_5976 && !self.method_24828()) {
            cir.setReturnValue(true);
        }
    }
}
