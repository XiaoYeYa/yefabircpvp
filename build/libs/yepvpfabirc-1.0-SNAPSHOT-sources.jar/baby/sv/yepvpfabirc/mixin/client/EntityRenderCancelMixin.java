package baby.sv.yepvpfabirc.mixin.client;

import baby.sv.yepvpfabirc.client.hud.HiddenPlayersCache;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// getAndUpdateRenderState定义在EntityRenderer且未被子类重写,在此捕获Entity UUID
@Mixin(class_897.class)
public abstract class EntityRenderCancelMixin {

    @Inject(method = "getAndUpdateRenderState", at = @At("RETURN"))
    private void onGetAndUpdateRenderState(class_1297 entity, float tickDelta, CallbackInfoReturnable<class_10017> cir) {
        if (entity instanceof class_1657) {
            HiddenPlayersCache.putStateUuid(cir.getReturnValue(), entity.method_5667());
        }
    }
}
