package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.skill.SkillHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public abstract class BlockInteractMixin {

    // 拦截玩家右键方块 - 如果是紫水晶方块(水平画)则进入画中世界
    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void onInteractBlock(class_3222 player, class_1937 world, net.minecraft.class_1799 stack,
                                  class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (world.method_8608()) return;
        if (!GameManager.getInstance().isGameActive()) return;

        // 基头四召唤器: 右键使用回响碎片
        if (stack.method_31574(net.minecraft.class_1802.field_38746)) {
            net.minecraft.class_2561 customName = stack.method_58694(net.minecraft.class_9334.field_49631);
            if (customName != null && customName.getString().contains("基头四召唤器")) {
                baby.sv.yepvpfabirc.game.PlayerData data = GameManager.getInstance().getPlayerData(player.method_5667());
                if (data != null && data.isAlive()) {
                    stack.method_7934(1);
                    GameManager.getInstance().spawnMachaWardens(player);
                    cir.setReturnValue(class_1269.field_5812);
                    return;
                }
            }
        }

        class_2338 pos = hitResult.method_17777();
        if (world.method_8320(pos).method_27852(class_2246.field_27159)) {
            SkillHandler.onPlayerTouchPaintingBlock(player, pos);
            cir.setReturnValue(class_1269.field_5812);
            return;
        }

        // 箱子战利品生成: 打开空箱子时自动填充
        if (world.method_8320(pos).method_27852(class_2246.field_10034) || world.method_8320(pos).method_27852(class_2246.field_10380)) {
            GameManager.getInstance().onChestOpen(player, pos, (net.minecraft.class_3218) world);
        }
    }
}
