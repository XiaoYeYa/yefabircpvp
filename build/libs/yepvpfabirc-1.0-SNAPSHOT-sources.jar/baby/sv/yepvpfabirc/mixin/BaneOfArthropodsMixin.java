package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import net.minecraft.class_1282;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3222.class)
public abstract class BaneOfArthropodsMixin {

    @org.spongepowered.asm.mixin.Unique
    private boolean yepvp_inDamageHandler = false;

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void onDamage(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (yepvp_inDamageHandler) return;
        class_3222 self = (class_3222) (Object) this;
        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        PlayerData selfData = gm.getPlayerData(self.method_5667());
        if (selfData == null) return;

        // 复活无敌期间免疫所有伤害
        long currentTick = world.method_75260();
        if (selfData.isInvincible(currentTick)) {
            cir.setReturnValue(false);
            return;
        }

        // 男娘+鱼碎互伤免疫: 男娘不能伤害男娘, 男娘不能伤害鱼碎, 鱼碎不能伤害男娘
        if (source.method_5529() instanceof class_3222 attacker) {
            PlayerData attackerData = gm.getPlayerData(attacker.method_5667());
            if (attackerData != null) {
                boolean attackerIsFemboy = attackerData.isNanniang() || attackerData.getRole() == Role.YUSUI;
                boolean victimIsFemboy = selfData.isNanniang() || selfData.getRole() == Role.YUSUI;
                if (attackerIsFemboy && victimIsFemboy) {
                    cir.setReturnValue(false);
                    return;
                }
            }
        }

        // SANCHEZ: 头狼代承伤害 — 将伤害转移到头狼实体
        if (selfData.getRole() == Role.SANCHEZ && !selfData.isAlphaWolfDead() && selfData.getAlphaWolfEntityUuid() != null) {
            net.minecraft.class_1297 alphaEntity = world.method_66347(selfData.getAlphaWolfEntityUuid());
            if (alphaEntity instanceof net.minecraft.class_1309 alphaWolf && alphaWolf.method_5805()) {
                // 伤害转移到头狼
                alphaWolf.method_64397(world, source, amount);
                // 同步头狼血量到PlayerData
                selfData.setAlphaWolfHealth(alphaWolf.method_6032());
                cir.setReturnValue(false); // 玩家不受伤
                return;
            }
        }

        // HELI揭露双倍伤害: 被揭露前15秒内受到的所有伤害翻倍
        for (PlayerData heliData : gm.getAllPlayerData().values()) {
            if (heliData.getRole() != Role.HELI) continue;
            if (heliData.isInHeliDoubleDamageWindow(self.method_5667(), currentTick)) {
                // 额外施加等量伤害(翻倍效果): 直接扣血绕过护甲
                float bonusDamage = amount;
                float newHp = Math.max(self.method_6032() - bonusDamage, 0);
                self.method_6033(newHp);
                if (newHp <= 0) {
                    yepvp_inDamageHandler = true;
                    try {
                        self.method_5768(world);
                    } finally {
                        yepvp_inDamageHandler = false;
                    }
                }
                break;
            }
        }

        // LAYI: 飞行中受伤不打断飞行
        if (selfData.getRole() == Role.LAYI && selfData.isLayiFlying() && self.method_6128()) {
            // 让伤害正常结算, 但之后立刻恢复飞行状态(通过标记, 在tick中恢复)
            // MC默认受伤会取消鞘翅飞行, 我们在伤害结算后立刻恢复
        }

        // MAYPOOR: 免疫摔落伤害(被动)
        if (selfData.getRole() == Role.MAYPOOR && source == world.method_48963().method_48827()) {
            cir.setReturnValue(false);
            return;
        }

        // 蜡翼箭矢命中: 5% maxHP真伤
        if (source.method_5526() instanceof net.minecraft.class_1667 arrow) {
            for (String tag : arrow.method_5752()) {
                if (tag.startsWith("layi_arrow_")) {
                    String layiUuidStr = tag.substring("layi_arrow_".length());
                    try {
                        java.util.UUID layiUuid = java.util.UUID.fromString(layiUuidStr);
                        class_3222 layiPlayer = world.method_8503().method_3760().method_14602(layiUuid);
                        if (layiPlayer != null && self != layiPlayer) {
                            float trueDmg = self.method_6063() * 0.05f;
                            float newHealth = Math.max(self.method_6032() - trueDmg, 0);
                            self.method_6033(newHealth);
                            if (newHealth <= 0) {
                                yepvp_inDamageHandler = true;
                                try { self.method_5768(world); } finally { yepvp_inDamageHandler = false; }
                            }
                            arrow.method_31472();
                            cir.setReturnValue(false); // 取消原始伤害, 我们已手动扣血
                            return;
                        }
                    } catch (Exception ignored) {}
                    break;
                }
            }
        }

        // 以下是节足专属逻辑
        if (selfData.getRole() != Role.JIEZU) return;

        // 免疫掉落伤害
        if (source == world.method_48963().method_48827()) {
            cir.setReturnValue(false);
            return;
        }

        // 节肢杀手秒杀
        if (!(source.method_5529() instanceof class_3222 attacker)) return;

        class_1799 weapon = attacker.method_6047();
        var bane = world.method_30349().method_30530(class_7924.field_41265).method_46746(class_1893.field_9112).orElse(null);
        if (bane != null) {
            int level = weapon.method_58657().method_57536(bane);
            if (level > 0) {
                self.method_5768(world);
                gm.broadcastMessage("§a" + self.method_7334().name() + " §c被节肢杀手秒杀了！");
                cir.setReturnValue(true);
            }
        }
    }
}
