package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1493;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1493.class)
public abstract class SanchezWolfFeedMixin {

    @Inject(method = "interactMob", at = @At("HEAD"), cancellable = true)
    private void onInteractSanchezWolf(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        class_1493 self = (class_1493) (Object) this;

        // 只拦截SANCHEZ的狼
        boolean isSanchezWolf = self.method_5752().stream().anyMatch(t -> t.startsWith("sanchez_"));
        if (!isSanchezWolf) return;

        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        // 禁止SANCHEZ玩家喂自己的狼(阻止恢复生命)
        if (player instanceof class_3222 sp) {
            PlayerData data = gm.getPlayerData(sp.method_5667());
            if (data != null && data.getRole() == Role.SANCHEZ) {
                String playerUuidStr = sp.method_5667().toString();
                if (self.method_5752().stream().anyMatch(t -> t.contains(playerUuidStr))) {
                    cir.setReturnValue(class_1269.field_5814);
                }
            }
        }
    }
}
