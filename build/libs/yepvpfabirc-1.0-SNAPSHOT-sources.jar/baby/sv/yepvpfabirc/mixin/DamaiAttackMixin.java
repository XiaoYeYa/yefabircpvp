package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import baby.sv.yepvpfabirc.skill.SkillHandler;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class DamaiAttackMixin {

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void onAttack(class_1297 target, CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        PlayerData selfData = gm.getPlayerData(self.method_5667());
        if (selfData == null) return;

        // SANCHEZ攻击时通知狼群锁定目标(对任何实体生效)
        if (selfData.getRole() == Role.SANCHEZ) {
            gm.onSanchezPlayerAttack(self, target);
        }

        if (!(target instanceof class_3222 targetPlayer)) return;
        PlayerData targetData = gm.getPlayerData(targetPlayer.method_5667());

        // 复活无敌期间无法攻击也无法被攻击
        long currentTick = self.method_51469().method_75260();
        if (selfData.isInvincible(currentTick)) {
            self.method_7353(net.minecraft.class_2561.method_43470("§c复活无敌期间无法攻击！"), true);
            ci.cancel();
            return;
        }
        if (targetData != null && targetData.isInvincible(currentTick)) {
            self.method_7353(net.minecraft.class_2561.method_43470("§c对方处于复活无敌期！"), true);
            ci.cancel();
            return;
        }

        // JVJV红莲华蓄力期间无法攻击
        if (selfData.getRole() == Role.JVJV && selfData.isRedLotusCharging(currentTick)) {
            self.method_7353(net.minecraft.class_2561.method_43470("§c红莲华蓄力中，无法操作！"), true);
            ci.cancel();
            return;
        }

        // ST声波蓄力期间无法攻击
        if (selfData.getRole() == Role.ST && selfData.getSonicPendingTick() > 0) {
            self.method_7353(net.minecraft.class_2561.method_43470("§c声波蓄力中，无法攻击！"), true);
            ci.cancel();
            return;
        }

        // Heli攻击揭露对方位置
        if (selfData.getRole() == Role.HELI) {
            SkillHandler.heliRevealOnAttack(self, targetPlayer);
        }

        // DASHA攻击后显形2秒
        if (selfData.getRole() == Role.DASHA) {
            selfData.setDashaVisibleUntilTick(currentTick + 40); // 2秒
        }
    }
}
