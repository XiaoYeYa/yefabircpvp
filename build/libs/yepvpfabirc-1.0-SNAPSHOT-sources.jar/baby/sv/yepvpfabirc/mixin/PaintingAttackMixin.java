package baby.sv.yepvpfabirc.mixin;

import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3222.class)
public abstract class PaintingAttackMixin {
}
