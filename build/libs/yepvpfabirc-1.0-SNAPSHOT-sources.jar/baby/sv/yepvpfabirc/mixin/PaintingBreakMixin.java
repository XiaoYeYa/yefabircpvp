package baby.sv.yepvpfabirc.mixin;

import net.minecraft.class_1534;
// 不再使用PaintingEntity,画统一用AMETHYST_BLOCK标记方块
// 破坏检测由GlassBreakMixin处理
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1534.class)
public abstract class PaintingBreakMixin {
}
