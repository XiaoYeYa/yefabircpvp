package baby.sv.yepvpfabirc.mixin;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
    @Accessor("riptideTicks")
    int getRiptideTicks();
}
