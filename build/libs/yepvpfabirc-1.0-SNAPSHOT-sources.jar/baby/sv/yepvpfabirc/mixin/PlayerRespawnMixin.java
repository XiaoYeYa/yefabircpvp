package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3324.class)
public abstract class PlayerRespawnMixin {

    @Inject(method = "respawnPlayer", at = @At("RETURN"))
    private void onRespawn(class_3222 player, boolean alive, class_1297.class_5529 removalReason, CallbackInfoReturnable<class_3222> cir) {
        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;
        class_3222 respawned = cir.getReturnValue();
        gm.respawnPlayer(respawned);
    }
}
