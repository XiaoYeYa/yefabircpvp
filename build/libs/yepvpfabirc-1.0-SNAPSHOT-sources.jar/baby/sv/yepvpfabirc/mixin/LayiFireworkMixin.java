package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1781;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

@Mixin(class_1781.class)
public class LayiFireworkMixin {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void onFireworkUse(class_1937 world, class_1657 user, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (world.method_8608() || !(user instanceof class_3222 player)) return;
        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        class_1799 stack = player.method_5998(hand);
        class_9290 lore = stack.method_58694(class_9334.field_49632);
        if (lore == null) return;

        List<class_2561> lines = lore.comp_2400();
        for (class_2561 line : lines) {
            String raw = line.getString();
            int idx = raw.indexOf("LAYI_MISSILE:");
            if (idx >= 0) {
                String uuidStr = raw.substring(idx + "LAYI_MISSILE:".length()).trim();
                // 去除可能残留的§格式码
                uuidStr = uuidStr.replaceAll("§[0-9a-fk-or]", "");
                try {
                    UUID layiUuid = UUID.fromString(uuidStr);
                    // 消耗烟花
                    stack.method_7934(1);
                    // 触发导弹发射
                    gm.onLayiMissileFireworkUsed(player, layiUuid);
                    cir.setReturnValue(class_1269.field_5812);
                } catch (Exception ignored) {}
                return;
            }
        }
    }
}
