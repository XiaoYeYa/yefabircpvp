package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1680;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

@Mixin(class_1680.class)
public abstract class SnowballHitMixin {

    @Inject(method = "onEntityHit", at = @At("HEAD"))
    private void onSnowballHit(class_3966 entityHitResult, CallbackInfo ci) {
        class_1680 snowball = (class_1680) (Object) this;
        class_1297 owner = snowball.method_24921();
        class_1297 target = entityHitResult.method_17782();

        if (!(owner instanceof class_3222 thrower)) return;
        if (!(target instanceof class_3222 victim)) return;

        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        PlayerData throwerData = gm.getPlayerData(thrower.method_5667());
        if (throwerData == null) return;

        // JIEZU: 蜘蛛茧晕眩5秒(完全定身+无法攻击)
        if (throwerData.getRole() == Role.JIEZU) {
            PlayerData victimData = gm.getPlayerData(victim.method_5667());
            if (victimData != null) {
                long currentTick = victim.method_51469().method_75260();
                victimData.setStunUntilTick(currentTick + 100); // 5秒定身
            }
            victim.method_6092(new class_1293(class_1294.field_5909, 100, 255, false, false, true));
            victim.method_6092(new class_1293(class_1294.field_5919, 100, 0, false, false, true));
            victim.method_6092(new class_1293(class_1294.field_5911, 100, 255, false, false, true));
            victim.method_6092(new class_1293(class_1294.field_5901, 100, 255, false, false, true));
            thrower.method_7353(net.minecraft.class_2561.method_43470("§a蜘蛛茧命中 " + victim.method_7334().name() + "！对方晕眩5秒！"), true);
            victim.method_7353(net.minecraft.class_2561.method_43470("§c§l你被蜘蛛茧命中！无法移动和攻击5秒！"), true);
        }

        // YUSUI: 男娘雪球命中
        if (throwerData.getRole() == Role.YUSUI) {
            baby.sv.yepvpfabirc.skill.SkillHandler.onYusuiSnowballHit(thrower, victim);
        }
    }

    @Inject(method = "onCollision", at = @At("HEAD"))
    private void onSnowballCollision(class_239 hitResult, CallbackInfo ci) {
        class_1680 snowball = (class_1680) (Object) this;
        if (snowball.method_73183().method_8608()) return;

        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        // 检查是否为ALLAND颜料弹
        int[] colorData = gm.getPaintProjectileColor(snowball.method_5628());
        UUID ownerUuid = gm.getPaintProjectileOwner(snowball.method_5628());
        if (colorData == null || ownerUuid == null) return;

        int color = colorData[0];

        // 获取命中位置
        class_2338 hitPos;
        if (hitResult.method_17783() == class_239.class_240.field_1332) {
            hitPos = ((class_3965) hitResult).method_17777();
        } else {
            hitPos = snowball.method_24515();
        }

        gm.onPaintProjectileHit(hitPos, color, ownerUuid);
    }
}
