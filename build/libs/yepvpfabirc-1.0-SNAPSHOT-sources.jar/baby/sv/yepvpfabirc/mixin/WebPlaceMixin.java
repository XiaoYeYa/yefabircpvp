package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2248.class)
public abstract class WebPlaceMixin {

    @Inject(method = "onPlaced", at = @At("HEAD"))
    private void onBlockPlaced(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack, CallbackInfo ci) {
        if (world.method_8608()) return;
        if (!GameManager.getInstance().isGameActive()) return;
        if (!state.method_27852(class_2246.field_10343)) return;
        if (!(placer instanceof class_3222 player)) return;

        PlayerData data = GameManager.getInstance().getPlayerData(player.method_5667());
        if (data == null || data.getRole() != Role.JIEZU) return;

        if (data.getWebPositions().size() >= 3) {
            // 已放置3个，移除最旧的
            class_2338 oldest = data.getWebPositions().remove(0);
            world.method_8501(oldest, class_2246.field_10124.method_9564());
            player.method_7353(net.minecraft.class_2561.method_43470("§c最旧的蛛网被替换！"), true);
        }
        data.getWebPositions().add(pos);
        player.method_7353(net.minecraft.class_2561.method_43470("§a放置了特殊蛛网！(" + data.getWebPositions().size() + "/3) 位置: " + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260()), false);
        GameManager.getInstance().broadcastMessage("§8§l[节足动物] §r§e" + player.method_7334().name() + " §8放置了特殊蛛网！");
    }
}
