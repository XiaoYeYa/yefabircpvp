package baby.sv.yepvpfabirc.mixin;

import net.minecraft.class_1671;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1671.class)
public interface FireworkRocketEntityAccessor {
    @Accessor("lifeTime")
    void setLifeTime(int lifeTime);

    @Accessor("life")
    int getLife();

    @Accessor("life")
    void setLife(int life);
}
