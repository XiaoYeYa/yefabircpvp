package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class)
public abstract class AmethystBreakSpeedMixin {

    @Inject(method = "calcBlockBreakingDelta", at = @At("RETURN"), cancellable = true)
    private void boostAmethystBreaking(class_2680 state, class_1657 player, class_1922 world, class_2338 pos,
                                        CallbackInfoReturnable<Float> cir) {
        if (!GameManager.getInstance().isGameActive()) return;
        if (state.method_27852(class_2246.field_27159)) {
            // 紫水晶方块挖掘速度提高5倍(让画更容易被破坏)
            cir.setReturnValue(cir.getReturnValue() * 5.0f);
        }
    }
}
