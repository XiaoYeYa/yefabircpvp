package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import net.minecraft.class_1282;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class PlayerDeathMixin {

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onPlayerDeath(class_1282 damageSource, CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return;

        class_3222 killer = null;
        if (damageSource.method_5529() instanceof class_3222 attackerPlayer) {
            killer = attackerPlayer;
        }
        gm.onPlayerDeath(self, killer);
    }
}
