package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import net.minecraft.class_1297;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public abstract class CobwebMixin {

    // JIEZU在蛛网中不减速
    @Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true)
    private void onSlowMovement(class_2680 state, net.minecraft.class_243 multiplier, CallbackInfo ci) {
        if (!((Object) this instanceof class_3222 player)) return;
        if (!GameManager.getInstance().isGameActive()) return;
        PlayerData data = GameManager.getInstance().getPlayerData(player.method_5667());
        if (data != null && data.getRole() == Role.JIEZU) {
            ci.cancel(); // JIEZU不受蛛网减速
        }
    }
}
