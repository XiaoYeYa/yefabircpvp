package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1309.class)
public abstract class JaneDamageMixin {

    @ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float janeBonusDamage(float amount, class_3218 world, class_1282 source) {
        class_1309 self = (class_1309) (Object) this;
        // 只对非玩家实体翻倍
        if (self instanceof class_3222) return amount;

        // 检查攻击者是否是JANE
        if (!(source.method_5529() instanceof class_3222 attacker)) return amount;

        GameManager gm = GameManager.getInstance();
        if (!gm.isGameActive()) return amount;

        PlayerData data = gm.getPlayerData(attacker.method_5667());
        if (data == null || data.getRole() != Role.JANE) return amount;

        return amount * 2.0f; // 翻倍
    }
}
