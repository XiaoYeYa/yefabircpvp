package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import net.minecraft.class_1282;
import net.minecraft.class_1294;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_3222.class)
public abstract class StrengthDamageMixin {

    @ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float onDamageModifyAmount(float amount, class_3218 world, class_1282 source, float originalAmount) {
        if (!GameManager.getInstance().isGameActive()) return amount;

        // 如果攻击者是玩家且有力量效果，把力量加成部分*0.5
        if (!(source.method_5529() instanceof class_3222 attacker)) return amount;

        var strengthEffect = attacker.method_6112(class_1294.field_5910);
        if (strengthEffect == null) return amount;

        int level = strengthEffect.method_5578() + 1; // amplifier=0 → 力量1
        // 原版力量加成：每级+3伤害（即+1.5颗心）
        float strengthBonus = level * 3.0f;
        // 将力量加成减半
        return amount - strengthBonus * 0.5f;
    }
}
