package baby.sv.yepvpfabirc.mixin;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.skill.SkillHandler;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public abstract class GlassBreakMixin {

    @Inject(method = "onBreak", at = @At("HEAD"))
    private void onBlockBreak(class_1937 world, class_2338 pos, class_2680 state, net.minecraft.class_1657 player, CallbackInfoReturnable<class_2680> cir) {
        if (world.method_8608()) return;
        if (!GameManager.getInstance().isGameActive()) return;

        // Shubing 水平画(紫水晶方块)被破坏检测
        if (state.method_27852(class_2246.field_27159)) {
            SkillHandler.onShubingPaintingBlockBroken((class_3218) world, pos);
            // 不return，让方块正常破坏
        }

        // DAMAI 墓碑(磁石)保护
        if (state.method_27852(class_2246.field_23261)) {
            GameManager gm = GameManager.getInstance();
            for (PlayerData pd : gm.getAllPlayerData().values()) {
                if (pd.getRole() != baby.sv.yepvpfabirc.game.Role.DAMAI) continue;
                if (pd.getTombstonePos() == null || !pd.getTombstonePos().equals(pos)) continue;
                long currentTick = ((class_3218) world).method_75260();
                if (currentTick < pd.getTombstoneProtectedUntilTick()) {
                    // 10秒内不可破坏
                    cir.setReturnValue(state);
                    world.method_8501(pos, state);
                    if (player instanceof class_3222 sp) {
                        sp.method_7353(net.minecraft.class_2561.method_43470("§c墓碑正在保护中，暂时无法破坏！"), true);
                    }
                    return;
                }
                // 保护期过后可以破坏(tickDamai会检测到墓碑消失并触发提前复活)
                break;
            }
        }

        // XLL 玻璃建筑不可破坏(正方体/玻璃长道)
        if (state.method_27852(class_2246.field_10033) || state.method_27852(class_2246.field_10171)) {
            if (SkillHandler.isXllProtectedBlock(pos)) {
                cir.setReturnValue(state);
                if (player instanceof class_3222 sp) {
                    sp.method_7353(net.minecraft.class_2561.method_43470("§c这是XLL的玻璃建筑，无法破坏！"), true);
                    // 强制恢复方块并同步给客户端(防止客户端破坏动画导致延迟)
                    ((class_3218) world).method_8652(pos, state, class_2248.field_31036 | class_2248.field_31031);
                }
                return;
            }
        }

        // JIEZU 特殊蛛网被破坏: 从webPositions移除，不掉落物品(直接设为空气)
        if (state.method_27852(class_2246.field_10343)) {
            GameManager gm = GameManager.getInstance();
            for (baby.sv.yepvpfabirc.game.PlayerData pd : gm.getAllPlayerData().values()) {
                if (pd.getRole() != baby.sv.yepvpfabirc.game.Role.JIEZU) continue;
                if (pd.getWebPositions().remove(pos)) {
                    // 取消正常掉落,直接设为空气
                    world.method_8501(pos, class_2246.field_10124.method_9564());
                    cir.setReturnValue(state);
                    if (player instanceof class_3222 sp) {
                        sp.method_7353(net.minecraft.class_2561.method_43470("§8你破坏了节足动物的特殊蛛网！"), true);
                    }
                    // 通知JIEZU
                    class_3222 jiezu = ((class_3218) world).method_8503().method_3760().method_14602(pd.getPlayerUuid());
                    if (jiezu != null) {
                        jiezu.method_7353(net.minecraft.class_2561.method_43470("§c§l你的蛛网被破坏了！剩余: " + pd.getWebPositions().size() + "/3"), false);
                    }
                    return;
                }
            }
        }
    }
}
