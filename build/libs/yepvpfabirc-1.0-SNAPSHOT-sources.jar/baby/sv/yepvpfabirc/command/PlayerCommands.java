package baby.sv.yepvpfabirc.command;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.PlayerData;
import baby.sv.yepvpfabirc.game.Role;
import baby.sv.yepvpfabirc.skill.SkillHandler;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class PlayerCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        // /Ciallo - 柚子厨技能
        dispatcher.register(class_2170.method_9247("Ciallo")
                .executes(ctx -> {
                    class_3222 source = ctx.getSource().method_9207();
                    if (!GameManager.getInstance().isGameActive()) {
                        ctx.getSource().method_9213(class_2561.method_43470("§c游戏未开始！"));
                        return 0;
                    }
                    SkillHandler.handleCialloCommand(source);
                    return 1;
                })
        );

        // /debugmode - 切换调试模式(OP only)
        dispatcher.register(class_2170.method_9247("debugmode")
                .requires(src -> {
                    try {
                        class_3222 p = src.method_9207();
                        return src.method_9211().method_3760().method_14603().method_14640(new net.minecraft.class_11560(p.method_7334())) != null;
                    } catch (Exception e) {
                        return true; // console
                    }
                })
                .executes(ctx -> {
                    GameManager gm = GameManager.getInstance();
                    gm.setDebugMode(!gm.isDebugMode());
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                            gm.isDebugMode() ? "§a§l[调试模式] §r§a已开启！可使用 /switchrole <职业id>" : "§c§l[调试模式] §r§c已关闭"
                    ), true);
                    return 1;
                })
        );

        // /switchrole <roleid> - 切换职业(调试模式下)
        dispatcher.register(class_2170.method_9247("switchrole")
                .then(class_2170.method_9244("role", StringArgumentType.word())
                        .executes(ctx -> {
                            GameManager gm = GameManager.getInstance();
                            if (!gm.isDebugMode()) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c调试模式未开启！请先使用 /debugmode"));
                                return 0;
                            }
                            if (!gm.isGameActive()) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c游戏未开始！"));
                                return 0;
                            }
                            class_3222 source = ctx.getSource().method_9207();
                            String roleId = StringArgumentType.getString(ctx, "role");
                            Role role = Role.fromId(roleId);
                            if (role == null) {
                                StringBuilder sb = new StringBuilder("§c未知职业ID: " + roleId + "\n§e可用职业: ");
                                for (Role r : Role.values()) {
                                    sb.append(r.getPlayerId()).append("(").append(r.getDisplayName()).append(") ");
                                }
                                ctx.getSource().method_9213(class_2561.method_43470(sb.toString()));
                                return 0;
                            }
                            if (gm.switchPlayerRole(source, role)) {
                                return 1;
                            } else {
                                ctx.getSource().method_9213(class_2561.method_43470("§c切换失败！你可能不在游戏中"));
                                return 0;
                            }
                        })
                )
        );

        // /hello <player> - NIHAO问好
        dispatcher.register(class_2170.method_9247("hello")
                .then(class_2170.method_9244("target", class_2186.method_9305())
                        .executes(ctx -> {
                            class_3222 source = ctx.getSource().method_9207();
                            if (!GameManager.getInstance().isGameActive()) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c游戏未开始！"));
                                return 0;
                            }
                            PlayerData data = GameManager.getInstance().getPlayerData(source.method_5667());
                            if (data == null || data.getRole() != Role.NIHAO) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c你不是Nihao角色！"));
                                return 0;
                            }
                            class_3222 target = class_2186.method_9315(ctx, "target");
                            SkillHandler.handleHelloCommand(source, target);
                            return 1;
                        })
                )
        );

        // /helloback <code> - 回复NIHAO问好
        dispatcher.register(class_2170.method_9247("helloback")
                .then(class_2170.method_9244("code", IntegerArgumentType.integer())
                        .executes(ctx -> {
                            class_3222 source = ctx.getSource().method_9207();
                            if (!GameManager.getInstance().isGameActive()) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c游戏未开始！"));
                                return 0;
                            }
                            int code = IntegerArgumentType.getInteger(ctx, "code");
                            SkillHandler.handleHelloBackCommand(source, code);
                            return 1;
                        })
                )
        );

        // /listroles - 列出所有职业ID
        dispatcher.register(class_2170.method_9247("listroles")
                .executes(ctx -> {
                    StringBuilder sb = new StringBuilder("§e§l职业列表:\n");
                    for (Role r : Role.values()) {
                        sb.append("§a").append(r.getPlayerId()).append(" §7- §e").append(r.getDisplayName()).append("\n");
                    }
                    ctx.getSource().method_9226(() -> class_2561.method_43470(sb.toString()), false);
                    return 1;
                })
        );
    }
}
