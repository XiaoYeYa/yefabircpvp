package baby.sv.yepvpfabirc.command;

import baby.sv.yepvpfabirc.config.AprilFoolsConfig;
import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.Role;
import baby.sv.yepvpfabirc.network.HudSyncManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class AprilFoolsCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("af")
                .requires(source -> {
                    try {
                        class_3222 p = source.method_9207();
                        return source.method_9211().method_3760().method_14603().method_14640(new net.minecraft.class_11560(p.method_7334())) != null;
                    } catch (Exception e) {
                        return true; // console
                    }
                })
                .then(class_2170.method_9247("start")
                        .executes(ctx -> {
                            GameManager.getInstance().startGame();
                            HudSyncManager.syncAllPlayers(ctx.getSource().method_9211());
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a愚人节大乱斗已开始！"), true);
                            return 1;
                        })
                )
                .then(class_2170.method_9247("random")
                        .executes(ctx -> {
                            GameManager.getInstance().startGame(true, false);
                            HudSyncManager.syncAllPlayers(ctx.getSource().method_9211());
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§6随机职业模式已开始！"), true);
                            return 1;
                        })
                        .then(class_2170.method_9247("fire")
                                .executes(ctx -> {
                                    GameManager.getInstance().startGame(true, true);
                                    HudSyncManager.syncAllPlayers(ctx.getSource().method_9211());
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§c随机职业+无限火力模式已开始！"), true);
                                    return 1;
                                })
                        )
                )
                .then(class_2170.method_9247("fire")
                        .executes(ctx -> {
                            GameManager.getInstance().startGame(false, true);
                            HudSyncManager.syncAllPlayers(ctx.getSource().method_9211());
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§c无限火力模式已开始！"), true);
                            return 1;
                        })
                )
                .then(class_2170.method_9247("stop")
                        .executes(ctx -> {
                            GameManager.getInstance().stopGame();
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§c愚人节大乱斗已停止！"), true);
                            return 1;
                        })
                )
                .then(class_2170.method_9247("assign")
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .then(class_2170.method_9244("role", StringArgumentType.word())
                                        .suggests((ctx, builder) -> {
                                            for (Role role : Role.values()) {
                                                builder.suggest(role.getPlayerId());
                                            }
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> {
                                            class_3222 player = class_2186.method_9315(ctx, "player");
                                            String roleId = StringArgumentType.getString(ctx, "role");
                                            Role role = Role.fromId(roleId);
                                            if (role == null) {
                                                ctx.getSource().method_9213(class_2561.method_43470("§c未知职业: " + roleId));
                                                return 0;
                                            }
                                            GameManager.getInstance().assignRole(player.method_7334().name(), role);
                                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a已将 " + player.method_7334().name() + " 分配为 " + role.getDisplayName()), true);
                                            return 1;
                                        })
                                )
                        )
                )
                .then(class_2170.method_9247("spawn")
                        .then(class_2170.method_9244("playerName", StringArgumentType.word())
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(ctx -> {
                                            String playerName = StringArgumentType.getString(ctx, "playerName");
                                            class_2338 pos = class_2262.method_48299(ctx, "pos");
                                            GameManager.getInstance().setSpawnPoint(playerName, pos);
                                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a已设置 " + playerName + " 的出生点为 " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()), true);
                                            return 1;
                                        })
                                )
                        )
                )
                .then(class_2170.method_9247("arena")
                        .then(class_2170.method_9244("center", class_2262.method_9698())
                                .then(class_2170.method_9244("radius", IntegerArgumentType.integer(10, 200))
                                        .executes(ctx -> {
                                            class_2338 center = class_2262.method_48299(ctx, "center");
                                            int radius = IntegerArgumentType.getInteger(ctx, "radius");
                                            GameManager.getInstance().setArena(center, radius);
                                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a已设置场地中心 " + center.method_10263() + ", " + center.method_10264() + ", " + center.method_10260() + " 半径 " + radius), true);
                                            return 1;
                                        })
                                )
                        )
                )
                .then(class_2170.method_9247("reload")
                        .executes(ctx -> {
                            AprilFoolsConfig config = new AprilFoolsConfig();
                            config.load();
                            config.applyToGameManager();
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a配置已重新加载！"), true);
                            return 1;
                        })
                )
                .then(class_2170.method_9247("save")
                        .executes(ctx -> {
                            AprilFoolsConfig config = new AprilFoolsConfig();
                            config.save();
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a配置已保存！"), true);
                            return 1;
                        })
                )
                .then(class_2170.method_9247("reveal")
                        .executes(ctx -> {
                            GameManager gm = GameManager.getInstance();
                            if (!gm.isGameActive()) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c游戏未开始！"));
                                return 0;
                            }
                            if (gm.isRevealed()) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c已经是明牌状态了！"));
                                return 0;
                            }
                            gm.revealAll();
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a已触发明牌！"), true);
                            return 1;
                        })
                )
                .then(class_2170.method_9247("rolespawn")
                        .then(class_2170.method_9244("role", StringArgumentType.word())
                                .suggests((ctx, builder) -> {
                                    for (Role role : Role.values()) {
                                        builder.suggest(role.getPlayerId());
                                    }
                                    return builder.buildFuture();
                                })
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(ctx -> {
                                            String roleId = StringArgumentType.getString(ctx, "role");
                                            Role role = Role.fromId(roleId);
                                            if (role == null) {
                                                ctx.getSource().method_9213(class_2561.method_43470("§c未知职业: " + roleId));
                                                return 0;
                                            }
                                            class_2338 pos = class_2262.method_48299(ctx, "pos");
                                            GameManager.getInstance().setRoleSpawnPoint(role, pos);
                                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a已设置 " + role.getDisplayName() + " 的出生点为 " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()), true);
                                            return 1;
                                        })
                                )
                        )
                )
                .then(class_2170.method_9247("open")
                        .then(class_2170.method_9244("minutes", IntegerArgumentType.integer(1, 1440))
                                .executes(ctx -> {
                                    int minutes = IntegerArgumentType.getInteger(ctx, "minutes");
                                    GameManager.getInstance().getLobbyManager().adminOpen(minutes);
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§a§l【临时开放】§r§a 服务器已临时开放 §e" + minutes + " §a分钟！"), true);
                                    // 广播给所有玩家
                                    for (class_3222 p : ctx.getSource().method_9211().method_3760().method_14571()) {
                                        p.method_7353(class_2561.method_43470("§a§l【系统】§r§e 管理员已临时开放服务器 §a" + minutes + " §e分钟！"), false);
                                    }
                                    return 1;
                                })
                        )
                )
                .then(class_2170.method_9247("list")
                        .executes(ctx -> {
                            GameManager gm = GameManager.getInstance();
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a§l=== 职业分配列表 ==="), false);
                            for (var entry : gm.getPlayerNameToRole().entrySet()) {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§e" + entry.getKey() + " §7-> §a" + entry.getValue().getDisplayName()), false);
                            }
                            return 1;
                        })
                )
                .then(class_2170.method_9247("win")
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(ctx -> {
                                    class_3222 player = class_2186.method_9315(ctx, "player");
                                    GameManager gm = GameManager.getInstance();
                                    if (!gm.isGameActive()) {
                                        ctx.getSource().method_9213(class_2561.method_43470("§c游戏未开始！"));
                                        return 0;
                                    }
                                    baby.sv.yepvpfabirc.game.PlayerData pd = gm.getPlayerData(player.method_5667());
                                    if (pd == null) {
                                        ctx.getSource().method_9213(class_2561.method_43470("§c该玩家未参与本局游戏！"));
                                        return 0;
                                    }
                                    boolean ok = gm.triggerVictorySceneForPlayer(pd);
                                    if (!ok) {
                                        ctx.getSource().method_9213(class_2561.method_43470("§c无法触发胜利(游戏未激活或已在演礼中)"));
                                        return 0;
                                    }
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§a已判定 §e" + player.method_7334().name() + " §a胜利！"), true);
                                    return 1;
                                })
                        )
                )
        );
    }
}
