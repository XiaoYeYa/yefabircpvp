package baby.sv.yepvpfabirc.command;

import baby.sv.yepvpfabirc.game.GameManager;
import baby.sv.yepvpfabirc.game.Role;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class VoteCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        // /vote <mode> - 发起投票
        dispatcher.register(class_2170.method_9247("vote")
                .then(class_2170.method_9244("mode", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            builder.suggest("id");
                            builder.suggest("select");
                            builder.suggest("random");
                            return builder.buildFuture();
                        })
                        .executes(ctx -> {
                            class_3222 player = ctx.getSource().method_9207();
                            String mode = StringArgumentType.getString(ctx, "mode");
                            GameManager.getInstance().getLobbyManager().initiateVote(
                                    player, mode, ctx.getSource().method_9211());
                            return 1;
                        })
                )
                .executes(ctx -> {
                    ctx.getSource().method_9226(() -> class_2561.method_43470("§7用法: §e/vote <id|select|random>"), false);
                    return 1;
                })
        );

        // /voteyes - 投同意票
        dispatcher.register(class_2170.method_9247("voteyes")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    GameManager.getInstance().getLobbyManager().castVote(player, true);
                    return 1;
                })
        );

        // /voteno - 投反对票
        dispatcher.register(class_2170.method_9247("voteno")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    GameManager.getInstance().getLobbyManager().castVote(player, false);
                    return 1;
                })
        );

        // /selectrole <roleid> - 自选模式选择职业
        dispatcher.register(class_2170.method_9247("selectrole")
                .then(class_2170.method_9244("role", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            for (Role role : Role.values()) {
                                builder.suggest(role.getPlayerId());
                            }
                            return builder.buildFuture();
                        })
                        .executes(ctx -> {
                            class_3222 player = ctx.getSource().method_9207();
                            String roleId = StringArgumentType.getString(ctx, "role");
                            GameManager.getInstance().getLobbyManager().handleRoleSelection(
                                    player, roleId, ctx.getSource().method_9211());
                            return 1;
                        })
                )
        );
    }
}
